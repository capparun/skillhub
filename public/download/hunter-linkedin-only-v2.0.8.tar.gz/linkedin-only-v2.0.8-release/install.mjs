#!/usr/bin/env node
// Hunter 客户包装机:插件运行时 + Skills 安装。
// 本地模式: 解压后在本目录执行  node install.mjs [--force]
// 远程模式: node install.mjs --from <url> [--sha256 <hex>] [其他参数...]
// 在线登记: --product <slug> --version <v> --server <url> [--update-credential <cred>]
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import {
  resolveNpmInvocation,
  resolveOpencliInvocation,
  runInvocation,
  spawnInvocation,
} from './process-distribution.mjs';
import { resolveInstallTargets } from './target-distribution.mjs';

const argv = process.argv.slice(2);

function getArg(name) {
  const index = argv.indexOf(name);
  return index !== -1 ? argv[index + 1] : null;
}

function withoutArgs(args, names) {
  const result = [];
  for (let i = 0; i < args.length; i += 1) {
    if (names.includes(args[i])) {
      i += 1; // 跳过该参数的值
      continue;
    }
    result.push(args[i]);
  }
  return result;
}

// --from: 下载 → 校验 SHA-256 → 解压 → 委托包内 install.mjs 继续
const fromUrl = getArg('--from');
if (fromUrl) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'hunter-install-'));
  const tgzPath = path.join(tmpDir, 'package.tar.gz');
  console.log(`下载安装包: ${fromUrl}`);
  const response = await fetch(fromUrl);
  if (!response.ok) throw new Error(`下载失败: HTTP ${response.status}`);
  fs.writeFileSync(tgzPath, Buffer.from(await response.arrayBuffer()));

  const expectedSha = (getArg('--sha256') ?? response.headers.get('x-sha256'))?.toLowerCase();
  if (expectedSha) {
    const actual = crypto.createHash('sha256').update(fs.readFileSync(tgzPath)).digest('hex');
    if (actual !== expectedSha) {
      throw new Error(`安装包校验失败(期望 ${expectedSha},实际 ${actual}),已中止`);
    }
    console.log('SHA-256 校验通过');
  } else {
    console.warn('警告: 未提供 SHA-256,跳过完整性校验');
  }

  runInvocation({ command: 'tar', prefixArgs: [] }, ['-xzf', tgzPath, '-C', tmpDir]);
  const packageDir = fs
    .readdirSync(tmpDir)
    .map((name) => path.join(tmpDir, name))
    .filter((p) => fs.statSync(p).isDirectory() && fs.existsSync(path.join(p, 'install.mjs')))[0];
  if (!packageDir) throw new Error('安装包内容不正确: 未找到 install.mjs');

  const rest = withoutArgs(argv, ['--from', '--sha256']);
  const result = spawnInvocation(
    { command: process.execPath, prefixArgs: [] },
    [path.join(packageDir, 'install.mjs'), ...rest],
    { stdio: 'inherit' },
  );
  fs.rmSync(tmpDir, { recursive: true, force: true });
  process.exit(result.status ?? 1);
}

const distributionRoot = path.dirname(fileURLToPath(import.meta.url));
const receipt = JSON.parse(fs.readFileSync(path.join(distributionRoot, 'distribution.json'), 'utf8'));
const runtimeRoot = path.join(distributionRoot, 'runtime');
const plugins = (receipt.requirements?.plugins ?? []).map(({ name }) => name);
const skills = (receipt.skills ?? []).map(({ id }) => id);
const targets = resolveInstallTargets(argv);
const skillsRoots = targets.skillRoots;
const plan = {
  schemaVersion: 1,
  platform: process.platform,
  node: { version: process.version, ok: Number(process.versions.node.split('.')[0]) >= 20 },
  agent: {
    requested: getArg('--agent') ?? 'auto',
    detected: targets.detectedAgent,
    selectionApplied: targets.selectionApplied,
  },
  plugins,
  skills,
  skillTargets: skillsRoots,
  runtimeTarget: runtimeRoot,
  stateTarget: targets.stateRoot,
  actions: [
    ...(plugins.length > 0 ? ['install-runtime', 'install-plugins'] : []),
    'install-skills',
    ...(getArg('--product') ? ['write-installation-receipt'] : []),
  ],
  recommendedNextAction: 'node doctor.mjs',
};

if (argv.includes('--dry-run')) {
  process.stdout.write(`${JSON.stringify(plan)}\n`);
  process.exit(0);
}
if (argv.includes('--preflight')) {
  process.stdout.write(`${JSON.stringify(plan, null, argv.includes('--json') ? 2 : 0)}\n`);
  process.exit(plan.node.ok ? 0 : 30);
}

const force = argv.includes('--force');
if (plugins.length > 0) {
  if (!fs.existsSync(runtimeRoot)) throw new Error('交付包缺少 runtime 目录');
  runInvocation(resolveNpmInvocation(), ['install', '--omit=dev'], { cwd: runtimeRoot });

  const opencli = resolveOpencliInvocation(runtimeRoot);
  const runtimePackages = new Map(
    (receipt.runtime?.packages ?? []).map(runtimePackage => [runtimePackage.name, runtimePackage]),
  );
  // 已安装的同名插件先卸载再装(opencli install 不支持覆盖,file:// 路径随包变化)
  const listResult = spawnInvocation(opencli, ['plugin', 'list']);
  const installedPlugins = `${listResult.stdout || ''}${listResult.stderr || ''}`;
  for (const plugin of plugins) {
    const runtimePackage = runtimePackages.get(plugin);
    if (!runtimePackage) throw new Error(`交付包缺少插件运行时: ${plugin}`);
    const pluginPath = path.join(runtimeRoot, runtimePackage.path);
    if (installedPlugins.includes(plugin)) {
      runInvocation(opencli, ['plugin', 'uninstall', plugin]);
    }
    runInvocation(opencli, ['plugin', 'install', pathToFileURL(pluginPath).href]);
  }
}

for (const skillsRoot of skillsRoots) {
  fs.mkdirSync(skillsRoot, { recursive: true });
  for (const skill of skills) {
    const source = path.join(distributionRoot, 'skills', skill);
    const destination = path.join(skillsRoot, skill);
    if (fs.existsSync(destination) && !force) {
      throw new Error(`Skill 已存在: ${destination}；确认覆盖时使用 --force`);
    }
    fs.cpSync(source, destination, { recursive: true, force });
  }
  console.log(`Skills 已安装到 ${skillsRoot}`);
}

// 在线登记:记录安装信息 + 把安装/更新脚本复制到固定位置(更新不依赖原解压目录)
const product = getArg('--product');
if (product) {
  const home = targets.stateRoot;
  const record = {
    product,
    version: getArg('--version'),
    serverUrl: (getArg('--server') ?? '').replace(/\/+$/, '') || null,
    updateCredential: getArg('--update-credential'),
    agent: targets.detectedAgent ?? targets.requestedAgent,
    projectDir: targets.projectDir,
    skillTargets: targets.skillRoots,
    stateTarget: targets.stateRoot,
    installedAt: new Date().toISOString(),
  };
  const installDir = path.join(home, 'installations');
  fs.mkdirSync(installDir, { recursive: true });
  fs.writeFileSync(
    path.join(installDir, `${product}.json`),
    `${JSON.stringify(record, null, 2)}\n`,
    { mode: 0o600 },
  );

  const packageHome = path.join(home, 'packages', product);
  fs.mkdirSync(packageHome, { recursive: true });
  for (const file of [
    'install.mjs',
    'doctor.mjs',
    'update.mjs',
    'process-distribution.mjs',
    'target-distribution.mjs',
    'distribution.json',
  ]) {
    const source = path.join(distributionRoot, file);
    if (fs.existsSync(source)) fs.copyFileSync(source, path.join(packageHome, file));
  }

  // 更新 Skill 通过这个安装时生成的指针定位真实状态目录，避免假定 ~/.hunter。
  for (const skillsRoot of skillsRoots) {
    const updateSkillRoot = path.join(skillsRoot, 'cskh-update');
    if (!skills.includes('cskh-update') || !fs.existsSync(updateSkillRoot)) continue;
    fs.writeFileSync(
      path.join(updateSkillRoot, '.hunter-installation.json'),
      `${JSON.stringify({ schemaVersion: 1, product, stateRoot: home }, null, 2)}\n`,
      { mode: 0o600 },
    );
  }
  console.log(`安装信息已登记到 ${path.join(installDir, `${product}.json`)}`);
  console.log(`以后更新请运行: node ${path.join(packageHome, 'update.mjs')}`);
}

console.log(`安装完成：${plugins.length} 个插件，${skills.length} 个 Skills × ${skillsRoots.length} 个 Agent 目录。`);
