---
name: cskh-sourcing-linkedin
description: |
  LinkedIn 寻访 pipeline 编排 skill。接收已确认的 SourcingRequest → 选择 LinkedIn 发现路径 → 读取并标准化结果 → LLM 评估 → 输出报告。
  触发词: linkedin sourcing / linkedin 寻访 / 在 linkedin 上招 / linkedin 人才搜索 / linkedin 候选人
  与通用 sourcing 词共用范围，但优先在 LinkedIn 场景触发。
type: skill
version: 1.6.3
status: ready
disable: false
---

# cskh-sourcing-linkedin: LinkedIn 寻访 Pipeline

编排“已确认画像 → LinkedIn 发现 → 标准化 → LLM 评估 → 报告”的 LinkedIn 寻访工作流。画像与约束的唯一事实源是 `cskh-align` 交付并经用户确认的 SourcingRequest。

> **定位**：本 skill 只负责 LinkedIn 平台。如果需要猎聘或脉脉，请使用对应平台命令或未来独立的平台 skill。

## 触发条件

以下任一情况自动触发：
- 用户说"LinkedIn sourcing"、"LinkedIn 寻访"、"在 LinkedIn 上招"
- 用户说"linkedin 人才搜索"、"linkedin 候选人"
- 用户从 `cskh-sourcing` 分发器选择 LinkedIn

上述直接请求仅在已有确认的 SourcingRequest 时执行；如果用户只给出 JD、职位描述或零散要求，先交给 `cskh-align`，不得在本 Skill 内自行生成或确认人才画像。

## 最小执行路径（TL;DR）

```
Step 1-2: 验证已确认的 SourcingRequest → 读取 persona 与搜索约束
Step 3:   生成 LinkedIn 英文关键词（2-4 组）
Step 4:   解析 Hunter 数据目录并保存 JD 配置到 {hunterDataDir}/sourcing/{projectId}.json
Step 5 前: 确认本轮寻访量级（快速验证 ~15 / 标准轮 ~30-50 / 深度 Mapping 80+）+ 是否开启详情页二评
Step 5:   选择并执行 LinkedIn 发现路径（默认 xray → 可选 scout/recruiter）
Step 6:   读取结果文件 → normalize 为统一 schema
Step 8:   LLM 统一评估（初评，仅列表页字段）
Step 8.5: 详情页二评（可选，默认关闭）→ 官方 profile-read 为基础，按岗位追加详情能力 → LLM 复评
Step 9-10: 结果诊断 → 建议是否调整条件续跑（最多 3 轮）
Step 12: 输出 LinkedIn 专属报告（Markdown + CSV + JSON + HTML）
```

**一句话规则：** 启动前确认一次本轮寻访量级、以及是否开启详情页二评；每轮评估后给出诊断与续跑建议，由用户决定调整续跑或出报告；结束前仅确认一次 HTML 报告。其余步骤自动推进。

## 输入输出

**输入：**
- `cskh-align` 生成且用户已确认的 SourcingRequest
- 已确认的 `persona`、`searchParameters` 与 LinkedIn 渠道
- 本轮目标量级（可选，未提供则在 Step 5 前确认）

**输出：**
- 基于确认画像生成的 LinkedIn 搜索配置
- LinkedIn 英文关键词方案
- 可执行的 LinkedIn scout/xray/recruiter 命令
- LLM 评估结果（评分、排序、理由）
- LinkedIn 寻访报告（Markdown + CSV + JSON + HTML）

## OpenCLI 官方能力注册表

本 Skill 以 OpenCLI 官方 LinkedIn 命令为优先能力层。注册表示 Skill 可以按任务调用，不代表每轮必须全部执行。Skill 必须根据岗位画像、当前步骤、访问成本和用户意图选择最小命令集合；不得为了“信息更全”无条件遍历全部能力。

### 启动时发现实际能力

每次新会话首次进入本 Skill 时，先执行一次 `opencli list -f json`，从实时注册表确认 `linkedin` 与 `hunter-linkedin` 命令。注册表是事实来源，本节表格只描述编排策略：

- 必须确认本轮将使用的命令真实存在；缺失时明确报告缺少哪个官方适配器或 Hunter 插件，不得猜测旧命令名
- 需要命令参数时执行 `opencli <site> <command> --help -f yaml`，不得把静态文档中的参数当成永久契约
- 选择 `xray` 时检查 Browser Bridge，但不检查 LinkedIn 登录态；当前底层 `google search`（以及备用搜索适配器）需要 Chrome 与 OpenCLI 扩展连接
- 选择 `scout`、`recruiter-scout` 或候选人详情读取时，同时检查 Browser Bridge 与 LinkedIn 登录态
- X-Ray 发现由本 Skill 直接调用搜索引擎命令，不要求 LinkedIn 登录态且不消耗 LinkedIn CUL；但搜索适配器可能仍依赖 Browser Bridge，必须以实时注册表中的 `browser` 字段为准

### 数据目录解析

启动时只解析一次 `hunterDataDir`，后续所有配置、中间文件、检查点和报告均使用该目录：

1. 若当前安装回执包含 `stateTarget`，使用该路径
2. 否则若环境变量 `HUNTER_DATA_DIR` 已设置，使用其值
3. 否则使用用户级默认目录 `~/.hunter`

项目级安装（包括 TRAE、WorkBuddy 或其他 Agent 的项目目录）不得再回退写入另一个 Agent 的用户目录。解析完成后，必须先把下文 `{hunterDataDir}` 替换为本次真实绝对路径，再执行命令或写入文件。

### 当前账号能力

| 需求 | 官方命令 | 使用规则 |
|---|---|---|
| 确认 LinkedIn 登录态与当前账号 | `opencli linkedin whoami -f json` | 浏览器路径开始前默认执行；同一持久会话内无需重复 |
| 读取当前账号公开主页 | `opencli linkedin profile-read -f json` | 仅在用户询问账号资料、需要检查主页完整度或以本人画像辅助寻访时执行 |
| 读取主页数据看板 | `opencli linkedin profile-analytics -f json` | 仅在用户询问主页浏览、曝光或搜索表现时执行 |
| 读取一度人脉 | `opencli linkedin connections --limit <N> -f json` | 仅在用户要求从现有人脉找候选人或做关系映射时执行 |
| 读取待处理的已发邀请 | `opencli linkedin sent-invitations -f json` | 仅用于 CRM 对账、避免重复触达或用户明确要求时执行 |

账号能力均为只读，但可能涉及用户人脉和账号数据。除 `whoami` 登录态确认外，不得作为普通寻访的固定前置步骤，也不得把结果写入候选人报告，除非用户明确要求。

### 候选人详情能力

| 信息层 | 官方命令 | Skill 决策规则 |
|---|---|---|
| 基础主页 | `opencli linkedin profile-read --profile-url "<url>" -f json` | 深评候选人的默认详情入口 |
| 结构化工作经历 | `opencli linkedin profile-experience --profile-url "<url>" -f json` | 岗位重视年限、公司、职级、管理经验或技术栈时执行 |
| 项目经历 | `opencli linkedin profile-projects --profile-url "<url>" -f json` | 工程、产品、设计、研究等重视项目证据的岗位执行 |
| 公开内容 | `opencli linkedin posts --profile-url "<url>" --limit <N> -f json` | 高管、市场、销售、顾问或重视行业影响力的岗位执行 |
| 专业服务 | `opencli linkedin services-read --profile-url "<url>" -f json` | 顾问、自由职业者、培训师等服务型人才执行 |

Skill 负责选择和串行编排这些命令，并把成功结果合并到候选人的 `detail.profile`、`detail.experiences`、`detail.projects`、`detail.posts`、`detail.services`。单项失败只记录到 `detailFetch`，不得丢弃其他已成功详情。Hunter 插件只实现 OpenCLI 官方命令没有覆盖的招聘领域能力，不重复实现同类页面读取。

**官方详情命令已知缺口（OpenCLI v1.8.x 实测）：**

- `profile-read` 的 `location`、`education`、`experience` 字段解析结果通常为空，属官方解析器现状，不是候选人主页没有这些内容
- 候选人所在地可改用 `profile-experience` 返回的每段经历 `location` 推断
- 学历信息当前无任何官方命令可达；二评时**不得**以"详情页缺少学历信息"为由下调评分或结论

## Step 3: 生成 LinkedIn 英文关键词

基于人才画像，生成适合 LinkedIn 搜索的英文关键词：

| 角度 | 示例 |
|------|------|
| 职位名 + 技能 | `"AI Inference Engineer,CUDA,TensorRT"` |
| 职位名 + 领域 | `"LLM Inference Engineer,Large Language Model"` |
| 更宽泛职位 | `"Machine Learning Engineer,AI Infrastructure"` |
| 目标公司 + 技能 | `"Google AI Inference","Meta AI Infrastructure"` |

**规则：**
- 使用英文职位名和英文技能词
- 每个关键词组 1-3 个词，避免过长
- 生成 2-4 组，覆盖不同搜索角度
- 如果 JD 有明确目标公司，单独生成一组目标公司关键词

## Step 5: LinkedIn 发现路径

### 执行前：确认本轮寻访量级

执行任何发现命令前，必须确认本轮目标量级。用户在输入中已给出具体数字时按其数字执行并复述确认；未给出时提供三档供选择：

| 档位 | 目标人数 | 路径策略 | 成本 |
|------|---------|---------|------|
| 快速验证 | ~15 | 仅 xray | 免费 |
| 标准轮（默认） | ~30-50 | xray + 必要时 scout | scout 部分消耗 CUL |
| 深度 Mapping | 80+ | xray + scout 多页 + recruiter（如可用） | 消耗较多 CUL |

确认后将量级写入 `{hunterDataDir}/sourcing/{projectId}.json` 的 `roundTarget` 字段（`{"tier": "standard", "targetCount": 40}`），Step 12 的检索统计用它做目标 vs 实际对比。

同时确认**是否开启详情页二评**（默认关闭）。向用户说明：

- 不开（默认）：初评只看列表页能看到的职位/公司/地点/简介，速度快、不消耗 LinkedIn 账号额度；但学历、完整经历、证书等详情页才有的信息看不到
- 开启：初评通过后，自动访问通过者的 LinkedIn 详情页，用完整资料再评一轮，结果更准；代价是每看一人计一次 profile 浏览（受 LinkedIn 商业使用上限约束），且需要当前 Chrome 已登录 LinkedIn

确认结果写入项目配置的 `deepReview` 字段（`true`/`false`），本轮后续续跑沿用，不再重复询问。

### 路径选择策略

| 路径 | 命令 | 默认优先级 | 成本 | 结果文件 |
|------|------|-----------|------|---------|
| **X-Ray** | `node <本Skill目录>/scripts/discover-linkedin-xray.mjs` | 默认第一选择 | Skill 直接编排官方搜索；免费，不耗 CUL；无需 LinkedIn 登录，但当前需要 Browser Bridge | `{hunterDataDir}/channels/linkedin/xray-result-{timestamp}.json` |
| **Browser** | `opencli hunter-linkedin scout` | 有登录态且 xray 结果质量不佳时 | 消耗 CUL | `{hunterDataDir}/channels/linkedin/linkedin-scout-result.json` |
| **Recruiter** | `opencli hunter-linkedin recruiter-scout --raw` | Recruiter tier 可用 | 消耗 CUL | `{hunterDataDir}/channels/linkedin-recruiter/linkedin-recruiter-scout-result.json` |

> **Apify 已移除**（2026-09-10）：LinkedIn 候选人发现使用 xray / browser 两条基础路径，Recruiter 账号还可使用 recruiter 路径；`apify`、`apify-cost` 命令及相关配置已删除。

**默认执行顺序：**
1. 先执行本 Skill 的 `discover-linkedin-xray.mjs`（直接调用官方 `opencli google search`，Google 优先，免费、快速验证关键词质量）
2. 如果 xray 结果 < 5 人或质量不佳，且用户有 LinkedIn 登录态，执行 `opencli hunter-linkedin scout`
3. `recruiter-scout` 只在 `{hunterDataDir}/config.json` 中检测到 Recruiter tier 时推荐

### 浏览器导航稳定性规则

所有发现与详情命令必须遵守以下编排，尽量避免 Browser Bridge 标签页复用竞态导致的 `Navigation rejected`：

1. 同一寻访任务沿用同一个持久浏览器会话；不得为每组关键词创建新 session。
2. 浏览器命令严格串行执行；上一条命令结束并确认页面稳定后才能执行下一条。禁止并发运行 xray、scout、company、recruiter-scout 或任何 `opencli linkedin` 详情/账号命令。
3. 命令结束后保留当前标签页和会话，不主动关闭、释放或切换到空白页。
4. 两条包含页面导航的命令之间至少冷却 5 秒；上一条出现导航错误时冷却 10 秒。
5. 同一轮每组关键词只运行一次 `discover-linkedin-xray.mjs`。脚本按 `Google → 独立 Google 重试 → Brave → Yahoo` 自动恢复，Skill 不得逐个重复调用这些搜索命令。Google 成功时不会调用备用源；Google 两次均失败或无有效 LinkedIn `/in/` 结果时才降级。
6. 若整条 `xray` 仍返回失败，Skill 最多进行一次流程级重试。重试前等待 10 秒并继续沿用持久会话；第二次仍失败则停止 X-Ray，记录 `attempts`，有 LinkedIn 登录态时继续 scout，否则输出 `manualCheckUrl` 供人工复核。
7. 不把 `Navigation rejected` 表述为 Google 或 LinkedIn 风控。它是导航建立前的浏览器错误；只有实际 HTTP 429、验证码或挑战页才能标记为搜索引擎风控。
8. 多组关键词依次执行，每组之间冷却至少 5 秒；结果达到本轮目标后立即停止，不为凑满请求次数继续搜索。
9. 若预检或搜索返回 `BROWSER_CONNECT`，立即提示打开 Chrome 并启用 OpenCLI 扩展；此时 Google、Brave、Yahoo 共享同一基础设施故障，不继续轮询备用源，也不把它记为搜索源无结果。

Skill 不应要求用户处理一次性的 `Navigation rejected`。只有插件自动恢复和一次流程级重试都失败、且没有可用的 scout 路径时，才展示人工复核链接。

### X-Ray 命令

```bash
node <本Skill目录>/scripts/discover-linkedin-xray.mjs \
  --keyword "AI Inference Engineer" \
  --location "Shanghai" \
  --limit 15
```

该脚本运行在 Skill 进程中，依次调用官方 `opencli google search` / `brave search` / `yahoo search`，把公开结果保存成 Hunter X-Ray schema，随后调用本地的 `opencli hunter-linkedin normalize`。Hunter CLI 不再提供嵌套启动搜索命令的 X-Ray 入口。

### Browser Scout 命令

```bash
opencli hunter-linkedin scout \
  --keyword "AI Inference Engineer" \
  --location "Shanghai" \
  --industry "Software Development" \
  --limit 15
```

### Recruiter Scout 命令

```bash
opencli hunter-linkedin recruiter-scout \
  --keyword "AI Inference Engineer" \
  --location "Shanghai" \
  --limit 15 \
  --raw \
  --output "{hunterDataDir}/sourcing/xxx-linkedin-recruiter-raw.json"
```

## Step 6: 读取并标准化 LinkedIn 结果

### X-Ray 结果

```bash
# 自动读取最新 X-Ray 结果，输出到
# {hunterDataDir}/channels/linkedin/normalized-xray-result.json
opencli hunter-linkedin normalize --source xray
```

### Browser Scout 结果

```bash
opencli hunter-linkedin normalize \
  --source scout \
  --input "{hunterDataDir}/channels/linkedin/linkedin-scout-result.json"
```

## Step 8: LLM 统一评估

### 评估 Prompt

基于 LinkedIn 列表页可用字段做评估。注意：LinkedIn 列表页通常缺少年龄/学历/经验年限，不要强制过滤这些字段。

```
你是一位资深猎头顾问。请根据以下 JD 配置，对 LinkedIn 候选人做列表页初评。

【职位要求】
职位名称: {title}

硬性要求（必须满足）:
{hard_requirements}

加分项（有则更好）:
{bonus_items}

排除项（一票否决）:
{exclude_items}

评分规则:
- 满分 100 分
- 硬性要求全满足: 基础分 60
- 加分项: 每项 +5~10 分，封顶 40
- 排除项命中: 直接不合格

【LinkedIn 候选人列表】（共 N 人）

候选人 1:
- 姓名: {name}
- 当前职位: {title}
- 当前公司: {company}
- 地点: {location}
- 简介: {listPageText}
- 资料链接: {profileUrl}

候选人 2: ...

【评估要求】

对每位候选人：
1. 基于职位、公司、地点、简介做匹配判断
2. 识别加分项匹配情况
3. 检查是否有排除项命中
4. 给出 0-100 的评分
5. 判断是否 qualified（评分 >= 60 且无排除项）
6. 写出推荐理由或风险点

【LinkedIn 字段特殊性】
- 年龄、学历、经验年限通常缺失，允许基于职位/公司合理推断
- 不要因为这些字段缺失而降低评分
- 地点不匹配 = 风险点，但不一票否决
- 近期跳槽或项目经验可在简介中推断

【输出格式】

请输出 JSON：

{
  "evaluations": [
    {
      "id": "...",
      "name": "...",
      "channel": "linkedin",
      "score": 85,
      "qualified": true,
      "hard_passed": ["title_match", "location_match"],
      "hard_failed": [],
      "bonus_matched": ["target_company", "senior_title"],
      "exclude_matched": [],
      "reasons": ["职位匹配：AI Inference Engineer", "公司背景：目标公司"],
      "risks": ["地点为新加坡，与目标上海不一致"],
      "highlights": ["目标公司背景", "资深工程师职位"]
    }
  ],
  "summary": {
    "total": 15,
    "qualified_count": 10,
    "qualified_rate": "67%",
    "avg_score": 72,
    "top3_scores": [90, 85, 82],
    "top3_names": ["San Zhang", "Li Si", "Wang Wu"]
  }
}
```

### Sanity Check

评估结果生成后自动校验：

| 校验项 | 阈值 | 异常处理 |
|--------|------|---------|
| 所有人评分相同 | 所有 score 一致 | 提示异常，建议重试 |
| 通过率 > 95% | qualified_rate > 0.95 | 提示标准过松 |
| 通过率 < 5% | qualified_rate < 0.05 | 提示标准过严 |
| 平均分异常 | avg_score < 30 或 > 95 | 提示评分分布异常 |

异常时向用户展示数据并询问是否继续。无异常则进入 Step 8.5（若开启）或 Step 9 结果诊断。

## Step 8.5: 详情页二评（可选，默认关闭）

仅当项目配置 `deepReview: true` 时执行。对初评通过的候选人访问 LinkedIn 详情页，用完整资料复评一轮。

### 执行方式

```bash
node <本Skill目录>/scripts/enrich-linkedin-profiles.mjs <评估结果.json> \
  --include profile,experience \
  --limit 20
```

`--include` 由 Skill 根据“候选人详情能力”表生成，可选值为 `profile,experience,projects,posts,services`。脚本只负责编排，内部逐项调用对应的 `opencli linkedin ...` 官方命令，不包含 LinkedIn 页面解析器。
单条官方命令默认 120 秒浏览器超时，可用 `--command-timeout-ms` 调整；脚本同步设置 OpenCLI 内部超时，并额外保留 15 秒用于返回结构化错误。超时只标记当前能力失败并保存检查点，不得挂住或丢弃整批结果。

- 默认只处理初评通过（qualified）且评分降序的前 20 人；单轮硬上限 50 人
- 每位候选人先执行 `profile-read`，再按照“候选人详情能力”表决定是否追加其他命令
- 所有命令在同一个持久会话内严格串行；候选人之间沿用账号保护配置中的人性化间隔和每日浏览上限
- 每完成一位候选人立即把结构化结果和 `detailFetch` 状态写回 `<原名>-with-profiles.json`，支持失败隔离与断点续跑
- 为兼容现有评估器，同时由结构化结果生成 `detailText`；新评估优先读取 `detail` 下的结构化字段
- Hunter CLI 不再提供重复的详情页解析入口；详情读取统一使用上表中的 OpenCLI 官方命令

### 二评 Prompt 调整

复用 Step 8 的评估 prompt，做两处调整：

1. 候选人信息中追加结构化详情 `{detail}`；兼容旧结果时使用 `- 详情页资料: {detailText}`
2. 追加说明："现在有详情页的完整资料（About/经历/技能等）。初评时缺失的年龄/经验年限，以详情页为准重新核对；初评结论与详情页冲突时以详情页为准，可上调或下调评分与 qualified 结论。注意官方命令当前拿不到学历字段，不要因详情页缺少学历而扣分。"

二评结果覆盖初评写入 `{hunterDataDir}/sourcing/{projectId}-linkedin-evaluated.json`，Step 9 诊断与 Step 12 报告均以二评结果为准。访问失败的候选人保留初评结果，并在报告风险栏标注"详情页未能访问"。

## Step 9-10: 结果诊断与调整续跑

每轮评估完成后，基于检索统计（对照 `roundTarget`）和评估结果给出诊断，并向用户提出明确的下一步建议。

### 诊断规则

| 结果模式 | 诊断 | 建议调整 |
|---------|------|---------|
| 获取数 < roundTarget 的 50% | 关键词过窄或搜索角度不对 | 放宽关键词、去掉 location 限制、增加关键词组 |
| 通过率 < 5% | 条件过严或候选池不匹配 | 检查 hard 要求与关键词的对应关系，换搜索角度 |
| 通过率 > 95% | 标准过松 | 将部分 bonus 升为 hard，或顺势扩大量级 |
| scout 页数用尽仍未达标 | 当前关键词覆盖的候选池已耗尽 | 换领域/目标公司角度，或启用 recruiter 路径 |
| 数量与质量均达标 | 符合预期 | 直接进入 Step 12 出报告；用户也可选择加跑一轮扩量 |

### 续跑规则

- 调整方案必须具体：说明改哪组关键词、增删哪个条件、是否换路径，经用户确认后才执行。
- 改关键词/条件：回到 Step 3 重新生成；仅扩大量级：从 Step 5 直接续跑。
- 跨轮结果合并进 `{hunterDataDir}/sourcing/{projectId}-linkedin-merged.json` 去重，评估只针对新增候选人。
- 同一项目最多续跑 3 轮；达到上限或用户喊停即进入 Step 12。
- 每轮诊断建议与结果追加记录到 `{projectId}.json` 的 `rounds` 数组，保证可追溯。

## Step 12: 输出 LinkedIn 报告

寻访完成后，标准化报告自动保存到 `{hunterDataDir}/output/`：

### 检索统计（必须）

报告开头和展示给用户的汇总都必须包含检索统计，从结果文件的 meta 与候选人数组统计：

| 指标 | 说明 |
|------|------|
| 轮次 | 当前第几轮、累计执行轮数 |
| 目标量级 | `roundTarget` 中确认的本轮目标人数 |
| 各路径原始获取数 | 每个已执行发现路径（xray / scout / recruiter）各自检索到的候选人数 |
| 浏览页数 | Browser Scout 实际翻阅的列表页页数（取自 scout 结果 meta；未执行 scout 则标注"未使用"） |
| 标准化后总数 | normalize 去重合并后的候选人总数（跨轮累计去重） |
| 评估通过数 | LLM 评估 qualified 人数与通过率 |

汇总展示格式示例：

```
本次 LinkedIn 寻访（目标：标准轮 ~30-50 人）：
- X-Ray 获取 15 人；Browser Scout 获取 42 人（浏览 3 页）
- 标准化去重后共 51 人
- LLM 评估通过 18 人（35%）
```

缺失某个路径的数据时明确标注"未执行"，不要省略该行。

```
{hunterDataDir}/
├── sourcing/                              # pipeline 中间文件
│   ├── {projectId}.json                   # JD 配置
│   ├── {projectId}-linkedin-xray.json     # X-Ray 标准化结果
│   ├── {projectId}-linkedin-scout.json    # Browser 标准化结果
│   ├── {projectId}-linkedin-evaluated.json # LLM 评估结果
│   ├── {projectId}-linkedin-evaluated-with-profiles.json # 详情页二评后的评估结果（仅开启深评时）
│   └── {projectId}-linkedin-merged.json   # 多路径合并结果（如同时跑多个路径）
├── output/                                # 业务输出
│   ├── {projectId}-report.md              # Markdown 可读报告
│   ├── {projectId}-candidates.csv         # CSV 结构化数据
│   ├── {projectId}-candidates.json        # JSON 原始数据
│   └── {projectId}-report.html            # HTML 可视化报告（用户确认后生成）
└── channels/linkedin/
    ├── linkedin-scout-result.json
    ├── xray-result-{timestamp}.json
    └── tags.csv
```

**HTML 报告生成规则：**
最终报告生成后，先向用户展示含检索统计的汇总结果，再主动询问："是否需要生成 HTML 报告以便查看当前结果？"
- 如果用户确认：
  1. 询问输出文件夹（默认 `{hunterDataDir}/output/`）
  2. **首次为该项目生成 HTML 报告时**（项目配置中无 `reportFields` 字段）：根据本轮评估结果，列出报告可展示的权重字段，让用户确认要突出哪些，再问"直接用这个，还是要增删？"。字段来源是评估 reasons/highlights 里实际出现的维度（如课程体系、管理经验、母语英语、国际背景、地域）。**LinkedIn 链接列默认始终展示，无需用户选择**。确认后把字段列表写入 `{hunterDataDir}/sourcing/{projectId}.json` 的 `reportFields`（如 `["curriculum","management","nativeEnglish"]`）
  3. 执行：`opencli hunter-linkedin report <json路径> --formats html --outputDir <输出文件夹> --fields <逗号分隔字段>`；无 `reportFields`（用户选择自动判断）时省略 `--fields`，报告自动从评估结果提取字段
  4. 展示生成的 HTML 文件路径
- 非首次生成：直接沿用项目配置中的 `reportFields`，不再询问；用户主动要求调整字段时才更新
- 如果用户说"否"，跳过 HTML 生成

## 边界条件与故障恢复

### 输入阶段
1. **无 SourcingRequest**：转入 `cskh-align` 收集并确认需求，不启动任何 LinkedIn 命令
2. **SourcingRequest 未确认或字段不完整**：返回 `cskh-align` 补齐；不得在本 Skill 内推断或改写画像

### 数据收集阶段
3. **数据目录不存在**: 在已解析的 `{hunterDataDir}` 下创建 `output`、`sourcing`、`channels/linkedin`、`channels/linkedin-recruiter`；不得硬编码用户主目录
4. **scout 命令执行失败**: 等待 10 秒后在同一持久会话重试 1 次，失败则建议换 xray 路径
5. **xray 无结果**: 不重复轰击相同查询；建议放宽关键词或去掉 location 限制
6. **网络超时**: 指数退避重试，单次命令最长等待 120s；浏览器命令始终串行
7. **无 LinkedIn 登录态**: xray 路径不依赖 LinkedIn 登录态，但仍需 Browser Bridge；scout 路径失败时提示用户先登录 LinkedIn

### 评估阶段
8. **LLM 评估输出格式错误**: 重新构造 prompt，追加"必须输出严格 JSON，不要 markdown 代码块"，重试 2 次
9. **LLM API 不可用**: 降级为规则筛选（基于 title/company/location 关键词匹配），标注"LLM 评估未执行"
10. **官方详情命令返回未登录**: 提示用户在 Chrome 里登录 LinkedIn 后说"重试"；未响应则跳过二评，保留初评结果继续
11. **达到 Skill 配置的每日详情浏览上限**: 跳过剩余二评，保留初评结果继续，在报告中标注"详情页二评因当日浏览上限未执行"
12. **单个候选人或单项详情读取失败**: 在 `detailFetch` 记录错误，保留初评结果和其他成功字段，报告风险栏标注"部分详情未能访问"，不中断流程

### 输出阶段
13. **文件写入失败**: 检查目录权限，尝试写入 Node.js `os.tmpdir()` 返回的系统临时目录作为 fallback，提示用户手动迁移
14. **磁盘空间不足**: 输出到 stdout 不保存文件，提示用户清理空间

## 与 cskh-sourcing 分发器的关系

- `cskh-sourcing` 是通用入口，收到 sourcing 请求时先问平台。
- 用户选择 LinkedIn 后，`cskh-sourcing` 把上下文交给 `cskh-sourcing-linkedin` 执行。
- 用户直接说 LinkedIn 相关词时，优先触发 `cskh-sourcing-linkedin`，跳过平台选择。
