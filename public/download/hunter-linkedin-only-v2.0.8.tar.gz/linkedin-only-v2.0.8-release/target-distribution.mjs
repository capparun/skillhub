import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export function getArg(argv, name) {
  const index = argv.indexOf(name);
  return index === -1 ? null : argv[index + 1] ?? null;
}

export function inferStateRootFromUpdater(scriptPath, product) {
  if (!scriptPath || !product) return null;
  const scriptDir = path.dirname(path.resolve(scriptPath));
  if (path.basename(scriptDir) !== product) return null;
  const packagesDir = path.dirname(scriptDir);
  if (path.basename(packagesDir) !== 'packages') return null;
  return path.dirname(packagesDir);
}

export function resolveInstallTargets(argv = process.argv.slice(2), env = process.env) {
  const requested = getArg(argv, '--agent') ?? env.HUNTER_AGENT ?? 'auto';
  const projectDir = path.resolve(getArg(argv, '--project-dir') ?? env.HUNTER_PROJECT_DIR ?? process.cwd());
  const detected = requested === 'auto' ? detectAgent(env, projectDir) : requested;
  const explicitSkills = getArg(argv, '--skills-dir') ?? env.HUNTER_SKILLS_DIR;
  const explicitState = getArg(argv, '--state-dir') ?? env.HUNTER_STATE_DIR;

  let skillRoots;
  if (explicitSkills) {
    skillRoots = [path.resolve(explicitSkills)];
  } else if (getArg(argv, '--project-dir') || env.HUNTER_PROJECT_DIR || requested !== 'auto' || detected) {
    skillRoots = [projectSkillRoot(detected ?? 'generic', projectDir)];
  } else {
    const candidates = ['.workbuddy/skills', '.claude/skills', '.agents/skills']
      .map(relative => path.join(os.homedir(), relative));
    const existing = candidates.filter(directory => fs.existsSync(directory));
    skillRoots = existing.length > 0 ? existing : [path.join(os.homedir(), '.agents', 'skills')];
  }

  const stateRoot = explicitState
    ? path.resolve(explicitState)
    : detected === 'trae'
      ? path.join(projectDir, '.hunter')
      : process.platform === 'win32' && env.LOCALAPPDATA
        ? path.join(env.LOCALAPPDATA, 'Hunter')
        : path.join(os.homedir(), '.hunter');

  return {
    requestedAgent: requested,
    detectedAgent: detected,
    projectDir,
    skillRoots,
    stateRoot,
    selectionApplied: Boolean(explicitSkills || getArg(argv, '--project-dir') || requested !== 'auto' || detected),
  };
}

function detectAgent(env, projectDir) {
  if (env.TRAE_AGENT || env.TRAE_IDE) return 'trae';
  if (env.WORKBUDDY_AGENT || env.WORKBUDDY_HOME) return 'workbuddy';
  if (env.CLAUDECODE || env.CLAUDE_CODE_ENTRYPOINT) return 'claude-code';
  if (env.CODEX_HOME || env.CODEX_THREAD_ID) return 'codex';
  if (fs.existsSync(path.join(projectDir, '.trae'))) return 'trae';
  if (fs.existsSync(path.join(projectDir, '.claude'))) return 'claude-code';
  return null;
}

function projectSkillRoot(agent, projectDir) {
  if (agent === 'claude-code') return path.join(projectDir, '.claude', 'skills');
  if (agent === 'workbuddy') return path.join(projectDir, '.workbuddy', 'skills');
  return path.join(projectDir, '.agents', 'skills');
}
