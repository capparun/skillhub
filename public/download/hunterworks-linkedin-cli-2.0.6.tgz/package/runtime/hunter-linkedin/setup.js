import { cli } from '@jackwener/opencli/registry';
import fs from 'fs';
import path from 'path';
import os from 'os';
import readline from 'readline/promises';
import {
  isValidTier,
  normalizeTier,
  TIER_KEYS,
  getTierLabel,
} from './lib/index.js';
import {
  loadHunterConfig,
  saveHunterConfig,
  setLinkedInTier,
  setLinkedInConfig,
} from './lib/index.js';
import { detectTierFromSession } from './lib/index.js';

function ensureConfigDir() {
  const dir = path.join(os.homedir(), '.hunter');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

async function askQuestion(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    return await rl.question(question);
  } finally {
    rl.close();
  }
}

async function promptTier(defaultTier = null) {
  console.log('\n请选择 LinkedIn 账号档位：');
  TIER_KEYS.forEach((key, i) => {
    const marker = key === defaultTier ? ' (检测推荐)' : '';
    console.log(`  ${i + 1}. ${getTierLabel(key)}${marker}`);
  });

  const answer = await askQuestion(defaultTier ? `请输入序号 [默认: ${getTierLabel(defaultTier)}]: ` : '请输入序号: ');
  if (!answer && defaultTier) return defaultTier;

  const index = parseInt(answer.trim(), 10) - 1;
  if (index >= 0 && index < TIER_KEYS.length) {
    return TIER_KEYS[index];
  }

  console.log('❌ 无效选择');
  return null;
}

async function confirmTier(detectedTier) {
  const answer = await askQuestion(`检测到可能是「${getTierLabel(detectedTier)}」，是否确认？(y/n) `);
  return /^y/i.test(answer.trim());
}

cli({
  site: 'hunter-linkedin',
  name: 'setup',
  access: 'write',
  description: '配置 LinkedIn 寻访工具（账号档位 / 首选发现路径）',
  domain: 'www.linkedin.com',
  args: [
    { name: 'tier', type: 'string', default: '', description: 'LinkedIn 账号档位: free | premium_career | premium_business | sales_navigator | recruiter_lite | recruiter_corporate | rps' },
    { name: 'preferredDiscovery', type: 'string', default: '', description: '首选发现路径: browser | xray' },
  ],
  func: async (page, kwargs) => {
    console.log('='.repeat(60));
    console.log('🔧 LinkedIn 寻访配置');
    console.log('='.repeat(60));

    ensureConfigDir();
    let config = loadHunterConfig();

    // 配置 LinkedIn 账号档位
    let tierUpdated = false;
    if (kwargs.tier) {
      const normalized = normalizeTier(kwargs.tier);
      if (!isValidTier(normalized)) {
        console.log(`\n❌ 无效的 tier: ${kwargs.tier}`);
        console.log(`   可选值: ${TIER_KEYS.join(', ')}`);
        return { success: false };
      }
      config = setLinkedInTier(config, normalized, {
        preferredDiscovery: kwargs.preferredDiscovery || undefined,
      });
      saveHunterConfig(config);
      console.log(`\n✅ LinkedIn 账号档位设置为: ${getTierLabel(config.linkedin.tier)}`);
      tierUpdated = true;
    } else if (!config.linkedin?.tierConfirmedAt) {
      // 未确认过时尝试自动检测或交互选择
      const detected = await detectTierFromSession(page);
      let chosenTier = null;

      if (detected) {
        console.log(`\n🔍 检测到 LinkedIn 登录态`);
        const confirmed = await confirmTier(detected);
        chosenTier = confirmed ? detected : await promptTier(detected);
      } else {
        console.log('\n⚠️ 未检测到 LinkedIn 登录态，请手动选择账号档位');
        chosenTier = await promptTier();
      }

      if (chosenTier) {
        config = setLinkedInTier(config, chosenTier, {
          preferredDiscovery: kwargs.preferredDiscovery || undefined,
        });
        saveHunterConfig(config);
        console.log(`\n✅ LinkedIn 账号档位设置为: ${getTierLabel(config.linkedin.tier)}`);
        tierUpdated = true;
      }
    } else if (kwargs.preferredDiscovery) {
      const valid = ['browser', 'xray'].includes(kwargs.preferredDiscovery);
      if (!valid) {
        console.log('\n❌ 无效的 preferredDiscovery，请选择: browser | xray');
        return { success: false };
      }
      config = setLinkedInConfig(config, { preferredDiscovery: kwargs.preferredDiscovery });
      saveHunterConfig(config);
      console.log(`\n✅ 首选发现路径设置为: ${kwargs.preferredDiscovery}`);
    }

    // 显示当前配置
    console.log('\n📋 当前配置:');
    console.log(`  LinkedIn 档位: ${getTierLabel(config.linkedin?.tier || 'free')} (${config.linkedin?.tier || 'free'})`);
    console.log(`  首选发现路径: ${config.linkedin?.preferredDiscovery || 'browser'}`);
    if (config.linkedin?.tierConfirmedAt) {
      console.log(`  档位确认时间: ${config.linkedin.tierConfirmedAt}`);
    }

    console.log('\n💡 使用说明:');
    console.log('  opencli hunter linkedin-scout --keyword "AI Engineer" --limit 50');
    console.log('  opencli hunter linkedin-xray --keyword "AI Engineer" --location Shanghai --limit 10');

    return { success: true, config, tierUpdated };
  }
});
