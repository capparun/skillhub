# liepin 0.1.0 — 搜索能力初版

Strategy: UI_SELECTOR / DOM_STATE。Contract: visible-ui。
证据：工作区 docs/liepin-search-discovery.md 记录了页面控件和结果卡片。
授权来自用户现有登录浏览器。无私有 API 重放，不访问简历详情。

安装：从 csk 根目录执行 `opencli plugin install file://$PWD/hunter/packages/liepin`。

命令：

- `opencli liepin conditions`：离线列出字段。
- `opencli liepin diagnose`：只读检查当前页加载状态和控件，不导航、不点击。
- `opencli liepin prepare 电机结构工程师 --city 深圳 --keep-tab true`：设置并校验条件，不提交搜索。
- `opencli liepin search 电机结构工程师 --city 深圳 --education 本科 --limit 5 --keep-tab true`：逐项校验后提交一次。
- `opencli liepin results --limit 10`：只读已有结果。

`prepare` 和 `search` 默认使用单命令会话，在一次命令内完成导航、逐项设置、回读校验
和最多一次提交，规避 1.8.8 的 persistent write 会话偶发 `about:blank` 问题。需要保留
页面供人工查看时传 `--keep-tab true`。页面异常、验证提示或条件未确认时停止，不自动
重新搜索。

参数名以 `conditions` 输出为准，使用页面原文作为值，薪资单位为万元/年。
支持关键词与匹配方式、公司职位、当前/期望城市、工作年限、学历、院校类型、
统招要求、当前/期望行业职位、活跃度、语言、跳槽频率、毕业院校、专业名称、
求职状态、简历语言、当前/期望薪资上下限、年龄上下限（整数岁）、性别、
海外工作和管理经历。当前每个字段单值；不支持任意多选组合。

当前/期望城市不限于行内热门城市：非热门城市自动走"其他"弹层搜索联想
（如 `--city 佛山`）；重名城市可用"省份·城市"精确指定（如
`--expectedCity 广东·佛山`，间隔号 `·`/`・`/`•` 均可）。弹层本身支持
最多 9 城多选，CLI 当前仍只暴露单值。

每次先清空页面旧筛选，然后应用指定条件。发生验证失败时页面可能保留部分新条件，
但不会提交。复杂联想控件必须出现唯一候选并能读回选中值，否则停止。

输出总数保留页面原文（如 3000+），pageCount 是当前页卡片数。
翻页由 `--pages N`（1–10，默认 1）显式控制：逐页点击一次"下一页"，页间停顿，
页码或内容未前进即停并保留已读数据（warning 字段注明原因），不自动重试。
每行带 page 页码；limit 是每页读取条数。
摘要不推断隐藏字段；结果可能含页面上的个人信息，不自动落盘。

搜索结果行默认附带简历标识：提交前挂被动网络捕获（`Network` 域，只监听响应、
不发额外请求），从 `search-resumes` 接口响应按卡片顺序提取 `resumeId`
（resIdEncode）、`resumeUserId`（usercIdEncode）和完整 `detailUrl`，用脱敏姓名
做行对齐校验，对不上的行不带 ID。不提取接口里返回的未脱敏真名等字段。
可用 `--capture false` 关闭。除 DOM 摘要字段外，捕获开启时每行还富化列表接口返回的
展示字段：age、gender、company（卡片高亮公司，可能为过往雇主）、jobTitle、
workHistory（职位/公司/起止）、educationHistory（学校/专业/学位/起止）、
resumeUpdatedAt、lastLoginAt、online、hasAttachResume、fullTimeEdu。resumeId 已验证可跨会话持久使用：
`https://h.liepin.com/resume/showresumedetail/?res_id_encode=<resumeId>` 即稳定详情入口
（sss/ck_id 等为追踪参数，过期不影响访问）。

2026-09-09 已在真实登录页面逐项验收全部 27 个筛选条件、30 个 CLI 参数（prepare 不提交）：
关键词、匹配方式、职位/公司名称、当前/期望城市、工作年限、教育经历、院校要求、
统招要求、当前/期望行业、当前/期望职位、活跃度、语言、跳槽频率、毕业院校、
专业名称、求职状态、简历语言、目前/期望年薪上下限、年龄上下限、性别、
海外工作经验、管理经验。行业与职位类联想按选项主名匹配（如 `--industry 互联网`
而非整段面包屑）；求职状态等含全角标点的值可用半角逗号输入（如
`--jobStatus 在职,看看新机会`）。非热门城市经"其他"弹层联想验收
（`--city 佛山`、`--expectedCity 无锡`、`--expectedCity 广东·佛山`）。
当天并完成一次”电机结构工程师 + 深圳 + 本科”
真实搜索；页面返回 3000+ 人选，当前页识别 30 张卡片，命令按 limit 返回前 5 条。
