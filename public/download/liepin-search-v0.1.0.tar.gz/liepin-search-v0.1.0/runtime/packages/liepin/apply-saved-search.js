import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError, AuthRequiredError, CommandExecutionError } from '@jackwener/opencli/errors';
import { applySavedSearch } from './lib/records.js';
import { inspect } from './lib/dom.js';

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
cli({
  site: 'liepin', access: 'write', name: 'apply-saved-search',
  description: '应用一个猎聘已保存条件并执行平台的一次搜索',
  domain: 'h.liepin.com', navigateBefore: 'https://h.liepin.com/search/getConditionItem',
  browser: true, strategy: Strategy.UI, siteSession: 'ephemeral',
  args: [
    { name: 'name', type: 'string', positional: true, required: true, help: '已有方案名称' },
    { name: 'limit', type: 'int', default: 10, help: '读取当前页前 1–30 条' },
  ],
  columns: ['rank', 'name', 'experience', 'education', 'city', 'expectation', 'skills', 'status', 'total', 'pageCount'],
  func: async (page, args) => {
    const name = String(args.name ?? '').trim();
    const limit = Number(args.limit);
    if (!name) throw new ArgumentError('name 不能为空');
    if (!Number.isInteger(limit) || limit < 1 || limit > 30) throw new ArgumentError('limit 必须为 1–30');
    try {
      await applySavedSearch(page, name);
      let result;
      for (let attempt = 0; attempt < 8; attempt++) {
        result = await page.evaluate(inspect, { mode: 'results', limit });
        if (result.login) throw new AuthRequiredError('h.liepin.com', '猎聘登录已失效');
        if (result.risk) throw new CommandExecutionError('页面出现风险提示；已停止且不会重试');
        if (!result.blank && !result.loading && (result.count || result.empty)) break;
        await wait(500);
      }
      if (!result || result.blank || result.loading || (!result.count && !result.empty)) throw new Error('应用方案后的搜索结果无法确认；不会再次点击方案');
      return result.rows.map((candidate, index) => ({
        rank: index + 1, name: candidate.name, experience: candidate.experience,
        education: candidate.education, city: candidate.city, expectation: candidate.expectation,
        skills: candidate.skills, status: candidate.status, total: result.total, pageCount: result.count,
      }));
    } catch (error) {
      if (error instanceof AuthRequiredError || error instanceof CommandExecutionError) throw error;
      throw new CommandExecutionError(error.message);
    }
  },
});
