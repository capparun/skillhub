import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError, AuthRequiredError, CommandExecutionError } from '@jackwener/opencli/errors';
import { deleteSavedSearch } from './lib/records.js';

cli({
  site: 'liepin', access: 'write', name: 'delete-saved-search',
  description: '删除一个唯一匹配的猎聘已保存搜索条件',
  domain: 'h.liepin.com', navigateBefore: 'https://h.liepin.com/search/getConditionItem',
  browser: true, strategy: Strategy.UI, siteSession: 'ephemeral',
  args: [{ name: 'name', type: 'string', positional: true, required: true, help: '已有方案名称' }],
  columns: ['name', 'deleted'],
  func: async (page, args) => {
    const name = String(args.name ?? '').trim();
    if (!name) throw new ArgumentError('name 不能为空');
    try { return [await deleteSavedSearch(page, name)]; }
    catch (error) {
      if (/登录/.test(error.message)) throw new AuthRequiredError('h.liepin.com', error.message);
      throw new CommandExecutionError(error.message);
    }
  },
});
