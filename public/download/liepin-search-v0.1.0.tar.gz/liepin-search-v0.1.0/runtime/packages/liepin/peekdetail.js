import { cli, Strategy } from '@jackwener/opencli/registry';

// 一次性验证工具:从首页推荐列表点击一张卡片,回报新标签页 URL 与网络捕获,
// 用于验证 resIdEncode 与详情 URL 的对应关系。验证完成后应移除本文件
// (插件发现机制会注册所有顶层 .js,不要把它留给正式分发)。
cli({
  site: 'liepin',
  access: 'write',
  name: 'peekdetail',
  description: '验证用:从首页推荐列表点开一张卡片,只点一次,回报详情页 URL',
  domain: 'h.liepin.com',
  navigateBefore: 'https://h.liepin.com/',
  strategy: Strategy.UI,
  browser: true,
  siteSession: 'ephemeral',
  args: [
    { name: 'index', type: 'int', default: 0, help: '点击第几张可见卡片(0 起)' },
    { name: 'open', type: 'string', help: '验证用:直接打开指定详情 URL(跳过列表点击),回报页面结构标记' },
    { name: 'clickText', type: 'string', help: '配合 open:打开后点击页面上精确匹配的可见文本,回报指定容器 HTML' },
    { name: 'clickText2', type: 'string', help: '配合 clickText:第一次点击后再点一个文本(如弹层里的省份),二次抓取' },
    { name: 'fillText', type: 'string', help: '配合 clickText:点击后向 fillSelector 填充文本,再抓取(验证弹层内搜索联想)' },
    { name: 'fillSelector', type: 'string', help: '配合 fillText:要填充的输入框选择器' },
    { name: 'clickMore', type: 'string', help: '配合 fillText:填充后依次点击的文本,逗号分隔,最后抓取一次' },
    { name: 'watchSelector', type: 'string', help: '配合 clickText:点击后抓取的容器选择器,逗号分隔' },
  ],
  columns: ['clicked', 'cardName', 'cardCount', 'currentUrl', 'tabs', 'capturedIds', 'riskSignals', 'openResult'],
  func: async (page, args) => {
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    const riskPatterns = ['验证码', '访问过于频繁', '操作频繁', '安全验证', '异常访问', '账号异常'];
    // --open 模式:验证指定详情 URL 在新会话里的可达性,不输出候选人内容
    if (args.open) {
      await page.goto(args.open);
      await sleep(3000);
      // 可选:点击一个精确文本的可见元素(如城市行的"其他"),再抓容器结构
      let clickEvidence = null;
      const captureContainers = selectors => page.evaluate(sels => {
        const out = {};
        for (const sel of sels) {
          const el = document.querySelector(sel);
          out[sel] = el ? el.outerHTML.slice(0, 12000) : null;
        }
        // 兜底扫描:所有类名含 city 的可见元素,找真正的弹层
        out.__cityScan = [...document.querySelectorAll('[class*=city], [class*=City]')]
          .filter(e => e.getClientRects().length > 0 && (e.textContent ?? '').trim())
          .slice(0, 8).map(e => ({ className: String(e.className).slice(0, 120), text: (e.textContent ?? '').replace(/\s+/g, '').slice(0, 100), html: e.outerHTML.slice(0, 400) }));
        return out;
      }, selectors);
      const clickLeafText = async text => {
        const found = await page.evaluate(t => {
          const norm = v => (v ?? '').replace(/\s+/g, '');
          for (const e of document.querySelectorAll('[data-opencli-click]')) e.removeAttribute('data-opencli-click');
          const el = [...document.querySelectorAll('span, label, div, a, li')]
            .find(e => e.getClientRects().length > 0 && norm(e.textContent) === norm(t)
              && ![...e.children].some(c => norm(c.textContent) === norm(t)));
          if (!el) return false;
          el.setAttribute('data-opencli-click', '1');
          return true;
        }, text);
        if (!found) return false;
        await page.click('[data-opencli-click="1"]');
        await sleep(1200);
        return true;
      };
      if (args.clickText) {
        const selectors = String(args.watchSelector ?? '.antd-lp-city').split(',');
        if (await clickLeafText(args.clickText)) {
          clickEvidence = await captureContainers(selectors);
          if (args.clickText2) {
            const found2 = await clickLeafText(args.clickText2);
            clickEvidence.__click2 = found2 ? await captureContainers(selectors) : { notFound: args.clickText2 };
          }
          if (args.fillText && args.fillSelector) {
            const hasInput = await page.evaluate(sel => !!document.querySelector(sel), args.fillSelector).catch(() => false);
            if (hasInput) {
              await page.click(args.fillSelector);
              await sleep(300);
              await page.fillText(args.fillSelector, args.fillText);
              await sleep(1600);
              clickEvidence.__fill = await captureContainers(selectors);
              clickEvidence.__fill.__suggestScan = await page.evaluate(() => {
                const norm = v => (v ?? '').replace(/\s+/g, '');
                return [...document.querySelectorAll('.city-modal [class*=suggest], .city-modal [class*=result], .city-modal li, .city-modal .hide')]
                  .filter(e => e.getClientRects().length > 0 && norm(e.textContent))
                  .slice(0, 10).map(e => ({ className: String(e.className).slice(0, 100), text: norm(e.textContent).slice(0, 60), html: e.outerHTML.slice(0, 300) }));
              }).catch(() => []);
            } else {
              clickEvidence.__fill = { notFound: args.fillSelector };
            }
          }
          if (args.clickMore) {
            const results = [];
            for (const text of String(args.clickMore).split(',')) {
              results.push({ text, clicked: await clickLeafText(text) });
              if (!results[results.length - 1].clicked) break;
            }
            clickEvidence.__clickMore = { results, containers: await captureContainers(selectors) };
          }
        } else {
          clickEvidence = { notFound: args.clickText };
        }
      }
      const state = await page.evaluate(patterns => {
        const text = document.body?.innerText ?? '';
        return {
          finalUrl: location.href,
          title: document.title,
          textLength: text.trim().length,
          // 结构标记:详情页该有的板块词,不含个人信息
          markers: ['工作经历', '教育经历', '项目经历', '立即沟通', '打招呼', '期望职位'].filter(w => text.includes(w)),
          risk: patterns.filter(p => text.includes(p)),
          login: /请登录|扫码登录/.test(text),
          notFound: /不存在|已下架|页面走丢|404/.test(text),
        };
      }, riskPatterns);
      return [{ clicked: !!clickEvidence, cardName: null, cardCount: 0, currentUrl: clickEvidence ? { clickEvidence } : null, tabs: [], capturedIds: [], riskSignals: state.risk, openResult: state }];
    }
    const index = Number(args.index ?? 0);
    await page.startNetworkCapture?.('api-h.liepin.com').catch(() => false);
    await sleep(2500);
    const mark = await page.evaluate(i => {
      const cards = [...document.querySelectorAll('.tlog-common-resume-card')]
        .filter(el => el.getClientRects().length > 0);
      const card = cards[i];
      if (!card) return { marked: false, count: cards.length };
      // 拦截导航:记录点击想打开的 URL,但不真正打开详情页(零详情页加载)。
      window.__openedUrls = [];
      window.open = (...a) => { window.__openedUrls.push(`open:${a[0]}`); return null; };
      try { location.assign = url => { window.__openedUrls.push(`assign:${url}`); }; } catch { /* 只读则跳过 */ }
      const wrapHistory = fnName => {
        const orig = history[fnName].bind(history);
        history[fnName] = (s, t, url) => { if (url) window.__openedUrls.push(`${fnName}:${url}`); return orig(s, t, url); };
      };
      wrapHistory('pushState');
      wrapHistory('replaceState');
      const target = card.querySelector('.new-resume-personal-name') ?? card;
      target.setAttribute('data-opencli-click', '1');
      return {
        marked: true,
        count: cards.length,
        name: card.querySelector('.new-resume-personal-name')?.textContent?.trim() ?? null,
        clickedTag: target.tagName,
        text: document.body?.innerText ?? '',
      };
    }, index);
    if (!mark.marked) return [{ clicked: false, cardName: null, cardCount: mark.count, tabs: [], currentUrl: null, capturedIds: [], riskSignals: ['no-card'] }];
    const risk = riskPatterns.filter(p => mark.text.includes(p));
    if (risk.length) return [{ clicked: false, cardName: mark.name, cardCount: mark.count, tabs: [], currentUrl: null, capturedIds: [], riskSignals: risk }];
    await page.click('[data-opencli-click="1"]');
    await sleep(2500);
    const after = await page.evaluate(() => ({ url: location.href, title: document.title, openedUrls: window.__openedUrls ?? [] })).catch(() => null);
    const tabs = await page.tabs().catch(() => []);
    const captures = await page.readNetworkCapture?.().catch(() => []) ?? [];
    // 只提取 ID 字段,不回传候选人内容
    const capturedIds = [];
    for (const c of captures) {
      if (typeof c?.responsePreview !== 'string') continue;
      try {
        const data = JSON.parse(c.responsePreview)?.data;
        const list = data?.resList ?? data?.recList ?? [];
        for (const item of list.slice(0, 30)) {
          capturedIds.push({
            resIdEncode: item.simpleResumeForm?.resIdEncode ?? item.resIdEncode ?? null,
            resName: item.simpleResumeForm?.resName ?? null,
            detailUrl: item.detailUrl ?? null,
          });
        }
      } catch { /* 非 JSON 响应忽略 */ }
    }
    return [{
      clicked: true,
      cardName: mark.name,
      cardCount: mark.count,
      currentUrl: after,
      tabs: (Array.isArray(tabs) ? tabs : []).map(t => ({ id: t?.id, url: t?.url, title: t?.title, active: t?.active })),
      capturedIds,
      riskSignals: [],
    }];
  },
});
