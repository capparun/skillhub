import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError, AuthRequiredError, CommandExecutionError } from '@jackwener/opencli/errors';
import { filters } from './lib/filters.js';
import { run } from './lib/engine.js';

cli({
  site: 'liepin',
  access: 'write',
  name: 'prepare',
  description: '清空并设置猎聘筛选条件，但不点击搜索',
  domain: 'h.liepin.com',
  navigateBefore: 'https://h.liepin.com/search/getConditionItem',
  strategy: Strategy.UI,
  browser: true,
  siteSession: 'ephemeral',
  args: Object.entries(filters).map(([name, [label, kind]]) => ({
    name,
    type: kind === 'check' ? 'boolean' : 'string',
    positional: name === 'keyword',
    help: label,
  })),
  columns: ['field', 'value'],
  func: async (page, args) => {
    try {
      const result = await run(page, args, { submit: false });
      return result.applied;
    }
    catch (error) {
      if (error.code === 'ARGUMENT') throw new ArgumentError(error.message);
      if (error.code === 'AUTH') throw new AuthRequiredError('h.liepin.com', error.message);
      throw new CommandExecutionError(error.message);
    }
  },
});
