import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError, AuthRequiredError, CommandExecutionError, EmptyResultError } from '@jackwener/opencli/errors';
import { inspect } from './lib/dom.js';
cli({ site: 'liepin', access: 'read', name: 'results', description: '只读取当前搜索结果，不导航、不提交、不翻页', domain: 'h.liepin.com', browser: true, strategy: Strategy.UI, siteSession: 'persistent',
  args: [{ name: 'limit', type: 'int', default: 10, help: '1–30 条' }], columns: ['rank', 'name', 'experience', 'education', 'city', 'expectation', 'skills', 'status', 'total', 'pageCount'],
  func: async (page, args) => {
    const limit = Number(args.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > 30) throw new ArgumentError('limit 必须为 1–30');
    const result = await page.evaluate(inspect, { mode: 'results', limit });
    if (result.login) throw new AuthRequiredError('h.liepin.com', '猎聘登录已失效');
    if (!result.url.startsWith('https://h.liepin.com/search/getConditionItem') || result.risk || result.blank || result.loading || (!result.count && !result.empty)) throw new CommandExecutionError('当前不是已确认的猎聘结果页；停止读取');
    if (!result.rows.length) throw new EmptyResultError('liepin results', '当前结果页没有候选人');
    return result.rows.map((candidate, index) => ({ rank: index + 1, name: candidate.name, experience: candidate.experience, education: candidate.education, city: candidate.city, expectation: candidate.expectation, skills: candidate.skills, status: candidate.status, total: result.total, pageCount: result.count }));
  },
});
