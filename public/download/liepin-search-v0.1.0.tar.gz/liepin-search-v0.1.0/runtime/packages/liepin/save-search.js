import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError, AuthRequiredError, CommandExecutionError } from '@jackwener/opencli/errors';
import { filters } from './lib/filters.js';
import { run } from './lib/engine.js';
import { saveSearchPlan } from './lib/records.js';

const filterArgs = Object.entries(filters).map(([name, [label, kind]]) => ({
  name, type: kind === 'check' ? 'boolean' : 'string', positional: false, help: label,
}));

cli({
  site: 'liepin', access: 'write', name: 'save-search',
  description: '设置并校验筛选条件，然后保存为猎聘平台搜索方案',
  domain: 'h.liepin.com', navigateBefore: 'https://h.liepin.com/search/getConditionItem',
  browser: true, strategy: Strategy.UI, siteSession: 'ephemeral',
  args: [{ name: 'name', type: 'string', positional: true, required: true, help: '方案名称' }, ...filterArgs],
  columns: ['name', 'saved', 'conditionCount'],
  func: async (page, args) => {
    const name = String(args.name ?? '').trim();
    if (!name) throw new ArgumentError('name 不能为空');
    if (name.length > 10) throw new ArgumentError('name 不能超过 10 个字符');
    const filterValues = Object.fromEntries(Object.keys(filters).filter(key => args[key] !== undefined).map(key => [key, args[key]]));
    if (!Object.keys(filterValues).length) throw new ArgumentError('至少指定一个搜索条件');
    try {
      const prepared = await run(page, filterValues, { submit: false });
      await saveSearchPlan(page, name);
      return [{ name, saved: true, conditionCount: prepared.applied.length }];
    } catch (error) {
      if (error.code === 'ARGUMENT') throw new ArgumentError(error.message);
      if (error.code === 'AUTH') throw new AuthRequiredError('h.liepin.com', error.message);
      throw new CommandExecutionError(error.message);
    }
  },
});
