import { cli, Strategy } from '@jackwener/opencli/registry';
import { AuthRequiredError, CommandExecutionError, EmptyResultError } from '@jackwener/opencli/errors';
import { readSavedSearches } from './lib/records.js';

cli({
  site: 'liepin', access: 'read', name: 'saved-searches',
  description: '列出猎聘平台已保存的搜索条件方案',
  domain: 'h.liepin.com', navigateBefore: 'https://h.liepin.com/search/getConditionItem',
  browser: true, strategy: Strategy.UI, siteSession: 'ephemeral',
  columns: ['name', 'subscribed'],
  func: async page => {
    const state = await readSavedSearches(page);
    if (state.login) throw new AuthRequiredError('h.liepin.com', '猎聘登录已失效');
    if (state.blank || !state.url.startsWith('https://h.liepin.com/search/getConditionItem')) {
      throw new CommandExecutionError('未进入猎聘搜索条件页');
    }
    if (!state.schemes.length) throw new EmptyResultError('liepin saved-searches', '平台当前没有可见的已保存条件');
    return state.schemes.map(({ name, subscribed }) => ({ name, subscribed }));
  },
});
