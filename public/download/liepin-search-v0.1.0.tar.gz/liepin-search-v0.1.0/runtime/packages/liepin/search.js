import { cli, Strategy } from '@jackwener/opencli/registry';
import { ArgumentError, AuthRequiredError, CommandExecutionError, EmptyResultError, TimeoutError } from '@jackwener/opencli/errors';
import { filters } from './lib/filters.js';
import { run } from './lib/engine.js';
cli({
  site: 'liepin', access: 'write', name: 'search', description: '在现有猎聘搜索页设置筛选并提交一次；失败停止',
  domain: 'h.liepin.com', navigateBefore: 'https://h.liepin.com/search/getConditionItem', strategy: Strategy.UI, browser: true, siteSession: 'ephemeral',
  args: [...Object.entries(filters).map(([name, [label, kind]]) => ({ name, type: kind === 'check' ? 'boolean' : 'string', positional: name === 'keyword', help: label })),
    { name: 'limit', type: 'int', default: 10, help: '每页最多读取 1–30 条' },
    { name: 'pages', type: 'int', default: 1, help: '读取页数 1–10(默认 1 不翻页);逐页点击下一页,翻不动即停并保留已读数据' },
    { name: 'capture', type: 'boolean', default: true, help: '被动捕获搜索接口响应以提取简历 ID(默认开,不发额外请求)' }],
  columns: ['rank', 'page', 'name', 'age', 'gender', 'experience', 'education', 'city', 'company', 'jobTitle', 'expectation', 'skills', 'status', 'online', 'lastLoginAt', 'resumeUpdatedAt', 'fullTimeEdu', 'hasAttachResume', 'workHistory', 'educationHistory', 'total', 'pageCount', 'pages', 'warning', 'resumeId', 'resumeUserId', 'detailUrl'],
  func: async (page, args) => {
    try {
      const result = await run(page, args, { capture: args.capture !== false });
      if (!result.rows.length) throw new EmptyResultError('liepin search', '筛选有效，但当前页没有候选人');
      return result.rows.map((candidate, index) => ({
        rank: index + 1,
        page: candidate.page ?? 1,
        name: candidate.name,
        age: candidate.age ?? null,
        gender: candidate.gender ?? null,
        experience: candidate.experience,
        education: candidate.education,
        city: candidate.city,
        company: candidate.company ?? null,
        jobTitle: candidate.jobTitle ?? null,
        expectation: candidate.expectation,
        skills: candidate.skills,
        status: candidate.status,
        online: candidate.online ?? null,
        lastLoginAt: candidate.lastLoginAt ?? null,
        resumeUpdatedAt: candidate.resumeUpdatedAt ?? null,
        fullTimeEdu: candidate.fullTimeEdu ?? null,
        hasAttachResume: candidate.hasAttachResume ?? null,
        workHistory: candidate.workHistory ?? [],
        educationHistory: candidate.educationHistory ?? [],
        total: result.total,
        pageCount: result.pageCount,
        pages: result.pages,
        warning: result.warning ?? null,
        resumeId: candidate.resumeId ?? null,
        resumeUserId: candidate.resumeUserId ?? null,
        detailUrl: candidate.detailUrl ?? null,
      }));
    }
    catch (error) {
      if (error instanceof EmptyResultError) throw error;
      if (error.code === 'ARGUMENT') throw new ArgumentError(error.message);
      if (error.code === 'AUTH') throw new AuthRequiredError('h.liepin.com', error.message);
      if (error.code === 'TIMEOUT') throw new TimeoutError('猎聘搜索结果（不重试）', 10);
      throw new CommandExecutionError(error.message);
    }
  },
});
