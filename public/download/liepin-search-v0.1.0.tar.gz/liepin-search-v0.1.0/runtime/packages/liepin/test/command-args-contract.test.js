import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getRegistry } from '@jackwener/opencli/registry';
import { filters } from '../lib/filters.js';

const root = path.dirname(fileURLToPath(new URL('../package.json', import.meta.url)));

const filterKeys = Object.keys(filters);
// filterKeys = keyword, match, title, company, city, expectedCity, experience, education,
//   schoolTier, fullTime, industry, position, expectedIndustry, expectedPosition,
//   activity, language, jobChanges, school, major, jobStatus, resumeLanguage,
//   salaryMin, salaryMax, expectedSalaryMin, expectedSalaryMax, ageMin, ageMax,
//   gender, overseas, management  (30 keys)

// Public CLI contract. Any added, removed, or renamed parameter must update this
// snapshot and receive a behavioral test in the command-specific test file.
const expected = {
  'apply-saved-search': ['name', 'limit'],
  'conditions': [],
  'delete-saved-search': ['name'],
  'diagnose': ['probe', 'probeValue'],
  'peekdetail': ['index', 'open', 'clickText', 'clickText2', 'fillText', 'fillSelector', 'clickMore', 'watchSelector'],
  'prepare': [...filterKeys],
  'results': ['limit'],
  'save-search': ['name', ...filterKeys],
  'saved-searches': [],
  'search': [...filterKeys, 'limit', 'pages', 'capture'],
};

const required = new Set(['save-search.name', 'apply-saved-search.name', 'delete-saved-search.name']);
const positional = new Set([
  'search.keyword',
  'prepare.keyword',
  'save-search.name',
  'apply-saved-search.name',
  'delete-saved-search.name',
]);

test('liepin command contract: all 10 commands registered with correct args', async () => {
  // Discover all registered commands by scanning root .js files for site declarations.
  const discovered = [];
  for (const file of fs.readdirSync(root).filter(file => file.endsWith('.js'))) {
    const source = fs.readFileSync(path.join(root, file), 'utf8');
    if (!source.includes("site: 'liepin'")) continue;
    const name = source.match(/\bname:\s*'([^']+)'/)?.[1];
    assert.ok(name, `${file} must register a command name`);
    discovered.push(name);
  }
  discovered.sort();
  const expectedNames = Object.keys(expected).sort();
  assert.deepEqual(discovered, expectedNames, 'discovered commands must match expected contract keys');

  // Import all commands to trigger real OpenCLI registry registration.
  for (const command of Object.keys(expected)) {
    await import(new URL(`../${command}.js`, import.meta.url));
  }

  for (const [commandName, argNames] of Object.entries(expected)) {
    const command = getRegistry().get(`liepin/${commandName}`);
    assert.ok(command, `${commandName} must be registered in the real OpenCLI registry`);
    assert.deepEqual(command.args.map(arg => arg.name), argNames, `${commandName} real args must match the contract`);
    for (const arg of command.args) {
      const key = `${commandName}.${arg.name}`;
      assert.ok(['string', 'int', 'boolean'].includes(arg.type), `${key} has a supported parser type`);
      // liepin uses `help:` not `description:`
      assert.ok(arg.help?.trim(), `${key} exposes help text`);
      assert.equal(Boolean(arg.required), required.has(key), `${key} required flag is intentional`);
      assert.equal(Boolean(arg.positional), positional.has(key), `${key} positional flag is intentional`);
      // liepin convention: optional args may omit default — only verify required/positional flags
    }
  }
});

test('liepin filter keys are stable (30 filter definitions)', () => {
  assert.equal(filterKeys.length, 30, 'filters.js must export exactly 30 filter definitions');
});
