import test from 'node:test';
import assert from 'node:assert/strict';
import { plan } from '../lib/filters.js';
import { run } from '../lib/engine.js';
import { applySavedSearch, deleteSavedSearch, saveSearchPlan } from '../lib/records.js';
const url = 'https://h.liepin.com/search/getConditionItem';
test('validates all inputs before browser access', async () => {
  for (const args of [{}, { keyword: '' }, { keyword: 'a', limit: 31 }, { keyword: 'a', pages: 0 }, { keyword: 'a', pages: 11 }, { salaryMin: 20, salaryMax: 10 }, { overseas: 'false' }, { unknown: 'x' },
    { ageMin: -1 }, { ageMin: '25.5' }, { ageMin: 'abc' }, { ageMin: 40, ageMax: 25 }, { gender: '' }]) {
    await assert.rejects(run({ evaluate() { assert.fail('browser touched'); } }, args), { code: 'ARGUMENT' });
  }
});
test('age range accepts non-negative integers and keeps zero', () => {
  const steps = plan({ ageMin: 0, ageMax: 40 }).steps;
  assert.deepEqual(steps.map(s => [s.key, s.kind, s.selector, s.value]), [
    ['ageMin', 'age', '#ageLow', '0'],
    ['ageMax', 'age', '#ageHigh', '40'],
  ]);
});
test('saves a search plan once and verifies it from the visible scheme list', async () => {
  const states = [
    { saveButton: '#save', schemes: [] },
    { dialog: { input: '#name', confirm: '#confirm' }, schemes: [] },
    { schemes: [{ name: '深圳电机' }] },
  ];
  const actions = [];
  const page = {
    async evaluate() { return states.shift(); },
    async click(selector) { actions.push(['click', selector]); },
    async fillText(selector, value) { actions.push(['fill', selector, value]); },
  };
  await saveSearchPlan(page, '深圳电机', { pause: async () => {} });
  assert.deepEqual(actions, [['click', '#save'], ['fill', '#name', '深圳电机'], ['click', '#confirm']]);
});
test('does not retry when saved search verification is uncertain', async () => {
  const states = [
    { saveButton: '#save', schemes: [] },
    { dialog: { input: '#name', confirm: '#confirm' }, schemes: [] },
    { schemes: [] },
  ];
  let confirms = 0;
  const page = {
    async evaluate() { return states.shift(); },
    async click(selector) { if (selector === '#confirm') confirms++; },
    async fillText() {},
  };
  await assert.rejects(saveSearchPlan(page, '深圳电机', { pause: async () => {} }), /不会自动重试/);
  assert.equal(confirms, 1);
});
test('applies one uniquely named saved search exactly once', async () => {
  const actions = [];
  const page = {
    async evaluate() { return { schemes: [{ name: '深圳电机', apply: '#apply' }] }; },
    async click(selector) { actions.push(selector); },
  };
  await applySavedSearch(page, '深圳电机', { pause: async () => {} });
  assert.deepEqual(actions, ['#apply']);
});
test('deletes one uniquely named saved search with one confirmation', async () => {
  const states = [
    { schemes: [{ name: '深圳电机', remove: '#remove' }] },
    { schemes: [{ name: '深圳电机' }], dialog: { text: '确定删除该搜索条件吗？', confirm: '#confirm' } },
    { schemes: [] },
  ];
  const actions = [];
  const page = {
    async evaluate() { return states.shift(); },
    async click(selector) { actions.push(selector); },
  };
  assert.deepEqual(await deleteSavedSearch(page, '深圳电机', { pause: async () => {} }), { name: '深圳电机', deleted: true });
  assert.deepEqual(actions, ['#remove', '#confirm']);
});
test('gender plans as a select filter without a hardcoded dynamic selector', () => {
  const [step] = plan({ gender: '男' }).steps;
  assert.deepEqual([step.label, step.kind, step.selector ?? null], ['性别', 'select', null]);
});
test('preserves numeric zero and explicit false', () => {
  assert.deepEqual(plan({ salaryMin: 0, overseas: false }).steps.map(s => s.value), ['0', 'false']);
});
test('accepts OpenCLI option provenance metadata but rejects other unknown keys', () => {
  assert.equal(plan({ keyword: '机械', __opencliOptionSources: { keyword: 'cli' } }).steps.length, 1);
  assert.throws(() => plan({ keyword: '机械', unknown: true }), /未知参数/);
});
function fake({ mismatch = false, risk = false, pending = false, blankReads = 0, reset = '#reset' } = {}) {
  const clicks = []; let value = ''; let reads = 0;
  return { clicks, async click(s) { clicks.push(s); }, async fillText(s,v) { value = v; }, async evaluate(fn, request) {
    const base = { url, risk, riskSignals: risk ? ['安全验证'] : [], blank: reads++ < blankReads, login: false };
    if (request.mode === 'controls') return { ...base, reset, submit: '#submit' };
    if (request.mode === 'results') return { ...base, count: pending ? 0 : 1, total: '3000+', rows: [{ name: '测试**' }] };
    return { ...base, target: '#keyword', value: mismatch ? '' : value };
  }};
}
test('one submission and separate page/total counts', async () => {
  const page = fake(); const result = await run(page, { keyword: '机械' }, { pause: async () => {} });
  assert.equal(page.clicks.filter(x => x === '#submit').length, 1);
  assert.equal(result.total, '3000+'); assert.equal(result.pageCount, 1); assert.equal(result.rows.length, 1);
});
test('prepare applies and verifies filters without submitting', async () => {
  const page = fake();
  const result = await run(page, { keyword: '机械' }, { pause: async () => {}, submit: false });
  assert.deepEqual(result.applied, [{ field: 'keyword', value: '机械' }]);
  assert.equal(page.clicks.includes('#submit'), false);
});
test('waits through a short blank render before touching controls', async () => {
  const page = fake({ blankReads: 2 });
  await run(page, { keyword: '机械' }, { pause: async () => {}, submit: false });
  assert.equal(page.clicks[0], '#reset');
});
test('does not require a reset control on a clean search page', async () => {
  const page = fake({ reset: null });
  await run(page, { keyword: '机械' }, { pause: async () => {}, submit: false });
  assert.equal(page.clicks.includes('#reset'), false);
});
test('failed verification never submits', async () => {
  const broken = fake({ mismatch: true }); await assert.rejects(run(broken, { keyword: '机械' }, { pause: async () => {} }), { code: 'VERIFY' });
  assert.equal(broken.clicks.includes('#submit'), false);
});
test('refreshes a choice selector after human-paced hover before clicking', async () => {
  let hovered = false; let selected = false;
  const page = {
    clicks: [],
    async hover(selector) { assert.equal(selector, '#before-hover'); hovered = true; },
    async click(selector) { this.clicks.push(selector); if (selector === '#after-hover') selected = true; },
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      return { ...base, choice: hovered ? '#after-hover' : '#before-hover', selected };
    },
  };
  const result = await run(page, { education: '本科' }, { pause: async () => {}, submit: false });
  assert.deepEqual(result.applied, [{ field: 'education', value: '本科' }]);
  assert.deepEqual(page.clicks, ['#after-hover']);
});
test('expands the panel when the choice exists but is clipped by the collapsed area', async () => {
  let expanded = false; let selected = false;
  const page = {
    clicks: [],
    async hover() {},
    async click(selector) {
      this.clicks.push(selector);
      if (selector === '#expand') expanded = true;
      if (selector === '#lang') selected = true;
    },
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      return {
        ...base,
        choice: '#lang',
        selected,
        expand: expanded ? null : '#expand',
        choiceEvidence: { hitRelation: expanded ? 'self' : 'ancestor' },
      };
    },
  };
  const result = await run(page, { language: '英语' }, { pause: async () => {}, submit: false });
  assert.equal(page.clicks[0], '#expand');
  assert.deepEqual(page.clicks, ['#expand', '#lang']);
  assert.deepEqual(result.applied, [{ field: 'language', value: '英语' }]);
});
test('closes a leftover dropdown with Escape before opening the next select', async () => {
  const keys = []; let escaped = false; const clicked = [];
  const page = {
    async pressKey(key) { keys.push(key); escaped = true; },
    async click(selector) { clicked.push(selector); },
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      return {
        ...base,
        target: '#activity',
        // Escape 前旧下拉仍可见;Escape 后收起,点击后展开并出现唯一候选
        dropdownCount: escaped ? (clicked.length ? 1 : 0) : 1,
        option: clicked.length ? '#opt' : null,
        dropdownOptions: clicked.length ? ['30天内活跃'] : [],
        committed: clicked.length >= 2,
      };
    },
  };
  const result = await run(page, { activity: '30天内活跃' }, { pause: async () => {}, submit: false });
  assert.deepEqual(keys, ['Escape']);
  assert.deepEqual(result.applied, [{ field: 'activity', value: '30天内活跃' }]);
});
test('pins the container path from the first read for later verification reads', async () => {
  const requests = []; let clicked = false;
  const page = {
    async click(selector) { clicked = true; },
    async evaluate(fn, request) {
      requests.push({ ...request });
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      return {
        ...base,
        target: '#sel',
        rootPath: '#row-jobchanges',
        dropdownCount: clicked ? 1 : 0,
        option: clicked ? '#opt' : null,
        committed: clicked && requests.filter(r => r.rootPath).length >= 1,
      };
    },
  };
  const result = await run(page, { jobChanges: '近5年不超过3段' }, { pause: async () => {}, submit: false });
  assert.deepEqual(result.applied, [{ field: 'jobChanges', value: '近5年不超过3段' }]);
  const stepReads = requests.filter(r => r.key === 'jobChanges');
  assert.equal(stepReads[0].rootPath, undefined);
  assert.ok(stepReads.slice(1).every(r => r.rootPath === '#row-jobchanges'));
});
test('expands the panel when a check control is clipped by the collapsed area', async () => {
  let expanded = false; let checked = false;
  const page = {
    clicks: [],
    async hover() {},
    async click(selector) {
      this.clicks.push(selector);
      if (selector === '#expand') expanded = true;
      if (selector === '#chk') checked = true;
    },
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      return {
        ...base,
        target: '#chk',
        checked,
        expand: expanded ? null : '#expand',
        targetEvidence: { hitRelation: expanded ? 'self' : 'ancestor' },
      };
    },
  };
  const result = await run(page, { overseas: true }, { pause: async () => {}, submit: false });
  assert.deepEqual(page.clicks, ['#expand', '#chk']);
  assert.deepEqual(result.applied, [{ field: 'overseas', value: 'true' }]);
});
test('paginates across pages with per-row page numbers and one submission', async () => {
  let pageNo = 1;
  const page = {
    value: '',
    clicks: [],
    async click(selector) { this.clicks.push(selector); if (selector === '#next') pageNo = 2; },
    async fillText(selector, v) { this.value = v; },
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      if (request.mode === 'results') return {
        ...base, loading: false, count: 1, empty: false, total: '60',
        pagination: { current: pageNo, next: pageNo === 1 ? '#next' : null, totalPages: 2 },
        rows: [{ name: pageNo === 1 ? '甲**' : '乙**', experience: `工作${pageNo}年` }],
      };
      return { ...base, target: '#keyword', value: this.value };
    },
  };
  const result = await run(page, { keyword: '前端', pages: 2, limit: 5 }, { pause: async () => {} });
  assert.equal(page.clicks.filter(x => x === '#submit').length, 1);
  assert.deepEqual(page.clicks.filter(x => x === '#next'), ['#next']);
  assert.equal(result.pages, 2);
  assert.deepEqual(result.rows.map(r => [r.name, r.page]), [['甲**', 1], ['乙**', 2]]);
});
test('stops pagination when the page does not advance and keeps what was read', async () => {
  const page = {
    value: '',
    clicks: [],
    async click(selector) { this.clicks.push(selector); },
    async fillText(selector, v) { this.value = v; },
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      if (request.mode === 'results') return {
        ...base, loading: false, count: 1, empty: false, total: '60',
        pagination: { current: 1, next: '#next', totalPages: 3 },
        rows: [{ name: '甲**', experience: '工作1年' }],
      };
      return { ...base, target: '#keyword', value: this.value };
    },
  };
  const result = await run(page, { keyword: '前端', pages: 3, limit: 5 }, { pause: async () => {} });
  assert.equal(result.pages, 1);
  assert.equal(result.rows.length, 1);
  assert.match(result.warning, /停止翻页/);
  assert.equal(page.clicks.filter(x => x === '#submit').length, 1);
});
test('risk stops before mutation; result timeout never resubmits', async () => {
  const blocked = fake({ risk: true }); await assert.rejects(run(blocked, { keyword: 'a' }), { code: 'RISK' }); assert.equal(blocked.clicks.length, 0);
  const slow = fake({ pending: true }); await assert.rejects(run(slow, { keyword: 'a' }, { pause: async () => {} }), { code: 'TIMEOUT' }); assert.equal(slow.clicks.filter(x => x === '#submit').length, 1);
});
test('city cascade: selects a non-hot city via the 其他 modal search and confirms', async () => {
  const clicks = [];
  let stage = 'row'; // row → modal → picked → done
  const page = {
    async click(selector) {
      clicks.push(selector);
      if (selector === '#other') stage = 'modal';
      if (selector === '#sugg') stage = 'picked';
      if (selector === '#confirm') stage = 'done';
    },
    async fillText() {},
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      if (stage === 'done') return { ...base, choice: '#foshan', selected: true, cascadeTrigger: '#other', cityModal: null };
      if (stage === 'row') return { ...base, choice: null, cascadeTrigger: '#other', cityModal: null };
      return {
        ...base, choice: null, cascadeTrigger: '#other',
        cityModal: {
          input: '#city-input', suggestionTexts: ['广东·佛山'],
          match: '#sugg', matchCount: 1,
          confirm: '#confirm', confirmDisabled: stage !== 'picked',
        },
      };
    },
  };
  const result = await run(page, { city: '佛山' }, { pause: async () => {}, submit: false });
  assert.deepEqual(clicks, ['#other', '#city-input', '#sugg', '#confirm']);
  assert.deepEqual(result.applied, [{ field: 'city', value: '佛山' }]);
  assert.equal(clicks.includes('#submit'), false);
});
test('city cascade refuses to guess when no unique suggestion matches', async () => {
  const clicks = [];
  const page = {
    async click(selector) { clicks.push(selector); },
    async fillText() {},
    async evaluate(fn, request) {
      const base = { url, risk: false, riskSignals: [], blank: false, login: false };
      if (request.mode === 'controls') return { ...base, reset: null, submit: '#submit' };
      if (clicks.includes('#other')) {
        return { ...base, choice: null, cascadeTrigger: '#other',
          cityModal: { input: '#city-input', suggestionTexts: ['辽宁·朝阳', '北京·朝阳区'], match: null, matchCount: 2, confirm: '#confirm', confirmDisabled: true } };
      }
      return { ...base, choice: null, cascadeTrigger: '#other', cityModal: null };
    },
  };
  await assert.rejects(run(page, { city: '朝阳' }, { pause: async () => {}, submit: false }), { code: 'CONTROL' });
  assert.equal(clicks.includes('#sugg'), false);
  assert.equal(clicks.includes('#submit'), false);
});
