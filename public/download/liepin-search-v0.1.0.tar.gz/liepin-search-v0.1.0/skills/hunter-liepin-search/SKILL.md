---
name: hunter-liepin-search
description: 在猎聘猎头端 h.liepin.com 按已确认的职位条件搜索候选人、读取搜索结果，或管理已保存的搜索方案。使用 OpenCLI liepin 插件；适用于招聘寻访，不用于个人求职和投递。
---

# 猎聘搜索

## 开始前

1. 确认用户在 Chrome 登录猎聘猎头端，OpenCLI 扩展已启用。运行 `opencli doctor` 检查浏览器连接；安装包 doctor 只检查本地安装。
2. 运行 `opencli liepin --help` 与 `opencli liepin conditions -f json` 获取实际参数。不要猜测字段或枚举值。
3. 从用户需求提取关键词、城市、学历、经验等条件；缺失项不擅自补充。先给出准备执行的条件，确认用户所要的搜索范围。

## 搜索与结果

- 检查当前页面：`opencli liepin diagnose -f json`，只读，不自动导航。
- 准备筛选：`opencli liepin prepare "电机结构工程师" --city 深圳 --education 本科 --keep-tab true -f json`。这会清空并设置页面条件，但不提交搜索。
- 用户已授权搜索后：`opencli liepin search "电机结构工程师" --city 深圳 --education 本科 --limit 5 --pages 1 --keep-tab true -f json`。提交一次，默认只读当前页。
- 读取已有结果：`opencli liepin results --limit 10 -f json`。不导航、不翻页、不提交。
- 多页读取只有在用户指定范围时使用 `--pages N`（1–10）。不重复提交失败搜索；出现验证码、限制提示、筛选回读失败时停止并说明实际状态。
- 页面总数可能为 3000+ 等原文；返回条数只代表已读卡片。缺失字段保持未知，不据摘要推断完整简历。搜索默认捕获列表响应富化展示字段；`--capture false` 关闭捕获。
- 以用户确认的职位要求解释匹配点与待核实项。结果不会自动保存；导出或落盘前按用户要求处理个人信息。

## 已保存搜索方案

运行相应命令的 `--help` 获取参数，再按用户指令执行：

| 任务 | 命令 |
| --- | --- |
| 列出已有方案 | `opencli liepin saved-searches -f json` |
| 保存当前需求的方案 | `opencli liepin save-search "方案名" ...` |
| 应用已有方案并搜索 | `opencli liepin apply-saved-search "方案名" ...` |
| 删除唯一匹配的方案 | `opencli liepin delete-saved-search "方案名"` |

保存和删除会改变猎聘账号数据，仅在用户明确要求时执行。名称匹配不唯一时停止。

本包包含搜索、列表读取和方案管理；不包含完整简历评估、自动联系、收藏、标签或消息发送。`peekdetail` 是开发验收命令，不作为日常寻访步骤。

## 更新

重新从官方独立产品入口安装可更新同名插件与 Skill。安装回执会显示持久目录和专用 `update.mjs` 路径；不要使用其他渠道产品的更新入口覆盖本包。
