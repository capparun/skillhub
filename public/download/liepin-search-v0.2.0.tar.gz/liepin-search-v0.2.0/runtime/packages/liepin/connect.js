import {cli} from './lib/register.js';
import {LIEPIN_SESSION,LIEPIN_CONNECTION} from './lib/connection.js';
import {checkReadRuntime} from './lib/current-detail.js';

// Bind the foreground page explicitly, without navigating or evaluating it.
export async function connectCurrentPage({checkRuntime=checkReadRuntime,bind,createPage}={}) {
 checkRuntime();
 if(!bind) {
  const {bindTab}=await import(new URL('daemon-client.js',import.meta.resolve('@jackwener/opencli/browser/page')).href);
  bind=bindTab;
 }
 if(!createPage) {
  const {Page}=await import('@jackwener/opencli/browser/page');
  createPage=()=>new Page(LIEPIN_SESSION,undefined,undefined,'background','browser','persistent');
 }
 const page=createPage();
 try {
  const bound=await bind(LIEPIN_SESSION);
  const url=new URL(bound.url);
  if(url.origin!=='https://h.liepin.com' || !['/search/getConditionItem','/resume/showresumedetail/','/resumemanage/showmytalentlist'].includes(url.pathname)) {
   // Keep query strings, fragments, credentials and non-web path data out of logs.
   const surface=bound.url==='about:blank'?'about:blank'
    :['http:','https:'].includes(url.protocol)?url.origin:`${url.protocol}页面`;
   const error=new Error(`当前绑定到 ${surface}，未执行猎聘页面操作。请先切换到原有猎聘搜索页、已打开的简历详情页或人才管理收藏页；若有其他任务切换窗口，先协调浏览器使用。绑定到空白页本身不能证明猎聘发生白屏。`);
   error.code='WRONG_BOUND_PAGE';
   throw error;
  }
  const tabs=await page.tabs();
  if(tabs.length!==1 || tabs[0].url!==bound.url || !/^[a-fA-F0-9]{16,128}$/.test(tabs[0].page ?? ''))throw new Error('绑定页面发生变化，请核对当前标签');
  if(tabs[0].connectionMode!==LIEPIN_CONNECTION)throw new Error('当前开发版插件要求实验连接协议，所连接扩展未声明该协议；尚未执行页面代码。这不代表官方扩展无法使用猎聘，官方连接路径仍待对照验收');
  return {session:LIEPIN_SESSION,page:tabs[0].page,url:bound.url,connectionMode:LIEPIN_CONNECTION};
 } catch(error) {await page.closeWindow();throw error;}
}
cli({site:'liepin',name:'connect',access:'read',browser:false,
 description:'绑定当前已打开的猎聘页面，检查配套连接扩展并返回后续命令使用的 page；不导航或读取简历',
 args:[],columns:['session','page','url','connectionMode'],func:async()=>[await connectCurrentPage()]});
