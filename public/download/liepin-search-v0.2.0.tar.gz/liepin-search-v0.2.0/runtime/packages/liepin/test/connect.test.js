import test from 'node:test';
import assert from 'node:assert/strict';
import {connectCurrentPage} from '../connect.js';
import {LIEPIN_SESSION,LIEPIN_CONNECTION} from '../lib/connection.js';
const url='https://h.liepin.com/search/getConditionItem#session',id='A'.repeat(32);
test('connect returns a checked existing target without page evaluation',async()=>{
 const result=await connectCurrentPage({checkRuntime(){},bind:async session=>{assert.equal(session,LIEPIN_SESSION);return {url};},
  createPage:()=>({tabs:async()=>[{page:id,url,connectionMode:LIEPIN_CONNECTION}],closeWindow:async()=>assert.fail('successful binding must remain usable')})});
 assert.equal(result.page,id);
});
test('wrong page, old extension or changed target releases binding',async()=>{
 for(const scenario of ['wrong','old','changed']) {
  let releases=0;
  await assert.rejects(connectCurrentPage({checkRuntime(){},bind:async()=>({url:scenario==='wrong'?'https://example.com':url}),
   createPage:()=>({tabs:async()=>[{page:id,url:scenario==='changed'?'about:blank':url,connectionMode:scenario==='old'?undefined:LIEPIN_CONNECTION}],closeWindow:async()=>{releases++;}})}));
  assert.equal(releases,1);
 }
});
test('wrong binding reports safe surface only and never inspects page contents',async()=>{
 for(const [boundUrl,label] of [['about:blank','about:blank'],['https://user:password@example.com/private-path?token=secret#private','https://example.com'],['file:///private/secret.txt','file:页面']]){
  let releases=0;
  await assert.rejects(connectCurrentPage({checkRuntime(){},bind:async()=>({url:boundUrl}),createPage:()=>({tabs:async()=>assert.fail('do not inspect wrong page'),closeWindow:async()=>{releases++;}})}),e=>{
   assert.equal(e.code,'WRONG_BOUND_PAGE');assert.ok(e.message.includes(label));assert.ok(!/password|secret|private-path/.test(e.message));return true;
  });assert.equal(releases,1);
 }
});
