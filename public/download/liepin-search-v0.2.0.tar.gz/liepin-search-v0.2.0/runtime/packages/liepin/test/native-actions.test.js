import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {createNativeActions,inspectActionTarget} from '../lib/native-actions.js';
const expectedUrl='https://h.liepin.com/search/getConditionItem';
const action={actionId:'submit-once',selector:'.search-btn'};
const ready={status:'ready',url:expectedUrl,x:120,y:80};
function driver(options={}) {
  const calls=[];
  const page={evaluate:async(fn,args)=>{calls.push(['read',fn,args]);return options.target ?? ready;},
    cdp:async(method,args)=>{calls.push([method,args]);if(options.failAt===calls.length-1)throw new Error('command_result_unknown');}};
  return {calls,actions:createNativeActions(page,{expectedUrl})};
}
test('direct click dispatches once, reports acknowledgment only and rejects repeated action IDs',async()=>{
  const {calls,actions}=driver();const result=await actions.click(action);
  assert.equal(result.status,'dispatched');assert.equal(result.requiresBusinessVerification,true);
  assert.deepEqual(calls.slice(1).map(c=>c[1].type),['mouseMoved','mousePressed','mouseReleased']);
  await assert.rejects(actions.click(action),e=>e.reason==='duplicate_action');assert.equal(calls.length,4);
  assert.deepEqual(Object.keys(actions),['click','hover','escape','scroll','scrollTo','fill']);
});
test('failure context distinguishes an initial blocked action from a later blocked action',async()=>{
 for(const prior of [0,1]) {
  let reads=0,dispatches=0;
  const actions=createNativeActions({evaluate:async()=>++reads<=prior?ready:{status:'blocked',reason:'target_covered'},
   cdp:async()=>{dispatches++;}},{expectedUrl});
  if(prior)await actions.click({...action,actionId:'before'});
  await assert.rejects(actions.click(action),error=>{
   assert.deepEqual(error.action,{actionId:'submit-once',purpose:'click',outcome:'not_started',acknowledgedActions:prior});
   assert.match(error.message,/不代表业务成功/);return true;
  });
  assert.equal(dispatches,prior*3);
 }
});
test('failure at every dispatch stage stops without fallback, release retry or another action',async()=>{
  for(const failAt of [1,2,3]) {
    const {calls,actions}=driver({failAt});
    await assert.rejects(actions.click(action),e=>e.outcome==='unknown');
    await assert.rejects(actions.click({...action,actionId:'different'}));
    assert.equal(calls.length,failAt+1);
  }
});
test('risk, login, wrong page and malformed geometry block before input',async()=>{
  for(const target of [{status:'blocked',reason:'risk_signal'},{status:'blocked',reason:'login_required'},
    {...ready,url:'https://example.com/'},{...ready,x:NaN}]) {
    const {calls,actions}=driver({target});
    await assert.rejects(actions.click(action),e=>e.outcome==='not_started');
    assert.equal(calls.length,1);
    await assert.rejects(actions.click({...action,actionId:'again'}));assert.equal(calls.length,1);
  }
});
test('concurrent calls cannot inspect or dispatch a second action',async()=>{
  let release;let reads=0;const barrier=new Promise(resolve=>{release=resolve;});
  const actions=createNativeActions({evaluate:async()=>{reads++;await barrier;return ready;},cdp:async()=>{}},{expectedUrl});
  const first=actions.click(action);
  await assert.rejects(actions.click({...action,actionId:'second'}),/busy/);
  release();await first;assert.equal(reads,1);
});
function inspect(overrides={}) {
  const element={disabled:false,getAttribute:()=>null,closest:()=>null,
    getBoundingClientRect:()=>({x:100,y:60,width:40,height:40}),contains:()=>false};
  const context={location:{href:expectedUrl,origin:'https://h.liepin.com'},innerWidth:800,innerHeight:600,
    document:{body:{innerText:'合成搜索页面'},readyState:'complete',querySelectorAll:()=>[element],elementFromPoint:()=>element},
    getComputedStyle:()=>({visibility:'visible',display:'block',opacity:'1'})};
  overrides.modify?.(context,element);
  return vm.runInNewContext(`(${inspectActionTarget.toString()})(${JSON.stringify({selector:'.search-btn',expectedUrl,purpose:overrides.purpose ?? 'click'})})`,context);
}
test('fixed evaluator refuses redirects, challenges, duplicate targets, overlays and unavailable controls',()=>{
  assert.equal(inspect().status,'ready');
  for(const [reason,modify] of [
    ['page_changed',c=>{c.location.href='https://example.com/';}],
    ['risk_signal',c=>{c.document.body.innerText='访问过于频繁';}],
    ['login_required',c=>{c.document.body.innerText='请登录';}],
    ['page_loading',c=>{c.document.readyState='loading';}],
    ['target_not_unique',(c,e)=>{c.document.querySelectorAll=()=>[e,e];}],
    ['target_covered',c=>{c.document.elementFromPoint=()=>({});}],
    ['target_unavailable',(c,e)=>{e.disabled=true;}],
    ['target_outside_viewport',(c,e)=>{e.getBoundingClientRect=()=>({x:900,y:0,width:20,height:20});}],
  ])assert.equal(inspect({modify}).reason,reason);
});
test('non-search pages are refused when constructing the driver',()=>{
  for(const expectedUrl of ['https://example.com/','https://h.liepin.com/','https://user@h.liepin.com/search/getConditionItem']) {
    assert.throws(()=>createNativeActions({},{expectedUrl}));
  }
});
test('production inspector requires an editable focused input and rejects password controls',()=>{
 const setup=(c,e)=>{Object.assign(e,{tagName:'INPUT',type:'text',value:'旧词',selectionStart:0,selectionEnd:2});c.document.activeElement=e;};
 assert.equal(inspect({purpose:'fill',modify:setup}).value,'旧词');
 for(const modify of [
  (c,e)=>{e.type='password';},(c,e)=>{e.readOnly=true;},
  c=>{c.document.activeElement={};},
 ])assert.equal(inspect({purpose:'fill',modify:(c,e)=>{setup(c,e);modify(c,e);}}).status,'blocked');
});
test('numeric input requires confirmed clearing before inserting once',async()=>{
 for(const failClear of [false,true]) {
  let value='123';const events=[];
  const actions=createNativeActions({evaluate:async()=>({...ready,inputType:'number',value,selectionStart:null,selectionEnd:null}),
    cdp:async(method,args)=>{events.push([method,args]);if(args.key==='Backspace' && args.type==='keyDown' && !failClear)value='';if(method==='Input.insertText')value=args.text;}
  },{expectedUrl});
  if(failClear){await assert.rejects(actions.fill({...action,value:'42.5'}),e=>e.reason==='clear_unconfirmed');assert.equal(events.some(e=>e[0]==='Input.insertText'),false);}
  else {await actions.fill({...action,value:'42.5'});assert.equal(value,'42.5');assert.equal(events.filter(e=>e[0]==='Input.insertText').length,1);}
 }
});
test('scroll resolves one node and stops if scrolling cannot be confirmed',async()=>{
 for(const failScroll of [false,true]) {
  let scrolled=false;const calls=[];
  const actions=createNativeActions({evaluate:async()=>({...ready,inViewport:scrolled}),cdp:async(method)=>{
   calls.push(method);if(method==='DOM.getDocument')return {root:{nodeId:1}};
   if(method==='DOM.querySelectorAll')return {nodeIds:[2]};
   if(method==='DOM.scrollIntoViewIfNeeded' && !failScroll)scrolled=true;
  }},{expectedUrl});
  if(failScroll){await assert.rejects(actions.scrollTo(action),e=>e.reason==='scroll_unconfirmed');await assert.rejects(actions.click({...action,actionId:'retry'}));}
  else await actions.scrollTo(action);
  assert.deepEqual(calls,['DOM.getDocument','DOM.querySelectorAll','DOM.scrollIntoViewIfNeeded']);
 }
});
function inputDriver({failSelection=false,failInsertion=false,loseFocus=false}={}) {
  let value='旧关键词',selected=false;const events=[];
  const page={
    evaluate:async()=>loseFocus && selected ? {status:'blocked',reason:'input_not_focused'}
      : {...ready,value,selectionStart:0,selectionEnd:selected && !failSelection?value.length:0},
    cdp:async(method,params)=>{
      events.push([method,params]);
      if(params.commands)selected=true;
      if(method==='Input.insertText' && !failInsertion)value=params.text;
    },
  };
  return {events,actions:createNativeActions(page,{expectedUrl}),value:()=>value};
}
test('fill uses native editing, verifies selection and reads back Unicode text',async()=>{
  const d=inputDriver();await d.actions.fill({...action,value:'嵌入式开发'});
  assert.equal(d.value(),'嵌入式开发');assert.equal(d.events.length,3);
  assert.deepEqual(d.events.map(e=>e[0]),['Input.dispatchKeyEvent','Input.dispatchKeyEvent','Input.insertText']);
});
test('unconfirmed selection or lost focus cannot insert into another field',async()=>{
  for(const options of [{failSelection:true},{loseFocus:true}]) {
    const d=inputDriver(options);
    await assert.rejects(d.actions.fill({...action,value:'新词'}),e=>e.outcome==='unknown');
    assert.equal(d.events.some(e=>e[0]==='Input.insertText'),false);
    await assert.rejects(d.actions.click({...action,actionId:'submit'}));assert.equal(d.events.length,2);
  }
});
test('failed input verification stops without reinserting or submitting',async()=>{
  const d=inputDriver({failInsertion:true});
  await assert.rejects(d.actions.fill({...action,value:'新词'}),e=>e.reason==='input_unconfirmed');
  await assert.rejects(d.actions.fill({...action,actionId:'again',value:'新词'}));
  assert.equal(d.events.filter(e=>e[0]==='Input.insertText').length,1);
});
test('already correct input does not dispatch editing commands',async()=>{
  const d=inputDriver();await d.actions.fill({...action,value:'旧关键词'});assert.equal(d.events.length,0);
});
test('hover dispatches only one native mouse move and shares the stop latch',async()=>{
  const {actions,calls}=driver({failAt:1});
  await assert.rejects(actions.hover(action),e=>e.outcome==='unknown');
  await assert.rejects(actions.click({...action,actionId:'after-hover'}));
  assert.equal(calls.length,2);assert.equal(calls[1][1].type,'mouseMoved');
});

test('native action permits the observed #session fragment but not query changes',async()=>{
 const accepted=driver({target:{...ready,url:expectedUrl+'#session'}});
 await accepted.actions.click(action);
 assert.equal(accepted.calls.filter(c=>c[0]==='Input.dispatchMouseEvent').length,3);
 const denied=driver({target:{...ready,url:expectedUrl+'?other=1#session'}});
 await assert.rejects(denied.actions.click(action));
 assert.equal(denied.calls.length,1);
});
test('transient coverage is observed again before one click, persistent coverage still blocks',async()=>{
 const {createNativeActionSequence}=await import('../lib/native-actions.js');
 for(const clears of [true,false]){
  let reads=0,dispatches=0,waits=0;
  const actions=createNativeActionSequence({evaluate:async()=>++reads===2&&clears?ready:{status:'blocked',reason:'target_covered'},cdp:async()=>{dispatches++;}},
   {expectedUrl,inspectTarget:inspectActionTarget,pause:async()=>{waits++;}});
  if(clears)await actions.click(action);else await assert.rejects(actions.click(action),e=>e.reason==='target_covered'&&e.outcome==='not_started');
  assert.equal(reads,2);assert.equal(waits,1);assert.equal(dispatches,clears?3:0);
 }
});
test('coverage after fill dispatch is uncertain and never gets a second inspection',async()=>{
 const {createNativeActionSequence}=await import('../lib/native-actions.js');let reads=0,waits=0;
 const actions=createNativeActionSequence({evaluate:async()=>++reads===1?{...ready,value:'old',inputType:'text'}:{status:'blocked',reason:'target_covered'},cdp:async()=>{}},
 {expectedUrl,inspectTarget:inspectActionTarget,pause:async()=>{waits++;}});
 await assert.rejects(actions.fill({...action,value:'new'}),e=>e.outcome==='unknown');assert.equal(reads,2);assert.equal(waits,0);
});
test('covered target records geometry without DOM text or values',()=>{
 const result=inspect({modify:(c,e)=>{e.tagName='INPUT';e.value='secret-value';c.document.elementFromPoint=()=>({tagName:'DIV',className:'sticky-bar',innerText:'private-page-text'});}});
 assert.equal(result.reason,'target_covered');assert.equal(result.geometry.targetTag,'INPUT');assert.equal(result.geometry.hitClass,'sticky-bar');assert.equal(typeof result.geometry.x,'number');assert.doesNotMatch(JSON.stringify(result),/secret-value|private-page-text/);
});
