import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {inspect} from '../lib/dom.js';
function controls(bothReachable=false){
 const node=(id,text,x,children=[])=>({id,textContent:text,children,getClientRects:()=>[{}],getBoundingClientRect:()=>({left:x,top:0,width:10,height:10}),contains:child=>children.includes(child),outerHTML:'<button />'});
 const icon={},reset=node('reset','清空筛选条件',40,[icon]),main=node('main','搜 索',0),sticky=node('sticky','搜 索',20);
 const nodes=[main,sticky,reset];
 const document={body:{innerText:'猎聘搜索当前条件界面'},readyState:'complete',querySelector:()=>main,
 querySelectorAll:s=>s==='span,a,button,div'?nodes:s==='.search-btn, button'?[main,sticky]:s.startsWith('#')?nodes.filter(n=>`#${n.id}`===s):[],
 elementFromPoint:x=>x===5?main:x===25?(bothReachable?sticky:{}):icon};
 return vm.runInNewContext(`(${inspect.toString()})({mode:'controls'})`,{document,location:{origin:'https://h.liepin.com',pathname:'/search/getConditionItem',href:'https://h.liepin.com/search/getConditionItem'},getComputedStyle:()=>({visibility:'visible'}),CSS:{escape:s=>s}});
}
test('icon-bearing reset is found and covered duplicate search button is excluded',()=>{
 const state=controls();assert.equal(state.reset,'#reset');assert.equal(state.submit,'#main');assert.equal(state.submitCount,1);
});
test('two reachable search buttons remain ambiguous',()=>{
 const state=controls(true);assert.equal(state.submit,null);assert.equal(state.submitCount,2);
});
