import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {createTask,readTask} from '../lib/task-store.js';
import {authorizeTask,resolveOperation,resumeTask} from '../lib/operation-gate.js';
import {createSiteScope,bindSiteScope,executeScopedOperation,authorizeScopedRetry} from '../lib/site-scope.js';
for(const outcome of ['not-executed','abandoned','unknown'])test(`explicit scoped retry requires proven non-execution: ${outcome}`,async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'liepin-retry-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const file=path.join(dir,'task.json'),scope=path.join(dir,'scope.json'),now=new Date().toISOString();
 createTask(file);createSiteScope(scope,{label:'test',maxOperations:1,confirmedAt:now});bindSiteScope(file,scope);
 const req={kind:'save-search',payload:{name:'test'}};
 authorizeTask(file,{allowedKinds:['save-search'],allowedRequests:[req],maxOperations:1,confirmedAt:now,scope:'test'});
 await executeScopedOperation(file,{...req,operationId:'old'},async()=>({status:'unknown',evidence:{reason:'inspection failed'}}));
 const scopeOp=readTask(scope).operations[0].operationId;
 if(outcome!=='unknown')for(const [f,id] of [[scope,scopeOp],[file,'old']]){
  resolveOperation(f,{operationId:id,outcome,reviewer:'test',reviewedAt:now,executorStopped:true,evidence:{reason:'checked'}});
  resumeTask(f,{reviewer:'test',confirmedAt:now,reason:'checked'});
 }
 const auth={previousOperationId:'old',operationId:'retry-one',reviewer:'test',confirmedAt:now,reason:'verified before click'};
 if(outcome!=='not-executed'){assert.throws(()=>authorizeScopedRetry(file,auth));return;}
 authorizeScopedRetry(file,auth);assert.throws(()=>authorizeScopedRetry(file,auth));
 let calls=0;const invoke=()=>executeScopedOperation(file,{...req,operationId:'retry-one'},async()=>{calls++;return {status:'completed',evidence:{saved:true}};});
 await invoke();await invoke();assert.equal(calls,1);
 for(const f of [file,scope]){const state=readTask(f);assert.equal(state.operations.length,2);assert.equal(state.operations[0].status,'closed');assert.equal(state.operations[0].resolution.previous.status,'unknown');assert.equal(state.operations[1].status,'completed');}
 assert.throws(()=>authorizeScopedRetry(file,{...auth,previousOperationId:'retry-one',operationId:'again'}));
});
for(const kind of ['prepare','save-search'])test(`reviewed partial reapplication stays limited to prepare: ${kind}`,async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'liepin-reapply-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const file=path.join(dir,'task.json'),scope=path.join(dir,'scope.json'),now=new Date().toISOString();
 createTask(file);createSiteScope(scope,{label:'test',maxOperations:1,confirmedAt:now});bindSiteScope(file,scope);
 const req={kind,payload:{page:'A'.repeat(32),filters:{salaryMin:'10',salaryMax:'50'}}};
 authorizeTask(file,{allowedKinds:[kind],allowedRequests:[req],maxOperations:1,confirmedAt:now,scope:'test'});
 await executeScopedOperation(file,{...req,operationId:'partial'},async()=>({status:'unknown',evidence:{reason:'second field failed'}}));
 const scopeOp=readTask(scope).operations[0].operationId;
 for(const [f,id] of [[scope,scopeOp],[file,'partial']]){
  resolveOperation(f,{operationId:id,outcome:'abandoned',reviewer:'test',reviewedAt:now,executorStopped:true,evidence:{reason:'partial effects inspected'}});
  resumeTask(f,{reviewer:'test',confirmedAt:now,reason:'checked'});
 }
 const auth={previousOperationId:'partial',operationId:'reapply',reviewer:'test',confirmedAt:now,reason:'reapply complete range after review',prepareReadback:{url:'https://h.liepin.com/search/getConditionItem#session',observedAt:now,values:{salaryMin:'10',salaryMax:''}}};
 assert.throws(()=>authorizeScopedRetry(file,{...auth,prepareReadback:{...auth.prepareReadback,observedAt:'2000-01-01'}}),/五分钟/);
 assert.throws(()=>authorizeScopedRetry(file,{...auth,prepareReadback:undefined}));
 if(kind!=='prepare'){assert.throws(()=>authorizeScopedRetry(file,auth));return;}
 authorizeScopedRetry(file,auth);
 let calls=0;const invoke=()=>executeScopedOperation(file,{...req,operationId:'reapply'},async()=>{calls++;return {status:'completed',evidence:{applied:true}};});
 await invoke();await invoke();assert.equal(calls,1);
 assert.equal(readTask(file).operations[0].resolution.outcome,'abandoned');
 assert.deepEqual(readTask(file).retryAuthorizations[0].prepareReadback.values,auth.prepareReadback.values);
});
