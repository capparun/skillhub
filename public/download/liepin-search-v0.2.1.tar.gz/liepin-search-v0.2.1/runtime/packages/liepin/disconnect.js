import {cli} from './lib/register.js';
import {disconnectManagedSearch} from './connect.js';
cli({site:'liepin',name:'disconnect',access:'write',browser:false,
 description:'结束官方独立寻访会话，释放它创建的搜索标签；本地任务和已打开详情保留',
 args:[{name:'page',type:'string',required:true,help:'独立寻访 connect 返回的原搜索目标'}],
 columns:['session','released'],func:async args=>[await disconnectManagedSearch(args.page)]});
