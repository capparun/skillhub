import {customerDoctor} from './tools/liepin-mcp/scripts/customer-install.mjs';
import {fileURLToPath} from 'node:url';
try {const args=process.argv.slice(2);if(args.length&&!(args.length===2&&args[0]==='--root'))throw Error('用法：node doctor.mjs [--root 安装根]');console.log(JSON.stringify(customerDoctor({packageDirectory:fileURLToPath(new URL('.',import.meta.url)),root:args[1]}),null,2));}catch(error){console.error(error.message);process.exitCode=1;}
