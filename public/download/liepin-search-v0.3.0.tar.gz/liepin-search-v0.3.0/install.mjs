import {installCustomer} from './tools/liepin-mcp/scripts/customer-install.mjs';
import {fileURLToPath} from 'node:url';
try {const result=await installCustomer(process.argv.slice(2),{packageDirectory:fileURLToPath(new URL('.',import.meta.url))});console.log(JSON.stringify(result,null,2));}catch(error){console.error(error.message);process.exitCode=1;}
