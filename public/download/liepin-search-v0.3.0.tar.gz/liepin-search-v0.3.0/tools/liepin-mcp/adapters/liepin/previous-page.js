import {withAdapterDeadline} from '../../lib/site-adapter-deadline.mjs';
import {defineAdapter} from 'opencli-mcp/adapter-sdk';
import {previousAdapterPage} from '../../lib/site-adapter-search.mjs';
export default defineAdapter({description:'点击当前结果的上一页并保存列表，用于返回核实遗漏人选；不重新搜索，不表示该页已处理完成',domain:'h.liepin.com',access:'write',result:{kind:'value',description:'上一页页码与保存数量'},args:[{name:'file',type:'string',required:true},{name:'operation_id',type:'string',required:true},{name:'tab_id',type:'string',required:true}],run:withAdapterDeadline(previousAdapterPage)});
