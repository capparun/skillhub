"use strict";
(() => {
  // extension/src/content/cursor.ts
  var ROOT_ID = "opencli-mcp-overlay-root";
  var host = null;
  var cursor = null;
  var keeper = null;
  var pos = { x: -100, y: -100 };
  var anim = null;
  var finishMove = null;
  function stopMotion() {
    if (anim !== null) cancelAnimationFrame(anim);
    anim = null;
    const finish = finishMove;
    finishMove = null;
    finish?.(false);
  }
  function place(el, x, y, tilt = 0, stretch = 1) {
    el.style.transform = `translate3d(${x - 2.5}px, ${y - 2}px, 0) rotate(${tilt}deg) scale(${stretch}, ${1 / stretch})`;
  }
  function ensureOverlay() {
    if (host && document.documentElement.contains(host)) return cursor;
    host = document.createElement("div");
    host.id = ROOT_ID;
    host.setAttribute("aria-hidden", "true");
    host.setAttribute("style", "all:initial;position:fixed;inset:0;z-index:2147483646;pointer-events:none;");
    const shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
    .c{position:fixed;left:0;top:0;width:26px;height:29px;pointer-events:none;will-change:transform;transform-origin:2.5px 2px;opacity:0;filter:blur(5px);transition:opacity .24s ease,filter .24s ease}
    .c.on{opacity:1;filter:blur(0)}
    .c img{display:block;width:26px;height:29px;user-select:none;filter:drop-shadow(0 1px 1px rgba(0,0,0,.48)) drop-shadow(0 0 6px rgba(51,156,255,.78)) drop-shadow(0 0 16px rgba(51,156,255,.38))}
    @media print{.c{display:none}}
    @media(prefers-reduced-motion:reduce){.c{transition:none}}
  `;
    cursor = document.createElement("div");
    cursor.className = "c";
    const img = document.createElement("img");
    try {
      img.src = chrome.runtime.getURL("cursor.svg");
    } catch {
    }
    img.width = 26;
    img.height = 29;
    img.alt = "";
    img.draggable = false;
    cursor.appendChild(img);
    shadow.append(style, cursor);
    document.documentElement.appendChild(host);
    keeper = new MutationObserver(() => {
      if (host && !document.documentElement.contains(host)) document.documentElement.appendChild(host);
    });
    keeper.observe(document.documentElement, { childList: true });
    return cursor;
  }
  function moveTo(x, y, animate) {
    const el = ensureOverlay();
    el.classList.add("on");
    stopMotion();
    const from = { ...pos };
    const dist = Math.hypot(x - from.x, y - from.y);
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    const duration = !animate || reduced || from.x < 0 || dist < 0.5 ? 0 : dist > 196 ? Math.min(760, 280 + dist * 0.38) : Math.min(300, 130 + dist * 0.7);
    const start = performance.now();
    if (duration === 0 || document.visibilityState !== "visible") {
      pos = { x, y };
      place(el, x, y);
      return Promise.resolve(true);
    }
    const dx = x - from.x;
    const dy = y - from.y;
    const arc = dist > 196 ? Math.min(95, dist * 0.16) : 0;
    const perpendicular = { x: -dy / dist, y: dx / dist };
    const mid = { x: (from.x + x) / 2, y: (from.y + y) / 2 };
    const room = (sign2) => {
      const cx = mid.x + perpendicular.x * arc * sign2;
      const cy = mid.y + perpendicular.y * arc * sign2;
      return Math.min(cx, innerWidth - cx, cy, innerHeight - cy);
    };
    const sign = room(1) >= room(-1) ? 1 : -1;
    const control = { x: mid.x + perpendicular.x * arc * sign, y: mid.y + perpendicular.y * arc * sign };
    return new Promise((resolve) => {
      finishMove = resolve;
      const step = (now) => {
        const t = Math.min(1, (now - start) / duration);
        const u = 1 - Math.pow(1 - t, 3);
        const v = 1 - u;
        pos = { x: v * v * from.x + 2 * v * u * control.x + u * u * x, y: v * v * from.y + 2 * v * u * control.y + u * u * y };
        const tilt = Math.max(-9, Math.min(9, (dx - dy) * 0.018)) * Math.sin(Math.PI * u);
        place(el, pos.x, pos.y, tilt, 1 + 0.06 * Math.sin(Math.PI * u));
        if (t < 1) {
          anim = requestAnimationFrame(step);
          return;
        }
        anim = null;
        finishMove = null;
        pos = { x, y };
        place(el, x, y);
        resolve(true);
      };
      anim = requestAnimationFrame(step);
    });
  }
  function dispose() {
    keeper?.disconnect();
    keeper = null;
    stopMotion();
    host?.remove();
    host = null;
    cursor = null;
    pos = { x: -100, y: -100 };
  }
  function render(state) {
    if (!state) {
      dispose();
      return Promise.resolve({ arrived: false });
    }
    if (!state.visible) {
      stopMotion();
      if (cursor) cursor.classList.remove("on");
      pos = { x: state.x, y: state.y };
      return Promise.resolve({ arrived: false });
    }
    return moveTo(state.x, state.y, state.animate === true && document.visibilityState === "visible").then((arrived) => ({ arrived, seq: state.seq }));
  }
  function alive() {
    try {
      return Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function pullState() {
    if (!alive()) return;
    try {
      chrome.runtime.sendMessage({ type: "opencli:cursor-state?" }).then((r) => {
        if (r && r.state !== void 0) void render(r.state ? { ...r.state, animate: false } : null);
      }).catch(() => {
      });
    } catch {
    }
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "opencli:ping") {
      sendResponse({ ok: true });
      return false;
    }
    if (msg?.type === "opencli:cursor-state") {
      void render(msg.state ?? null).then(sendResponse);
      return true;
    }
    return false;
  });
  window.addEventListener("pageshow", pullState);
  pullState();
})();
