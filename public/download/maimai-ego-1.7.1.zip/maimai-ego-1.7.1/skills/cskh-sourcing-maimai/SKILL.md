---
name: cskh-sourcing-maimai
description: |
  脉脉（maimai）寻访 pipeline 编排 skill。基于 ego-lite 独立浏览器执行寻访及经授权的候选人管理；与 OpenCLI 版分开验收。
  接收寻访画像（可由 JD 分析得出）→ 关键词搜索缩池 → 详情批量收割 → 岗位匹配度评估 → 结构化 CSV/JSON 交付。
  触发词: 脉脉寻访 / maimai sourcing / 脉脉人才搜索 / 脉脉候选人 / maimai 候选人 / 在脉脉上招 / 脉脉 scout
  与通用 sourcing 词共用范围，但优先在脉脉场景触发。
metadata:
  type: skill
  version: 1.7.1
  status: testing
  disable: false
---

# cskh-sourcing-maimai: 脉脉寻访 Pipeline

编排"寻访画像 → 脉脉关键词搜索 → 详情收割 → 岗位匹配度评估 → 结构化交付"的脉脉寻访工作流。

底层运行时是 **ego-lite**（`ego-browser`），不调用 OpenCLI 脉脉适配器。浏览器选择不保证免风控；当前平台可用性以本轮实际页面验收为准。

**无需职位、JD 或 JBF 即可搜索、浏览与导出。** 用户自愿提供匹配要求时才使用 `--persona`；没有标准就整理事实，不自行生成评分标准。

P0 范围、原子命令及验收边界见 [references/p0-scenarios.md](references/p0-scenarios.md)。当前只读基线与新增菜单动作分别记录验收；未覆盖路径不视为通过。

## 触发条件

以下任一情况自动触发：
- 用户说"脉脉寻访"、"maimai sourcing"、"在脉脉上招"
- 用户说"脉脉人才搜索"、"脉脉候选人"、"maimai 候选人"
- 用户给出脉脉链接或要求从脉脉找候选人
- 用户从 `cskh-sourcing` 分发器选择脉脉

输入可以是一句话，也可以是 **JD 分析后得出的寻访画像**（JSON）。只有关键词时可直接搜索；仅在用户要求评估且标准不足时澄清，不自行编造。

## 运行环境（必须先自检）

本 skill 的运行时分两层，适配边界不同：

| 层 | 依赖 | macOS | Linux | Windows |
|---|---|---|---|---|
| 消费层（SKILL.md 编排、export 本地处理） | Node ≥ 18 | ✅ | ✅ | ✅ |
| 运行时层（login/search/harvest，驱动 ego 浏览器） | ego-browser ≥ 0.5.1 | ✅ | ✅ | ❌ 暂不支持 |

**本 CLI 的 Windows 浏览器操作尚未支持。** Windows 上运行时会得到 `UNSUPPORTED_PLATFORM` 错误并明确提示，不会静默失败。WorkBuddy 装在 Windows 上时，消费层可正常读取本 skill 并给出诚实提示；要真正跑寻访需在 macOS/Linux 机器执行。

自检（每次新会话首次进入时执行一次）：

```bash
node --version          # 需 ≥ 18
ego-browser --version   # 需 ≥ 0.5.1；不存在则说明运行时层不可用
```

ego-browser 不在 PATH 时，可用环境变量 `EGO_BROWSER_BIN` 指定绝对路径。

## 关键规则（不可违反）

1. **搜索与详情默认只读；候选人管理须获得用户授权。** `note/job-assign/follow/reserve` 默认只预览，明确对象与改动后用 `--apply` 提交一次并回读。用户授权持续有效，不重复索要。禁止电话、立即沟通、发消息；加好友延期，不提供命令。结果不明时停止，不自动重试。
2. **节奏下限 ≥ 1.6 秒/人。** harvest 内置硬下限，不得为提速绕过。单轮 harvest 建议 ≤ 30 人，长任务分多轮。
3. **不落任何凭据。** 不读取、不保存、不打印 cookie / token / 密码。登录完全由人在 ego 弹出的浏览器窗口里完成。
4. **每个 space 串行。** 同一时刻只允许一个 ego 命令在跑；上一条结束、页面稳定后才执行下一条。禁止并发跑 search/harvest。
5. **中断靠 state 恢复，不靠重跑。** 所有进度落在 `~/.maimai-scout/`（state.json / page-map.json / seen.json / output/）。中断后核对错误与游标再续跑；身份不确定时停止，不猜测下一位。
6. **账号权限每次执行都检查。** 每次执行先 `health` 检查会话与登录；它不证明会员权限或额度充足。具体能力需在目标页面核实；无法读取时明确报告。
7. **诚实报错。** 页面改版导致选择器失效时报 `PAGE_MAP_DRIFT`，重跑 `explore` 自愈；不得猜旧选择器硬点。

## 命令参考

统一入口是 `node <SKILL_DIR>/scripts/mm.mjs <cmd> [args]`。所有命令输出单行 JSON 信封 `{ok, code, data, hint}`，失败时 exit 1。`<SKILL_DIR>` 指本 skill 安装目录的绝对路径。

| 命令 | 说明 | 关键参数 |
|---|---|---|
| `login` | 建/复用浏览器 space；未登录则交还用户人工登录 | `--resume`（登录完成后接管并验证） |
| `health` | 探登录态、space 存活、page-map 版本、已见人数（不等于平台全部权限已验证） | — |
| `explore` | 生成页面地图（选择器断言），写入 page-map.json | — |
| `search` | 关键词搜索 + 页面筛选 + 翻页，采集候选人列表到 list.jsonl | `[--query] --pages N --limit N [--filters '<json>'] [--run <id>]` |
| `harvest` | 从游标续跑，批量收割详情到 detail.jsonl；`--with-attachment` 顺手下载附件简历 | `--run <id> [--limit N] [--with-attachment]` |
| `export` | 解析 list+detail → 保守去重 → 可选匹配 → CSV/JSON/HTML | `--run <id> [--format csv\|json\|html] [--incremental] [--persona '<json>'\|--persona-file <path>]` |
| `resources` | 查询已有资源列表，不打开聊天 | `--source personal/enterprise/friends/history [--query 关键词] [--group 分组] --pages N --limit N` |
| `candidate` | 从已保存列表中读取指定且唯一的候选人 | `--run <id> --candidate-id <id>` 或 `--run <id> --fingerprint <值>` |
| `finish` | 释放浏览器 space | `--keep`（保留页面） |

错误码：`NOT_LOGGED_IN` / `PAGE_MAP_DRIFT` / `SPACE_LOST` / `RATE_LIMITED` / `SELECTOR_MISSING` / `FILTER_NOT_APPLIED` / `UNSUPPORTED_PLATFORM` / `EGO_NOT_FOUND` / `USAGE`。

## P1 / P2 读取与本地分析

| 命令 | 用途 | 参数 |
| --- | --- | --- |
| `jobs` | 读取在招或已关闭的已有职位及页面计数 | `--status open或closed [--query 关键词] [--limit N]` |
| `applications` | 读取待处理投递，保留投递时间/职位 | `[--job-id ID] [--limit N] [--pages N] [--run ID]` |
| `recommendations` | 独立读取推荐人才，空结果不回退到搜索 | `--job-id ID [--limit N] [--pages N] [--run ID]` |
| `visitors` | 读取职位访客 | 同上 |
| `overview` | 读取首页可见统计与异常提示 | 无 |
| `inbox` | 列出现有会话与最后消息摘要 | `[--limit N] [--pages N]` |
| `thread` | 按 inbox 返回的标识读取已有会话上下文 | `--thread-id ID [--limit N] [--pages N]` |
| `compare` | 本地候选人事实和证据对比，HTML/JSON | `--run ID [--criteria JSON 或 --criteria-file 路径] [--candidate-ids ID1,ID2] [--format html或json] [--output 路径]` |
| `changes` | 相同来源/条件的两轮采集差异 | `--before 旧run --after 新run [--output 路径]` |

读取命令不接受 `--apply`、发送内容等参数。投递/推荐/访客自动保存 `list.jsonl`，可接 `candidate/harvest/export/compare`。没有 ID 的投递可使用返回的完整 `fingerprint` 指定唯一候选人，不按姓名猜人。职位 ID 来自 `jobs` 或用户明确提供，不创建职位。若职位未在首批列表中，先 `jobs --query 关键词` 定位；后续按已保存条件重新读取并核对ID/标题，缓存不直接当作当前状态。

比较标准是可选的，例如 `{"criteria":[{"label":"机器人相关经历","terms":["机器人","robotics"]}]}`。关键词命中仅表示可见文字证据，未命中表示待补证据，不自动判断合格、淘汰或允许触达。没有标准时直接比较事实；不默认生成 JBF。`compare/changes` 为本地处理，不启动浏览器，不覆盖已有报告。

消息页使用 iframe 和虚拟列表；`pages` 是最多扫描多少个列表视口。`thread-id` 是当次列表提供的会话定位值，不是候选人 ID，不保证长期不变。`thread` 只读已加载片段，打开会话可能产生已读状态；禁止输入、发送、快捷回复或交换联系方式。范围内找不到目标时返回 `THREAD_NOT_FOUND`，不匹配同名对象。

职位列表报告当前加载页面；招聘概览保留首页计数原文，不代表全租户汇总。变化报告是两轮采集样本的观察差异；`notObserved` 不等于删除或离职，缺失/冲突身份单独列为 unresolved。定时调度、通知和平台状态变更不包含在这一版。

真实验收范围见 [P1/P2 只读验收](references/readonly-acceptance-20261118.md)。附件继续使用显式的 `--with-attachment`，默认不下载；用户授权后仅保存原文件，不解析 PDF。

## 候选人管理（五项原子命令）

完整场景见 [scene-roadmap.md](references/scene-roadmap.md)，真实验收见 [candidate-actions-acceptance.md](references/candidate-actions-acceptance.md)。

先用 `search/resources` 定位对象；以下命令只操作**当前绑定列表**内唯一稳定 ID 的卡片，不按姓名猜人，不要求 JBF。所有写命令省略 `--apply` 即预览；职位、分组缺参数时列出当前可见选项，不自动新建。

| 命令 | 参数 | 行为 |
|---|---|---|
| `note` | `--candidate-id ID --text 文本 [--visibility self或team] [--apply]` | 追加最多100字符备注，默认仅自己可见 |
| `job-assign` | `--candidate-id ID [--job 完整职位名 --company 公司] [--apply]` | 加入已有职位；新增关系为待沟通，已有关联不改状态 |
| `follow` | `--candidate-id ID [--state on或off] [--apply]` | 设置关注状态，已达到目标时不切换 |
| `reserve` | `--candidate-id ID [--group 名称 --scope personal或enterprise] [--apply]` | 加入指定已有分组，保留原分组 |
| `public-profile` | `--candidate-id ID` | 打开公开档案，核验 ID 与姓名，返回页面标签和不带追踪参数的地址 |

`MAIMAI_STATE_DIR/actions.jsonl` 保存动作键与回执。`ALREADY_RECORDED` 仅说明历史执行，不保证当前页面状态；先预览核查；若独立读取证实关注/分组/职位目标状态已被外部更改，旧成功记录失效，下一次显式提交可继续。`WRITE_UNCONFIRMED/ACTION_UNCERTAIN` 表示可能已写入，禁止换状态目录或改文字绕过防重。备注检测到相同文字时不重复添加，可见范围不一致会如实标注。职位回读使用同一记录的标题、负责人、日期，页面不提供职位ID或公司字段；同名冲突停止。职位下拉目前只匹配页面已加载选项；找不到即停止，不自动发布职位。公开档案由列表菜单打开，与招聘端详情独立。

## 页面筛选（--filters）

search 支持 `--filters '<json>'`，模拟真人点击搜索页筛选（实测：筛选不进 URL，只能点 UI）。筛选随 run 持久化，**harvest 会自动重放**（筛选是纯前端状态，重新导航后不点就没了，不重放会收割错人）。

```bash
node <SKILL_DIR>/scripts/mm.mjs search --query "数据采集" --pages 1 \
  --filters '{"workyears":"5-10年","degree":"本科及以上","city":"北京","hasPdf":true}'
```

面板筛选（值 = 页面上的选项原文）：

| key | 页面筛选项 | 示例值 |
|---|---|---|
| `city` | 城市地区 | `"北京"`（热门城市直选；也可填省名） |
| `cityMode` | （city 弹层内）期望/现居 | `"期望"` / `"现居"`，默认两个都勾=不限 |
| `degree` | 学历要求 | `"本科及以上"` / `"硕士及以上"` / `"专科及以上"` / `"博士"` |
| `workyears` | 工作年限 | `"5-10年"` / `"3-5年"` / `"1-3年"` / `"10年以上"` / `"在校/应届"` / `"1年以内"` |
| `gender` | 性别 | `"男"` / `"女"` |
| `company` | 就职公司 | `"BAT"` / `"一线互联网公司"` 等预设标签 |
| `companyTab` | （company 弹层内）正任职/曾任职 | `"正任职"` / `"曾任职"`，默认两个都勾=不限 |
| `jobtitle` | 职位名称 | `"算法"` / `"后端开发"` 等预设标签 |
| `industry` | 行业方向 | `"IT/互联网/游戏"`；**支持数组多选（≤10）**：`["IT/互联网/游戏","金融业"]` |
| `school` | 毕业学校 | `"985"` / `"211"` / `"QS排名Top500"` 等 |
| `major` | 专业 | `"计算机"`——联想式搜索，自动点第一个匹配联想项 |
| `hometown` | 家乡 | 同 city |
| `aiTalent` | AI人才类型 | `"全部AI人才"` 等 |

区间筛选（值 = `"下限-上限"`，单边开放 `"-40"` / `"30-"` 也行）：

| key | 页面筛选项 | 示例值 |
|---|---|---|
| `age` | 年龄 | `"30-40"`（岁） |
| `salary` | 期望月薪 | `"30-50"`（k） |

结果区筛选：

- **chip**（值固定 `true`）：`intent`（公开求职意向）、`active`（近期有动向）、`hasPdf`（**有附件简历**）、`hadIntent`、`enterprise`、`notViewed`、`notContacted`、`hasNote`、`noNote`、`followed`、`notFollowed`
- `smartFilter`：智能筛选开关（值 `true`，已开则跳过）
- `friend`：好友关系，`"是"` / `"否"`
- `sort`：排序，`"综合排序"` / `"活跃优先"` / `"匹配度优先"`
- `match`：关键词匹配模式，`"所有"` / `"任一"`

特殊行为（实测）：带子弹层的选项（如 `本科及以上` → 不限/只看统招本科）默认选「不限」，可用 `<key>Sub` 指定（如 `"degreeSub":"只看统招本科"`）。

**诚实性保证**：每个面板筛选应用后会校验筛选栏出现「标签：值」，没生效报 `FILTER_NOT_APPLIED`，绝不静默返回未筛选的结果。可选值全集见 [references/filters.md](references/filters.md)。

## 状态与文件

所有状态在 `~/.maimai-scout/`（skill 私有，不依赖 hunter 也能独立用）：

```text
~/.maimai-scout/
├── state.json          # space、login、runs（query/cursor/pageSize）
├── page-map.json       # explore 产物，运行时断言用
├── seen.json           # 增量去重账本 {"姓名|公司": {firstSeen, lastRun}}
├── downloads/<runId>/    # --with-attachment 下载的附件简历原件
└── output/<runId>/
    ├── list.jsonl      # search 产物（候选人列表行）
    ├── detail.jsonl    # harvest 产物（详情文本，按全局行号 rowIndex 对齐）
    └── candidates.csv  # export 产物（带 BOM，Excel 直接开）
```

状态 JSON 使用临时文件重命名；列表与详情有独立落盘逻辑，不将其宣称为全流程事务。可用 `MAIMAI_STATE_DIR` 指定隔离状态目录。

## Recipes

### 1. 首次登录（人在环）

```bash
node <SKILL_DIR>/scripts/mm.mjs login
```

ego 会弹出浏览器窗口。若未登录，命令返回 `NEEDS_LOGIN` 并交还控制权——**把提示原样转达用户**，请用户在弹出的 ego 窗口里扫码/账号登录脉脉（不要代填任何凭据）。用户登录完成后：

```bash
node <SKILL_DIR>/scripts/mm.mjs login --resume
```

验证通过后会话即建立。每次执行寻访前用 `health` 复查登录态与账号权限。

### 2. 关键词矩阵一轮寻访

画像里有多个搜索角度时，逐关键词跑（串行，不并发）。每个关键词一轮：

```bash
node <SKILL_DIR>/scripts/mm.mjs health
node <SKILL_DIR>/scripts/mm.mjs search --query "数据采集 负责人" --pages 2
# search 返回 data.runId，例如 20260924-数据采集-负责人
node <SKILL_DIR>/scripts/mm.mjs harvest --run 20260924-数据采集-负责人 --limit 20
node <SKILL_DIR>/scripts/mm.mjs export --run 20260924-数据采集-负责人 --persona '{"hard":{"years":"5-10","degree":"本科"},"bonus":["英文工作语言","团队管理经验"]}'
```

多组关键词时，每组用不同 `--run`（search 自动按 query+日期生成），最后可分别 export 或合并。

### 3. 增量日巡

每天对同一批关键词重跑 search + harvest，export 加 `--incremental`，只导出相对 `seen.json` 的新人：

```bash
node <SKILL_DIR>/scripts/mm.mjs search --query "数据采集 负责人" --pages 1
node <SKILL_DIR>/scripts/mm.mjs harvest --run <新runId> --limit 30
node <SKILL_DIR>/scripts/mm.mjs export --run <新runId> --incremental --persona-file <画像.json>
```

### 4. 岗位匹配度评估（核心）

export 的 `--persona` 是评估的唯一事实源，结构：

```json
{
  "hard": { "years": "5-10", "degree": "本科" },
  "bonus": ["英文工作语言", "团队管理经验", "出海背景"]
}
```

- `hard.years`：年限区间（如 `"3-5"`、`"5-10"`），候选人年限不在区间内 → `硬性✗`
- `hard.degree`：学历下限（`大专`/`本科`/`硕士`/`博士`/`MBA`），候选人学历低于它 → `硬性✗`
- `bonus`：加分项数组，逐项在候选人亮点/历任公司里找证据，命中标 `✓`

年限或学历缺失、标准不可解析时标为待确认，不得据缺失判定通过。输出的 `岗位匹配度` 列形如 `英文✓ 管理✓ 硬性✓`，排序规则：硬性通过优先，再按加分命中数降序。**硬性✗ 的候选人不会被删除**，只排在后面并标注原因，由人判断。

## 数据获取边界（必须向用户讲清）

"全量简历"的定义是 **脉脉页面公开展示的完整资料**，有三个客观边界：

1. 候选人自己没填的字段（如期望薪资、完整教育经历）拿不到
2. 页面折叠/截断的部分，实现会尽量自动展开（点"展开更多"），但极端长文可能仍有截断
3. **附件简历：harvest 加 `--with-attachment` 可下载原件**（v1.3.0），存到 `~/.maimai-scout/downloads/<runId>/`，CSV 多一列「附件文件」。
   注意两个边界：① 附件格式不假定是 PDF（页面上什么文件名就存什么，实测样例为 .pdf）；
   ② 实测下载的 PDF 是图片型（Pillow 渲染），文字不进 CSV，要全文检索需另做 OCR（v2 再看）

所以 CSV 是"脉脉公开资料的完整结构化"，不是"候选人原始简历附件的全文"。

## Pitfalls

以下都是 2026-09-24 对真实脉脉招聘端实测踩过的坑，不是猜测：

- **抽屉关闭用 Escape**：详情是 antd 抽屉，但**没有 `.ant-drawer-close` 按钮**，点 mask 也关不掉，实测只有按 `Escape` 能关。且抽屉打开时再点其他卡片不会切换内容——必须先 Escape 关掉再点下一张。收割循环是「点卡 → 读 → Escape 关 → 点下一张」。
- **抽屉遮挡点不到**：收割时对卡片用 `data-mm-row` 标记 + `force:true` 点击，绕开抽屉/浮层遮挡。
- **登录态不用 data-testid**：脉脉招聘端页面没有任何 `data-testid` 属性。登录判断靠导航信号（已登录有「人才库/沟通中/个人储备」，登录墙是「扫码/密码登录」）。
- **SPA 异步加载**：搜索结果要 1.5~4 秒才渲染，偶发不触发搜索 XHR。`gotoSearch` 用 `waitForFunction` 等卡片出现（options 是第三参，省略 argument 传 `undefined`），等不到就 `reload()` 重试一次。别用固定 sleep。
- **跨会话列表会重排（旧版行为记录）**：脉脉按活跃度等排序，search 时第 N 行 ≠ harvest 时第 N 行。新版优先使用稳定 ID/资料链接；无稳定标识仅允许唯一明确匹配，歧义留待确认，不靠行号或重名首条猜测。
- **分页是编号页码**：`[class*="pagesItem"]`，当前页带 `current` 类。`gotoNextPage` 点「当前页+1」那个页码，不是"下一页"文本按钮。
- **风控信号**：出现验证码即 `RATE_LIMITED`，已安全收割的部分保留，停止并建议稍后续跑，不硬闯。
- **space 丢失**：ego 浏览器被关/崩溃 → `SPACE_LOST`，重新 `login` 即可，state 里的 run 游标还在。
- **卡片行格式**：候选人卡片（`.talent-common-card`）的 innerText 是 `[姓名, 活跃度, 立即沟通, N年, 学历, 现居地, (期望)?, (意向)?, 职业标签：, ...标签, 工作段..., 教育段...]`。当前职位取「至今」那段。详见 [references/selectors.md](references/selectors.md)。

选择器细节、page-map 结构、漂移自愈流程见 [references/selectors.md](references/selectors.md)。

## 与 cskh-sourcing 分发器的关系

- `cskh-sourcing` 是通用入口，收到 sourcing 请求时先问平台。
- 用户选择脉脉后，`cskh-sourcing` 把上下文交给 `cskh-sourcing-maimai` 执行。
- 用户直接说脉脉相关词时，优先触发本 skill，跳过平台选择。

## See also

- `cskh-align`：JD → 寻访画像（SourcingRequest）
- `cskh-sourcing`：多平台分发器
- `ego-browser` skill：ego-lite API 事实源
- [references/selectors.md](references/selectors.md)：page-map 结构与漂移自愈
- [references/filters.md](references/filters.md)：筛选码表（年限/学历/排序）
- [references/hunter-export.md](references/hunter-export.md)：tags.csv / sourcing raw json 出口契约（v2）

## 人工短名单与后续跟进

从一次采集结果开始，用 `review --run RUN --format html` 生成审核页。审核人可按人记录入选、淘汰、暂缓及理由，导出决定，再用 `review --run RUN --import FILE` 保存。按入选状态导出即可交付短名单。[审核命令和示例](references/manual-review.md)

需要首次联系、拟回复或重新联系时，先由用户选择渠道与机会，核对资料或已有消息中的具体依据，再用 `follow-up` 生成草稿。人工确认后可在本机记录进展。草稿与实际发送分别记录。[跟进命令和示例](references/follow-up.md)

处理待筛选投递时，先读取 applications 任务，按唯一候选人标识和人工指定的 pass 或 reject 执行 application-review，回读当前页面操作入口。投递状态仅作预览。

验收筛选变更时，先运行脱敏样本测试。真实复验只传一个变动用例给 `node scripts/check-filter.mjs 关键词 '筛选JSON'`。该入口只调用一次搜索。失败时查看原页及回执，停止本轮，不循环调用或拆开重试。人工解除验证后，只传入待确认的一项。
