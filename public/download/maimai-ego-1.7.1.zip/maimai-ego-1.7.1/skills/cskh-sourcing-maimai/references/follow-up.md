# 准备联系与记录跟进

`follow-up` 在本机保存草稿、人工审核结果和跟进备注。每份草稿都包含渠道、目标、引用的依据与正文。准备前先确认用户给出的机会或岗位事实，只有对方的姓名不足以定位记录。以下为虚构示例，实际使用时替换为读取结果。

## 首次联系和再次联系

从采集任务中选出唯一的候选人，优先使用列表中的 candidateId。没有 ID 时可改用同一次采集的唯一 fingerprint。引用确切的履历原文，并填写用户选定的渠道和机会。Skill 可按已核实事实拟写正文并传入 `--text`，省略时 CLI 使用简短邀约模板。

```bash
node scripts/mm.mjs follow-up --action draft --kind first --run example --candidate-id 202 --channel 脉脉 --opportunity 设计主管 --evidence 曾负责工业设计团队
```

再次联系使用 `--kind reactivate`。先用 resources 读取储备或历史对象，比较其已知经历与本次机会；联系方式和意愿需要单独确认。渠道字段只用于人工审核。

## 回复已有会话

先用 inbox 确认具体会话，再用 thread 取得本机回执。在已加载内容里核对双方的发言，选出候选人的原话。根据用户确认的岗位信息拟回复；缺少答案时请用户提供，或写明确的待核实回复。CLI 核对回执的会话 ID 及引用原文，不能判定消息作者或核实岗位承诺。

```bash
node scripts/mm.mjs follow-up --action draft --kind reply --thread-id 888 --thread-file /本机输出目录/thread-123.json --evidence '请问工作地点？' --text '这个岗位的工作地点在上海，您是否方便？'
```

## 审核和跟进

将姓名、渠道、依据和完整正文展示给用户。用户明确确认这份正文后，把返回的 id 作为 draft-id 登记。改文案时重新生成草稿，保留旧稿历史，新稿重新审核。审批只登记本机状态。跟进备注记录顾问实际观察或决定，避免将拟稿写成已联系。

```bash
node scripts/mm.mjs follow-up --action approve --draft-id 已确认的草稿ID
node scripts/mm.mjs follow-up --action record --draft-id 草稿ID --note '岗位地点仍待核实，先暂缓'
node scripts/mm.mjs follow-up --action list
```

记录存放在当前 MAIMAI_STATE_DIR 下的 follow-up.json。正文、引用和备注可能包含业务资料，请使用原项目的本地资料保存位置。
