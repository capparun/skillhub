# 人工审核与短名单

对已有采集任务执行 `review --run hiring --format html`，打开输出文件。展开资料，选择入选、淘汰或暂缓并填写理由。点击“导出入选名单”可保存短名单 JSON。“保存全部决定”下载全部已审核结果，再用 `review --run hiring --import review-decisions.json` 持久保存本轮修改。页面中未导出的编辑在关闭后丢失。待审行在导入时跳过，已有决定保留。

直接记录可用 `review --run hiring --candidate-id 123 --decision select --reason '有同类产品经验'`。可选唯一的 `--profile-url` 或本轮的 `--fingerprint` 替代 ID。身份重复或缺失的记录需要核对后才能审核。

`review --run hiring --filter select --format csv` 可导出入选名单，格式支持 CSV、JSON、HTML。审核记录与修改历史保存在采集任务目录的 `manual-review/decisions.json`，并发写入遇锁会停止。导出文件含所选候选人信息，保存在本机。

2026-11-18，macOS Ego 浏览器使用虚构样本验证了打开 HTML、选择入选、填写理由、下载短名单和全部决定 JSON、导入及重新打开审核页。页面回读的决定和理由与输入一致。已审核条目的可选项为入选、淘汰、暂缓。
