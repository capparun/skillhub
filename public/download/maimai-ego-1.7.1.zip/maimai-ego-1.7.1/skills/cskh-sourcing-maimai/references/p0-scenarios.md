# Ego 脉脉 P0 场景与动作

版本：1.4.0。这里只说明源码能力与验收要求；真实页面端到端结果由本轮验收记录确认。当前不宣称全部通过，不提供免风控保证。

## 场景边界

| 场景 | 动作 | 边界 |
|---|---|---|
| 使用准备 | login、health、explore | 人工登录；健康检查不等于会员权限和额度核验 |
| 找人 | search，关键词或筛选，翻页与人数上限 | 不需要职位、JD、JBF |
| 看人 | candidate 指定候选人；harvest 批量详情 | 只读公开可见资料；身份歧义停止 |
| 交付 | export CSV、JSON、HTML | HTML 本地审核，无消息发送或平台修改 |
| 查已有资源 | resources：个人储备、企业储备、好友、沟通管理 | 沟通管理仅读取对象列表，不打开具体聊天；个人储备支持分组 |

附件下载是可选动作，不属于 P0 必需验收；默认不下载、不读取 PDF。发布职位、处理投递状态、加入储备、修改分组、发送消息均不在本版操作范围。

## 可独立调用的原子 CLI

CLI 目前随 Skill 一起分发，但不要求由 Skill 编排执行。设 `MM` 为安装目录下 `scripts/mm.mjs` 的绝对路径；每条命令输出 `{ok, code, data, hint}`。以下占位参数需替换为本次实际选择的值：

```bash
node "$MM" login
node "$MM" login --resume
node "$MM" health
node "$MM" explore --query 产品经理
node "$MM" search --query 产品经理 --pages 1 --limit 5 --run review-001
node "$MM" resources --source personal --pages 1 --limit 5 --run reserve-001
node "$MM" resources --source personal --group 已存在分组名 --limit 5 --run group-001
node "$MM" resources --source enterprise --limit 5 --run enterprise-001
node "$MM" resources --source friends --limit 5 --run friends-001
node "$MM" resources --source history --limit 5 --run history-001
node "$MM" candidate --run review-001 --candidate-id 从列表返回的ID
node "$MM" harvest --run review-001 --limit 5
node "$MM" export --run review-001 --format html
node "$MM" export --run review-001 --format csv
node "$MM" export --run review-001 --format json
node "$MM" finish
```

无 candidateId 时可使用列表返回的 `--fingerprint`，不能自行编造。`candidate` 依赖已保存的 run 列表，以限定目标身份；`export` 仅依赖本地文件，不启动浏览器。可用 `MAIMAI_STATE_DIR` 设置独立状态目录，测试须隔离真实任务数据。一个状态目录、一个浏览器空间内串行执行。

## 数据真实性

- 优先稳定 candidateId/profileUrl 关联；缺稳定标识的唯一匹配只作为受限降级，不等于稳定身份认证。
- 同名歧义不拼接详情、不静默去重；保留记录并提示待确认。
- 缺失年限、学历显示待确认；没有评估要求时不做岗位判定。
- 保留来源、读取状态、缺失字段和失败信息；增量去重不应隐藏身份不确定的记录。
- 遇到验证码、会话失效、页面结构变化或读取失败，检查 `ok/code` 与详细错误后停止，不自动改用 OpenCLI。

## 必须完成的验收

1. 页面登录、健康检查及异常状态。
2. 搜索条件、人数上限、翻页与列表身份字段。
3. 单人及批量详情读取，确认对象一致。
4. 个人储备、企业储备、好友、历史对象列表和个人分组的只读读取；权限受限应如实报告。
5. CSV/JSON/HTML 内容对应原记录，HTML 可打开，无外部请求或注入。
6. 缺失信息、同名歧义、零结果、中断恢复等回归。

只有以上实际运行证据可支持验收结论，源码存在和模拟测试通过不能替代真实页面通过。
