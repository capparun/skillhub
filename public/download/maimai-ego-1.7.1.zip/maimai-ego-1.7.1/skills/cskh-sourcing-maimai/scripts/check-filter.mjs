// One explicit case per invocation. No automatic retries or batch expansion.
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const [query, filters, ...extra] = process.argv.slice(2);
let valid = false;
try {
  const value = JSON.parse(filters);
  valid = query && value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length > 0;
} catch {}
if (!valid || extra.length) {
  console.error('用法：node scripts/check-filter.mjs 关键词 单条筛选条件JSON');
  process.exit(2);
}
const cli = fileURLToPath(new URL('./mm.mjs', import.meta.url));
const result = spawnSync(process.execPath,[cli,'search','--query',query,'--filters',filters,'--limit','1'],{encoding:'utf8'});
const receipt = JSON.parse(result.stdout);
console.log(JSON.stringify({ok:receipt.ok, code:receipt.code, hint:receipt.hint, tags:receipt.data?.filterTags, observed:receipt.data?.observed, step:receipt.data?.step, signal:receipt.data?.risk === 'captcha' || receipt.hint?.includes('页面要求验证') ? 'verification_prompt' : undefined}));
process.exitCode = result.status ?? 1;
