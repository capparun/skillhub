// Atomic actions on one stable-ID card in the currently bound list. No API writes.
const actionReceipt = { action: ARGS.action, candidateId: ARGS['candidate-id'], submitted: false, verified: false };

async function actionGuard(page) {
  if (!(await detectLogin(page)).loggedIn) throw new MmError('NOT_LOGGED_IN', '请恢复招聘端登录后再操作');
  if ((await detectRisk(page)).hasCaptcha) throw new MmError('RATE_LIMITED', '页面出现验证提示，已停止');
}
async function actionTarget(page) {
  await actionGuard(page);
  const r = await page.evaluate(id => {
    document.querySelectorAll('[data-mm-action-target]').forEach(e => e.removeAttribute('data-mm-action-target'));
    const cards = [...document.querySelectorAll('.talent-common-card')].filter(e => {
      const ids = [...new Set([...e.querySelectorAll('[id]')].map(n => n.id.match(/^(?:groups|talentDiscover)_discover_list_pc_(\d+)_\d+$/)?.[1]).filter(Boolean))];
      return ids.length === 1 && ids[0] === id && e.getClientRects().length;
    });
    if (cards.length !== 1) return null;
    cards[0].setAttribute('data-mm-action-target', '1');
    return { candidateId: id, name: cards[0].querySelector('[class*="name___"]')?.textContent.trim() || null };
  }, String(ARGS['candidate-id']));
  if (!r?.name) throw new MmError('IDENTITY_UNCERTAIN', '当前列表无唯一稳定 ID 卡片；先用 search/resources 定位候选人');
  actionReceipt.name = r.name;
  return r;
}
async function actionMenu(page) {
  await actionTarget(page);
  await page.hover('[data-mm-action-target="1"] .anticon[class*="button___"]');
  await page.waitForFunction(() => [...document.querySelectorAll('[role="tooltip"]')].some(e => e.getClientRects().length && e.innerText.includes('打开公开档案')), undefined, {timeout:5000});
  return page.evaluate(() => {
    document.querySelectorAll('[data-mm-action-menu]').forEach(e => e.removeAttribute('data-mm-action-menu'));
    const menus = [...document.querySelectorAll('[role="tooltip"]')].filter(e => e.getClientRects().length && e.innerText.includes('打开公开档案'));
    if (menus.length !== 1) return [];
    menus[0].setAttribute('data-mm-action-menu', '1');
    return menus[0].innerText.split('\n').map(t => t.trim()).filter(Boolean);
  });
}
async function actionClickText(page, scope, text) {
  const count = await page.evaluate(({scope,text}) => {
    document.querySelectorAll('[data-mm-action-click]').forEach(e => e.removeAttribute('data-mm-action-click'));
    const root = document.querySelector(scope);
    const norm = s => s.replace(/\s/g,'');
    const els = [...(root?.querySelectorAll('*') || [])].filter(e => e.getClientRects().length && norm(e.innerText || '') === norm(text) && ![...e.children].some(c => norm(c.innerText || '') === norm(text)));
    if (els.length === 1) els[0].setAttribute('data-mm-action-click','1');
    return els.length;
  }, {scope,text});
  if (count !== 1) throw new MmError('SELECTOR_MISSING','操作入口缺失或不唯一：'+text);
  await page.click('[data-mm-action-click="1"]');
}
async function actionModal(page, title) {
  await page.waitForFunction(t => [...document.querySelectorAll('[role="dialog"]')].some(e => e.getClientRects().length && (e.getAttribute('aria-label') === t || [...e.querySelectorAll('.ant-modal-title,.mui-modal-title')].some(n => n.textContent.trim() === t))), title, {timeout:7000});
  const found = await page.evaluate(t => {
    document.querySelectorAll('[data-mm-action-modal]').forEach(e => e.removeAttribute('data-mm-action-modal'));
    const els = [...document.querySelectorAll('[role="dialog"]')].filter(e => e.getClientRects().length && [...e.querySelectorAll('.ant-modal-title,.mui-modal-title')].some(n => n.textContent.trim() === t));
    if (els.length !== 1) return false;
    els[0].setAttribute('data-mm-action-modal','1');return true;
  },title);
  if (!found) throw new MmError('SELECTOR_MISSING','未找到唯一操作弹窗');
}
const ACTION_MODAL = '[data-mm-action-modal="1"]';
async function actionCloseModal(page) { await page.click(ACTION_MODAL+' button[aria-label="Close"]'); }
async function actionSubmit(page) {
  await actionGuard(page);
  // Mark uncertain BEFORE dispatch: a transport failure may follow a successful platform write.
  actionReceipt.submitted = true;
  await actionClickText(page,ACTION_MODAL,'确 定');
  await page.waitForFunction(() => !document.querySelector('[data-mm-action-modal="1"]')?.getClientRects().length, undefined, {timeout:10000});
}
async function actionDetail(page) {
  const target = await actionTarget(page);
  await page.click('[data-mm-action-target="1"] [class*="name___"]');
  await page.waitForFunction(id => [...document.querySelectorAll('.ant-drawer-open [id]')].some(n => n.id.match(/_discover_list_pc_(\d+)_\d+$/)?.[1] === id), target.candidateId, {timeout:10000});
  const r = await page.evaluate(() => {
    const drawer = document.querySelector('.ant-drawer-open');
    const ids = [...new Set([...drawer.querySelectorAll('[id]')].map(n=>n.id.match(/_discover_list_pc_(\d+)_\d+$/)?.[1]).filter(Boolean))];
    return {ids,text:drawer.innerText};
  });
  if (r.ids.length !== 1 || r.ids[0] !== target.candidateId || !r.text.includes(target.name)) throw new MmError('IDENTITY_UNCERTAIN','回读档案身份不一致');
  return r;
}
async function actionCloseDetail(page) { await page.press('body','Escape'); await page.waitForFunction(()=>!document.querySelector('.ant-drawer-open'),undefined,{timeout:5000}); }
async function actionNote(page) {
  // Read existing notes before append; exact text is idempotent across state directories too.
  await actionDetail(page);
  await page.waitForFunction(()=>{const root=document.querySelector('.ant-drawer-open [class*="remarks___"]');return root && (/备注（0）/.test(root.innerText) || root.querySelector('[class*="remarksItem___"]'));},undefined,{timeout:10000});
  const existing = await page.evaluate(text => {
    const item=[...document.querySelectorAll('.ant-drawer-open [class*="remarksItem___"]')].find(e=>e.querySelector('[class*="descExpanded___"]')?.textContent.trim()===text);
    return item ? {self:[...item.children].some(n=>!n.className.includes('descExpanded___')&&n.textContent.trim()==='仅自己可见')} : null;
  },ARGS.text);
  await actionCloseDetail(page);
  if (existing) return {alreadyApplied:true,verified:existing.self === (ARGS.visibility==='self'),visibilityVerified:existing.self === (ARGS.visibility==='self'),evidence:'已有相同文字备注，不重复追加',visibility:existing.self?'self':'team'};
  const menu = await actionMenu(page);
  if (!menu.includes('添加备注')) throw new MmError('UNAVAILABLE','当前候选人没有添加备注入口');
  await actionClickText(page,'[data-mm-action-menu="1"]','添加备注');
  await actionModal(page,'添加备注');
  await page.fill(ACTION_MODAL+' textarea',ARGS.text);
  const check = await page.evaluate(() => document.querySelector('[data-mm-action-modal="1"] input[type="checkbox"]')?.checked);
  if (check === undefined) throw new MmError('SELECTOR_MISSING','未找到备注可见范围');
  if (check !== (ARGS.visibility === 'self')) await page.click(ACTION_MODAL+' input[type="checkbox"]');
  const form = await page.evaluate(() => ({text:document.querySelector('[data-mm-action-modal="1"] textarea').value,self:document.querySelector('[data-mm-action-modal="1"] input').checked}));
  if (form.text !== ARGS.text || form.self !== (ARGS.visibility === 'self')) throw new MmError('FORM_MISMATCH','备注或可见范围未正确填写');
  if (!ARGS.apply) {await actionCloseModal(page);return {preview:{text:ARGS.text,visibility:ARGS.visibility}};}
  await actionSubmit(page);
  await actionDetail(page);
  await page.waitForFunction(text => [...document.querySelectorAll('.ant-drawer-open [class*="remarksItem___"] [class*="descExpanded___"]')].some(e=>e.textContent.trim()===text),ARGS.text,{timeout:10000});
  const evidence = await page.evaluate(text => {
    const e=[...document.querySelectorAll('.ant-drawer-open [class*="remarksItem___"] [class*="descExpanded___"]')].find(e=>e.textContent.trim()===text);
    return e ? {text:e.textContent.trim(),self:[...e.parentElement.children].some(n=>!n.className.includes('descExpanded___')&&n.textContent.trim()==='仅自己可见')} : null;
  },ARGS.text);
  await actionCloseDetail(page);
  if (!evidence || evidence.self !== (ARGS.visibility==='self')) throw new MmError('READBACK_UNCONFIRMED','备注正文存在，但可见范围不一致');
  return {verified:true,visibilityVerified:true,evidence};
}
async function actionFollow(page) {
  const menu = await actionMenu(page);
  const before = menu.includes('取消特别关注') ? 'on' : menu.includes('特别关注') ? 'off' : null;
  if (!before) throw new MmError('UNAVAILABLE','当前候选人没有关注入口');
  if (before === ARGS.state) return {alreadyApplied:true,verified:true,before,after:before};
  if (!ARGS.apply) return {preview:{before,after:ARGS.state}};
  await actionGuard(page);actionReceipt.submitted=true;
  await actionClickText(page,'[data-mm-action-menu="1"]',before==='on'?'取消特别关注':'特别关注');
  // First observe completion before navigation so reload cannot abort the write.
  await page.hover('[data-mm-action-target="1"] .anticon[class*="button___"]');
  await page.waitForFunction(want => [...document.querySelectorAll('[role="tooltip"]')].some(e=>e.getClientRects().length && e.innerText.split('\n').some(t=>t.trim()===want)),ARGS.state==='on'?'取消特别关注':'特别关注',{timeout:10000});
  // Reload to avoid treating an optimistic local toggle as persisted state.
  await page.reload();await waitSearchSettled(page);
  const afterMenu = await actionMenu(page);
  const after = afterMenu.includes('取消特别关注')?'on':afterMenu.includes('特别关注')?'off':null;
  if (after !== ARGS.state) throw new MmError('READBACK_UNCONFIRMED','关注提交后未回读到目标状态，不重试');
  return {verified:true,before,after};
}
async function actionGroups(page) {
  const menu = await actionMenu(page);
  const title = menu.includes('修改分组') ? '修改分组' : menu.includes('加入储备') ? '加入储备' : null;
  if (!title) throw new MmError('UNAVAILABLE','当前候选人没有储备入口');
  await actionClickText(page,'[data-mm-action-menu="1"]',title);await actionModal(page,title);
  await page.waitForSelector(ACTION_MODAL+' [class*="groupItem___"]');
  return page.evaluate(() => [...document.querySelectorAll('[data-mm-action-modal="1"] [class*="groupItem___"]')].map((e,i)=>({index:i,name:e.textContent.trim(),scope:e.parentElement.querySelector('h4')?.textContent.includes('企业储备')?'enterprise':'personal',selected:e.className.includes('activeGroupItem')})));
}
async function actionReserve(page) {
  const before = await actionGroups(page);
  if (!ARGS.group) {await actionCloseModal(page);return {preview:{groups:before}};}
  const matches=before.filter(g=>g.name===ARGS.group && g.scope===ARGS.scope);
  if(matches.length!==1) throw new MmError('GROUP_NOT_FOUND','分组缺失或不唯一；请先预览可用分组');
  const target=matches[0];
  if(target.selected){await actionCloseModal(page);return {alreadyApplied:true,verified:true,group:target};}
  if(!ARGS.apply){await actionCloseModal(page);return {preview:{add:target,preserve:before.filter(g=>g.selected)}};}
  await page.click(ACTION_MODAL+' [class*="groupItem___"] >> nth='+target.index);
  await actionSubmit(page);
  const after = await actionGroups(page);
  const kept=before.filter(g=>g.selected).every(g=>after.some(a=>a.name===g.name&&a.scope===g.scope&&a.selected));
  const added=after.some(g=>g.name===target.name&&g.scope===target.scope&&g.selected);
  await actionCloseModal(page);
  if(!kept||!added)throw new MmError('READBACK_UNCONFIRMED','储备提交后分组回读不一致，不重试');
  return {verified:true,added:target,preserved:before.filter(g=>g.selected)};
}
async function actionJobOptions(page) {
  const menu=await actionMenu(page);
  if(!menu.includes('加入其他职位'))throw new MmError('UNAVAILABLE','当前候选人没有加入职位入口');
  await actionClickText(page,'[data-mm-action-menu="1"]','加入其他职位');await actionModal(page,'加入其他职位');
  await page.click(ACTION_MODAL+' input[placeholder="请选择职位"]');
  await page.waitForFunction(()=>[...document.querySelectorAll('[data-mm-action-modal="1"] .commonList')].some(e=>e.getClientRects().length&&!e.innerText.includes('加载中')),undefined,{timeout:10000});
  return page.evaluate(()=>[...document.querySelectorAll('[data-mm-action-modal="1"] .commonList [class*="itemStyle___"]')].map((e,i)=>({index:i,title:e.querySelector('[title]')?.getAttribute('title'),company:e.querySelector('[class*="showCompanyContent___"]')?.textContent.trim(),owner:e.querySelectorAll('[class*="showCompanyContent___"]')[2]?.textContent.trim(),date:[...e.querySelector('[class*="other___"]').children].at(-1)?.textContent.trim(),text:e.innerText})));
}
async function actionJobRecords(page) {
  await actionDetail(page);
  const count=await page.evaluate(()=>{const n=[...document.querySelectorAll('.ant-drawer-open span')].find(e=>/^职位记录·\d+$/.test(e.textContent.trim()));if(n){n.setAttribute('data-mm-job-records','1');return Number(n.textContent.split('·')[1]);}return -1;});
  if(count<0)throw new MmError('READBACK_UNCONFIRMED','无法检查已有职位记录');
  if(count===0){await actionCloseDetail(page);return [];}
  await page.click('[data-mm-job-records="1"]');
  await page.waitForSelector('.ant-drawer-open [class*="oneSub___"]');
  const records=await page.evaluate(()=>[...document.querySelectorAll('.ant-drawer-open [class*="oneSub___"]')].map(sub=>{
    const row=sub.parentElement.parentElement;
    return {title:row.querySelector('[class*="one___"]')?.textContent.trim(),owner:sub.querySelectorAll('[class*="oneLeft___"]')[0]?.textContent.trim(),date:sub.querySelectorAll('[class*="oneLeft___"]')[1]?.textContent.trim(),status:row.querySelector('[class*="two___"]')?.textContent.trim()};
  }));
  await actionCloseDetail(page);return records;
}
function sameJobRecord(record, job) {return record.title===job.title && record.owner===job.owner && record.date===job.date;}
async function actionExistingJob(page,job) {
  const records=await actionJobRecords(page);
  const sameTitle=records.filter(r=>r.title===job.title);
  if(sameTitle.length>1 || (sameTitle.length===1&&!sameJobRecord(sameTitle[0],job)))throw new MmError('JOB_IDENTITY_UNCERTAIN','已有同名职位记录无法唯一对应公司，不修改');
  return sameTitle.length===1;
}
async function actionJob(page) {
  const options=await actionJobOptions(page);
  if(!ARGS.job||!ARGS.company){await actionCloseModal(page);return {preview:{options}};}
  const matches=options.filter(j=>j.title===ARGS.job&&j.company===ARGS.company);
  if(matches.length!==1 || options.filter(j=>j.title===ARGS.job).length!==1)throw new MmError('JOB_NOT_FOUND','当前可见职位无唯一标题+公司匹配；同名职位不冒险关联');
  const job=matches[0];
  if(!job.owner||!job.date)throw new MmError('JOB_IDENTITY_UNCERTAIN','职位负责人或日期缺失，无法进行独立回读');
  await actionCloseModal(page);
  if(await actionExistingJob(page,job))return {alreadyApplied:true,verified:true,job,identityVerification:'title-owner-date',evidence:'已有职位关联，保留原跟进状态；记录页面不显示公司或职位ID'};
  if(!ARGS.apply)return {preview:{job,status:'待沟通'}};
  const refreshed=await actionJobOptions(page);
  const same=refreshed.filter(j=>j.title===job.title&&j.company===job.company&&sameJobRecord(j,job));
  if(same.length!==1 || refreshed.filter(j=>j.title===job.title).length!==1)throw new MmError('JOB_IDENTITY_UNCERTAIN','职位选项已变化，停止提交');
  await page.click(ACTION_MODAL+' .commonList [class*="itemStyle___"] >> nth='+same[0].index);
  await page.waitForSelector(ACTION_MODAL+' .ant-select-selection-item');
  const status=await page.evaluate(()=>document.querySelector('[data-mm-action-modal="1"] .ant-select-selection-item')?.textContent.trim());
  if(status!=='待沟通')throw new MmError('FORM_MISMATCH','职位跟进状态不是待沟通，停止');
  await actionSubmit(page);
  const records=await actionJobRecords(page);
  const matched=records.filter(r=>sameJobRecord(r,job));
  if(matched.length!==1 || matched[0].status!==status)throw new MmError('READBACK_UNCONFIRMED','职位提交后记录不唯一或状态不一致，不重试');
  return {verified:true,job,status,identityVerification:'title-owner-date',evidence:matched[0]};
}
async function actionPublicProfile(page,task) {
  const menu=await actionMenu(page);
  if(!menu.includes('打开公开档案'))throw new MmError('UNAVAILABLE','当前候选人没有公开档案入口');
  const waiting=page.waitForEvent('popup',{timeout:10000});
  // Attach rejection immediately so a failed click cannot cause an unhandled rejection.
  waiting.catch(()=>{});
  await actionClickText(page,'[data-mm-action-menu="1"]','打开公开档案');
  const profile=await waiting;
  await profile.waitForFunction(()=>document.body?.innerText.includes('工作经历'),undefined,{timeout:15000});
  const url=new URL(await profile.url());
  if(url.hostname!=='maimai.cn'||url.pathname!=='/profile/detail'||url.searchParams.get('dstu')!==String(ARGS['candidate-id']))throw new MmError('IDENTITY_UNCERTAIN','公开档案地址与目标身份不符');
  const title=await profile.title();
  if(!title.includes(actionReceipt.name))throw new MmError('IDENTITY_UNCERTAIN','公开档案姓名与卡片不一致');
  return {verified:true,pageLabel:profile.label,url:'https://maimai.cn/profile/detail?dstu='+ARGS['candidate-id'],title};
}
async function main() {
  const task=await getTask();const page=getPage(task);
  await actionTarget(page);
  const handlers={'note':actionNote,'follow':actionFollow,'reserve':actionReserve,'job-assign':actionJob,'public-profile':actionPublicProfile};
  if(!handlers[ARGS.action])throw new MmError('USAGE','本轮不支持该动作');
  const result=await handlers[ARGS.action](page,task);
  Object.assign(actionReceipt,result);
  emit(true,result.alreadyApplied?'ALREADY_APPLIED':result.verified?'VERIFIED':'PREVIEW',actionReceipt);
}
main().catch(e=>emit(false,actionReceipt.submitted?'WRITE_UNCONFIRMED':(e.code||'ACTION_FAILED'),{...actionReceipt,errorCode:e.code||'ACTION_FAILED'},e.hint||e.message));
