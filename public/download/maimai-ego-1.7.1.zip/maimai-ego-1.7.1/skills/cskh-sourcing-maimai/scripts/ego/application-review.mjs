// Preview the current controls of a single application without invoking them.
async function previewApplication() {
  const previous = ARGS.__row;
  const jobId = previous.jobId || '';
  const page = getPage(await getTask());
  await navigateReadView(page, 'applications', jobId);

  const { rows } = await readCandidateRows(page, 'applications', jobId);
  const field = ARGS['candidate-id'] ? 'candidateId' : 'fingerprint';
  const matches = rows.filter(row =>
    row[field] && row[field] === previous[field] && row.sourceContext === previous.sourceContext
  );
  if (matches.length !== 1) {
    throw new MmError('IDENTITY_UNCERTAIN', '当前投递页无法唯一核对该候选人与投递职位');
  }

  const row = matches[0];
  const control = ARGS.decision === 'pass' ? '通过初筛' : '不合适';
  const visible = row.lines.some(line => line === control);
  if (!visible) throw new MmError('CONTROL_UNAVAILABLE', '当前投递卡片未显示所选操作');
  emit(true, 'OK', {
    mode: 'preview', decision: ARGS.decision, control, submitted: false,
    source: 'applications', jobId, sourceContext: row.sourceContext,
    candidateId: row.candidateId, name: row.name
  }, '已核对当前卡片及操作文案，仅预览');
}

previewApplication().catch(error =>
  emit(false, error.code || 'OBSERVER_ERROR', null, error.hint || error.message)
);
