// Read one candidate by saved identity; retain original row index for reports.
function identityMatches(expected, actual) {
  if (expected.candidateId && actual.candidateId) return String(expected.candidateId) === String(actual.candidateId);
  if (expected.profileUrl && actual.profileUrl) return expected.profileUrl === actual.profileUrl;
  return Boolean(expected.fingerprint && expected.fingerprint === actual.fingerprint);
}

async function main() {
  const expected = ARGS.expectedRows;
  const maxPages = Math.max(1, Math.ceil((ARGS.totalFromSearch || expected?.length || 0) / (ARGS.pageSize || 30)));
  if (!ARGS.run || !Array.isArray(expected)) throw new MmError('USAGE', '需要已保存的run列表');
  const selected = expected.filter(r => ARGS['candidate-id'] ? String(r.candidateId) === String(ARGS['candidate-id']) : ARGS.fingerprint && r.fingerprint === ARGS.fingerprint);
  if (selected.length !== 1) throw new MmError('IDENTITY_UNCERTAIN', '指定候选人不存在或身份不唯一');
  const originalIndex = expected.indexOf(selected[0]);
  ARGS.expectedRows = selected;
  expected.splice(0, expected.length, ...selected);
  let cursor = 0;
  const limit = 1;
  if (!Number.isInteger(limit) || limit < 1) throw new MmError('USAGE', '--limit必须为正整数');
  const task = await getTask(); const page = getPage(task);
  const details = [], errors = [];
  try {
    if (expected[cursor]?.readSource) await navigateReadView(page, expected[cursor].readSource, expected[cursor].jobId);
    else if (expected[cursor]?.resourceSource) await navigateResource(page, expected[cursor]);
    else if (expected[cursor]?.sourceUrl) { await page.goto(expected[cursor].sourceUrl); await waitSearchSettled(page); }
    else await gotoSearch(page, ARGS.query || '');
    if (ARGS.filters) await applyFilters(page, ARGS.filters);
    const resourceSource = expected[cursor]?.resourceSource;
    const readSource = expected[cursor]?.readSource;
    const readRows = () => readSource ? readCandidateRows(page,readSource,expected[cursor].jobId) : resourceSource ? readResourceRows(page, resourceSource) : markAndReadRows(page);
    let rows = await readRows();
    let visitedPages = 1;
    while (cursor < expected.length && details.length < limit) {
      const target = expected[cursor];
      const risk = await detectRisk(page);
      if (risk.hasCaptcha) throw new MmError('RATE_LIMITED', '发现验证码，已停止');
      let matches = rows.rows.filter(r => identityMatches(target, r));
      while (!matches.length && visitedPages < maxPages && await gotoNextPage(page, readSource ? p => waitReadView(p,readSource,expected[cursor].jobId) : resourceSource ? p => waitResource(p, resourceSource) : p => waitSearchSettled(p))) {
        visitedPages++;
        rows = await readRows();
        matches = rows.rows.filter(r => identityMatches(target, r));
      }
      if (matches.length !== 1) throw new MmError('IDENTITY_UNCERTAIN', '列表已变化或身份不唯一，停止并保留游标');
      const row = matches[0];
      await openDetail(page, row.i);
      const d = await readDetailText(page);
      if (target.candidateId && String(d.candidateId) !== String(target.candidateId)) throw new MmError('IDENTITY_UNCERTAIN', '详情稳定ID与目标卡片不一致');
      if (!d.text || !d.text.includes(row.lines[0])) throw new MmError('IDENTITY_UNCERTAIN', '详情姓名与目标卡片不一致');
      let attachment = null, attachmentErr = null;
      if (ARGS.withAttachment || ARGS['with-attachment']) {
        try { const a = await downloadAttachment(page, ARGS.dlDir); attachment = a.file || null; attachmentErr = a.ok ? null : a.reason; }
        catch(e) { attachmentErr = e.message; }
      }
      details.push({...target, candidateId:target.candidateId || (target.readSource ? d.candidateId : null), attachment, attachmentErr, rowIndex:originalIndex, name:row.lines[0], text:d.text, hasPdf:d.hasPdf, sourceQuery:ARGS.query || '', identityVerification: target.candidateId ? 'card-id-and-detail-name' : 'unique-card-fingerprint-and-detail-name'});
      await closeDetail(page);
      cursor++;
      await sleep(page,1600);
    }
    emit(true,'OK',{runId:ARGS.run,cursor,details,errors,harvested:details.length},'详情读取完成');
  } catch(e) {
    errors.push({rowIndex:originalIndex,candidateId:selected[0].candidateId,profileUrl:selected[0].profileUrl,code:e.code || 'INTERNAL',error:e.hint || e.message});
    try { await closeDetail(page); } catch {}
    emit(false,e.code || 'INTERNAL',{runId:ARGS.run,cursor,details,errors,harvested:details.length},e.hint || e.message);
  }
}
main().catch(e => emit(false,e.code || 'INTERNAL',e.data || null,e.hint || e.message));
