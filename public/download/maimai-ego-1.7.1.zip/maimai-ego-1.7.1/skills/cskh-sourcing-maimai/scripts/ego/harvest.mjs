// harvest.mjs — 详情抽屉批量收割（断点续跑，跨页，节奏 ≥1.6s/人）
// 用法：mm harvest --run <runId> [--limit 10] [--with-attachment]
// 依赖 lib.mjs 注入：ARGS（含 run/query/cursor/pageSize/totalFromSearch）、CTX、PAGE_MAP
// 说明：
//   - cursor 是全局行号（与 search 的扁平 rows 下标一致）。先翻到 cursor 所在页，再跨页收割。
//   - search 与 harvest 之间列表会重排（脉脉按活跃度等排序），所以每条详情都打上卡片姓名（name），
//     由 export 按姓名对齐，不依赖 rowIndex，也不重抓列表（避免多页截断）。
//   - --with-attachment：有附件简历的人顺手下载附件，存到 mm.mjs 注入的 dlDir（downloads/<runId>/），
//     文件名用页面上的原始文件名（格式不假定，实测样例为图片型 .pdf）。单条下载失败不致命，记 attachmentErr 继续。
// 返回：信封 data {runId, cursor, details:[{rowIndex,name,text,hasPdf,attachment,attachmentErr}], errors}
//   mm.mjs 负责把 details 追加写入 detail.jsonl、更新 state.runs[runId].harvest.cursor

function identityMatches(expected, actual) {
  if (expected.candidateId && actual.candidateId) return String(expected.candidateId) === String(actual.candidateId);
  if (expected.profileUrl && actual.profileUrl) return expected.profileUrl === actual.profileUrl;
  return Boolean(expected.fingerprint && expected.fingerprint === actual.fingerprint);
}

async function main() {
  const expected = ARGS.expectedRows;
  const maxPages = Math.max(1, Math.ceil((ARGS.totalFromSearch || expected?.length || 0) / (ARGS.pageSize || 30)));
  if (!ARGS.run || !Array.isArray(expected)) throw new MmError('USAGE', '需要已保存的run列表');
  let cursor = Number(ARGS.cursor || 0);
  const limit = Number(ARGS.limit || 10);
  if (!Number.isInteger(limit) || limit < 1) throw new MmError('USAGE', '--limit必须为正整数');
  const task = await getTask(); const page = getPage(task);
  const details = [], errors = [];
  try {
    if (expected[cursor]?.readSource) await navigateReadView(page, expected[cursor].readSource, expected[cursor].jobId);
    else if (expected[cursor]?.resourceSource) await navigateResource(page, expected[cursor]);
    else if (expected[cursor]?.sourceUrl) { await page.goto(expected[cursor].sourceUrl); await waitSearchSettled(page); }
    else await gotoSearch(page, ARGS.query || '');
    if (ARGS.filters) await applyFilters(page, ARGS.filters);
    const resourceSource = expected[cursor]?.resourceSource;
    const readSource = expected[cursor]?.readSource;
    const readRows = () => readSource ? readCandidateRows(page,readSource,expected[cursor].jobId) : resourceSource ? readResourceRows(page, resourceSource) : markAndReadRows(page);
    let rows = await readRows();
    let visitedPages = 1;
    while (cursor < expected.length && details.length < limit) {
      const target = expected[cursor];
      const risk = await detectRisk(page);
      if (risk.hasCaptcha) throw new MmError('RATE_LIMITED', '发现验证码，已停止');
      let matches = rows.rows.filter(r => identityMatches(target, r));
      while (!matches.length && visitedPages < maxPages && await gotoNextPage(page, readSource ? p => waitReadView(p,readSource,expected[cursor].jobId) : resourceSource ? p => waitResource(p, resourceSource) : p => waitSearchSettled(p))) {
        visitedPages++;
        rows = await readRows();
        matches = rows.rows.filter(r => identityMatches(target, r));
      }
      if (matches.length !== 1) throw new MmError('IDENTITY_UNCERTAIN', '列表已变化或身份不唯一，停止并保留游标');
      const row = matches[0];
      await openDetail(page, row.i);
      const d = await readDetailText(page);
      if (target.candidateId && String(d.candidateId) !== String(target.candidateId)) throw new MmError('IDENTITY_UNCERTAIN', '详情稳定ID与目标卡片不一致');
      if (!d.text || !d.text.includes(row.lines[0])) throw new MmError('IDENTITY_UNCERTAIN', '详情姓名与目标卡片不一致');
      let attachment = null, attachmentErr = null;
      if (ARGS.withAttachment || ARGS['with-attachment']) {
        try { const a = await downloadAttachment(page, ARGS.dlDir); attachment = a.file || null; attachmentErr = a.ok ? null : a.reason; }
        catch(e) { attachmentErr = e.message; }
      }
      details.push({...target, candidateId:target.candidateId || (target.readSource ? d.candidateId : null), attachment, attachmentErr, rowIndex:cursor, name:row.lines[0], text:d.text, hasPdf:d.hasPdf, sourceQuery:ARGS.query || '', identityVerification: target.candidateId ? 'card-id-and-detail-name' : 'unique-card-fingerprint-and-detail-name'});
      await closeDetail(page);
      cursor++;
      await sleep(page,1600);
    }
    emit(true,'OK',{runId:ARGS.run,cursor,details,errors,harvested:details.length},'详情读取完成');
  } catch(e) {
    errors.push({rowIndex:cursor,code:e.code || 'INTERNAL',error:e.hint || e.message});
    try { await closeDetail(page); } catch {}
    emit(false,e.code || 'INTERNAL',{runId:ARGS.run,cursor,details,errors,harvested:details.length},e.hint || e.message);
  }
}
main().catch(e => emit(false,e.code || 'INTERNAL',e.data || null,e.hint || e.message));
