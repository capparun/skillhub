// Only observe the current page; no navigation or active permission probes.
async function main() {
  if (CTX.spaceId == null) {
    emit(false,'SPACE_LOST',{spaceAlive:false,login:'unknown'},'没有已绑定会话，请先 login。');return;
  }
  let task;
  try { task=await getTask(); }
  catch(e){emit(false,e.code||'OBSERVER_ERROR',{spaceAlive:e.code==='SPACE_LOST'?false:null,login:'unknown'},e.hint||e.message);return;}
  const page=getPage(task);
  let login,permissionEvidence;
  try {
    login=await detectLogin(page);
    permissionEvidence=await page.evaluate(()=>{
      const text=document.body?.innerText||'';
      const patterns=[/权限不足/g,/暂无权限/g,/无权访问/g,/请联系管理员/g,/额度不足/g,/次数已用完/g,/今日次数已用完/g,/请升级会员/g,/开通会员/g];
      return [...new Set(patterns.flatMap(pattern=>text.match(pattern)||[]))];
    });
  } catch(e){emit(false,e.code==='USER_CONTROL'?e.code:'OBSERVER_ERROR',{spaceAlive:true,login:'unknown',causeCode:e.code||null},'无法观察当前页面：'+(e.hint||e.message));return;}
  const status=login.loggedIn?'ok':login.hasLoginWall?'expired':'unknown';
  const permissions={status:permissionEvidence.length?'visible_prompt':'not_verified',evidence:permissionEvidence,quota:null};
  const code=status==='ok'?'OK':status==='expired'?'NOT_LOGGED_IN':'AUTH_UNKNOWN';
  emit(status==='ok',code,{spaceAlive:true,login:status,accountHint:login.accountHint,permissions,
    __statePatch:{login:{status,checkedAt:new Date().toISOString(),accountHint:login.accountHint}}},
    status==='ok'?'当前页面有登录导航；权限和额度未作全面验证。':status==='expired'?'当前页面出现登录入口。':'当前页面没有足够登录证据，不能判定退登。');
}
main().catch(e=>emit(false,e.code||'OBSERVER_ERROR',{login:'unknown'},e.hint||e.message));
