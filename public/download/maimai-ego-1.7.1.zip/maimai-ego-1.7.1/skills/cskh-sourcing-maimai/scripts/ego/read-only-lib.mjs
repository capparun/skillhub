// Read-only UI routes observed on 2026-11-18. No HTTP replay or application internals.
const READ_VIEWS={applications:{tab:'2',label:'待处理投递'},recommendations:{tab:'0',label:'推荐'},visitors:{tab:'5',label:'职位访客'}};
const READ_JOB_TITLES=new Map();
async function assertReadSafety(page){
 const s=await page.evaluate(()=>{
  const visible=n=>n.getClientRects().length>0;
  const frame=document.querySelector?.('#imIframe')?.contentDocument;
  const body=(document.body?.innerText||'')+'\n'+(frame?.body?.innerText||'');
  const prompts=[...document.querySelectorAll('[role="dialog"],.ant-modal-content,.ant-message,.ant-notification')].filter(visible).map(n=>n.innerText).join('\n');
  return {login:/扫码登录|密码登录|验证码登录|立即登录/.test(body),risk:/请完成验证|安全验证|操作频繁|访问受限|账号异常/.test(prompts)||/请完成验证|安全验证|操作频繁|访问受限|账号异常/.test(body),permission:/暂无权限|无权限访问|权限不足|额度不足/.test(prompts)};
 });
 if(s.login)throw new MmError('NOT_LOGGED_IN','登录已失效，停止');
 if(s.risk)throw new MmError('RATE_LIMITED','出现验证或限制提示，停止');
 if(s.permission)throw new MmError('CAPABILITY_UNAVAILABLE','页面提示权限或额度不足');
}
async function assertReadView(page,source,jobId='',expectedJobTitle=READ_JOB_TITLES.get(String(jobId))){
 const expected=READ_VIEWS[source];if(!expected)throw new MmError('USAGE','未知读取来源');
 const s=await page.evaluate(()=>({tab:new URL(location.href).searchParams.get('tab'),pid:new URL(location.href).searchParams.get('pid')||'',selected:document.querySelector('[class*="tabContentSelected___"]')?.innerText||'',jobLabel:document.querySelector('[class*="positionNameText___"]')?.innerText||''}));
 if(s.tab!==expected.tab||s.pid!==String(jobId||'')||!s.selected.startsWith(expected.label)||(jobId&&(!expectedJobTitle||s.jobLabel!==expectedJobTitle)))throw new MmError('SOURCE_MISMATCH','栏目或职位不匹配，停止避免采错来源');
 return s;
}
async function waitReadView(page,source,jobId=''){
 let last='',stable=0;
 for(let i=0;i<30;i++){
  await assertReadSafety(page);
  const s=await page.evaluate(()=>{
   const cards=[...document.querySelectorAll('.talent-common-card')];
   const body=document.body?.innerText||'';
   return {signature:cards.map(n=>n.innerText).join('\n'),count:cards.length,empty:/暂无推荐人才|暂无投递|暂无访客|暂无人才|暂无数据|暂无结果|暂无匹配/.test(body),loading:/加载中/.test(body)||[...document.querySelectorAll('.ant-spin-spinning')].some(n=>n.getClientRects().length)};
  });
  const key=JSON.stringify([s.signature,s.empty]);stable=!s.loading&&key===last?stable+1:0;last=key;
  if(!s.loading&&((s.count&&stable>=2&&i>=4)||(s.empty&&stable>=5&&i>=8))){await assertReadView(page,source,jobId);return s;}
  await sleep(page,400);
 }
 throw new MmError('RESULTS_NOT_SETTLED','栏目没有稳定列表或明确空态');
}
async function navigateReadView(page,source,jobId=''){
 if(!READ_VIEWS[source]||(jobId&&!/^\d+$/.test(String(jobId))))throw new MmError('USAGE','来源或职位ID无效');
 if(jobId){
  const lookup=typeof CTX!=='undefined'?CTX.jobLookups?.[String(jobId)]:null;
  let jobs=await readJobs(page,{limit:200,...(lookup?{status:lookup.status,query:lookup.query||lookup.title}:{})});
  let matches=jobs.rows.filter(r=>String(r.jobId)===String(jobId));
  if(!matches.length&&lookup){jobs=await readJobs(page,{limit:200});matches=jobs.rows.filter(r=>String(r.jobId)===String(jobId));}
  if(!matches.length){jobs=await readJobs(page,{status:'closed',limit:200});matches=jobs.rows.filter(r=>String(r.jobId)===String(jobId));}
  if(matches.length!==1)throw new MmError('JOB_NOT_FOUND','已有职位ID未在加载列表中唯一找到，不猜测或创建职位');
  READ_JOB_TITLES.set(String(jobId),matches[0].title);
 }
 const u=new URL('https://maimai.cn/ent/v41/recruit/talents');u.searchParams.set('tab',READ_VIEWS[source].tab);
 if(source==='applications'){u.searchParams.set('applyStatus','1');u.searchParams.set('applyTab','1');}
 if(jobId)u.searchParams.set('pid',jobId);
 await page.goto(u.href);await waitReadView(page,source,jobId);
}
async function readCandidateRows(page,source,jobId=''){
 await assertReadSafety(page);await assertReadView(page,source,jobId);
 const result=await page.evaluate(({source,jobId})=>{
  const nodes=[...document.querySelectorAll('.talent-common-card')];
  const rows=nodes.map((n,i)=>{
   n.setAttribute('data-mm-row',String(i));
   const name=n.querySelector('[class*="name___"]')?.innerText.trim()||'';
   const raw=(n.innerText||'').split('\n').map(s=>s.trim()).filter(Boolean);
   const at=raw.indexOf(name),lines=at>=0?raw.slice(at):raw;
   const ids=[...new Set([...n.querySelectorAll('[id]')].map(e=>e.id.match(/^(?:(?:groups|talentDiscover)_discover_list_pc|visitor_pc)_(\d+)_\d+$/)?.[1]).filter(Boolean))];
   const experience=[...n.querySelectorAll('[class*="singleCompanyContent___"]')].map(e=>e.innerText.trim());
   const fingerprint=name&&experience.length?JSON.stringify([name,...experience]):lines.join('\n');
   const context=n.querySelector('[class*="matchJDLink___"]')?.innerText.trim()||'';
   return {i,name,lines,fingerprint,candidateId:ids.length===1?ids[0]:null,profileUrl:null,identityStatus:ids.length>1?'conflicting_ids':ids.length===1?'stable_id':'fingerprint_only',readSource:source,source,jobId:String(jobId||''),sourceContext:context,sourceUrl:location.href,collectedAt:new Date().toISOString()};
  });
  return {rows,total:nodes.length};
 },{source,jobId});
 if(result.rows.some(r=>r.identityStatus==='conflicting_ids'||!r.name))throw new MmError('IDENTITY_UNCERTAIN','卡片身份冲突或姓名缺失，停止读取');
 return result;
}
async function jobSnapshot(page){
 return page.evaluate(()=>{
  const tabs=[...document.querySelectorAll('div.cursor-pointer')].filter(n=>/^(在招|已关闭)·\d+$/.test(n.innerText||''));
  const selectedStatus=tabs.find(n=>n.querySelector('span'))?.innerText||null;
  const rows=[...document.querySelectorAll('tr[data-row-key]')].filter(n=>n.querySelector('[class*="projectName___"]')).map(n=>{
   const cells=[...n.querySelectorAll('td')].filter(c=>!c.classList.contains('ant-table-row-expand-icon-cell'));
   const count=c=>c?.innerText.trim().split('\n')[0]||null;
   return {jobId:n.getAttribute('data-row-key'),title:n.querySelector('[class*="projectName___"]')?.innerText,company:n.querySelector('[class*="company___"]')?.innerText||null,summary:cells[0]?.innerText||'',todayExposure:count(cells[1]),applications:count(cells[2]),pending:count(cells[3])};
  });
  const body=document.body.innerText;
  return {rows,empty:/暂无数据|暂无职位/.test(body)||(/·0$/.test(selectedStatus||'')&&body.includes('发布职位开启招聘旅程')),loading:/加载中/.test(body),statusText:tabs.map(n=>n.innerText),selectedStatus,query:document.querySelector('input[placeholder="搜索职位或公司"]')?.value};
 });
}
async function waitJobRows(page,status,query){
 let prev='',stable=0;
 for(let i=0;i<35;i++){
  await assertReadSafety(page);const s=await jobSnapshot(page);
  const selected=s.selectedStatus?.startsWith(status==='closed'?'已关闭':'在招');
  const matches=!query||s.rows.every(r=>(r.title+' '+r.company).toLowerCase().includes(query.toLowerCase()));
  const key=JSON.stringify(s);stable=key===prev&&!s.loading?stable+1:0;prev=key;
  if(selected&&s.query===query&&matches&&(s.rows.length||s.empty)&&stable>=4&&i>=7)return s;
  if(i<34)await sleep(page,400);
 }
 throw new MmError('FILTER_NOT_APPLIED','职位列表、状态或关键词未确认生效，未返回旧列表');
}
async function readJobs(page,{status='open',query='',limit=20}={}){
 await page.goto('https://maimai.cn/ent/v41/position/list');
 await page.waitForSelector('input[placeholder="搜索职位或公司"]',{timeout:15000});
 // Finish initial hydration before applying controls, otherwise initial results can overwrite the query.
 await waitJobRows(page,'open','');
 if(status==='closed'){
  const found=await page.evaluate(()=>{
   const nodes=[...document.querySelectorAll('div.cursor-pointer')].filter(n=>/^已关闭(?:·\d+)?$/.test(n.innerText||''));
   if(nodes.length===1)nodes[0].setAttribute('data-mm-closed-jobs','1');return nodes.length;
  });
  if(found!==1)throw new MmError('PAGE_MAP_DRIFT','未找到关闭职位栏目');
  await page.click('[data-mm-closed-jobs="1"]');await waitJobRows(page,status,'');
 }
 if(query){await page.fill('input[placeholder="搜索职位或公司"]',query);await page.press('input[placeholder="搜索职位或公司"]','Enter');}
 const result=await waitJobRows(page,status,query);
 return {source:'jobs',status,query,rows:result.rows.slice(0,limit),loadedCount:result.rows.length,scope:'loaded_page',totals:result.statusText,sourceUrl:await page.url(),collectedAt:new Date().toISOString()};
}

async function waitInbox(page){
 let prev='',stable=0;
 for(let i=0;i<30;i++){
  await assertReadSafety(page);
  const s=await page.evaluate(()=>{
   const d=document.querySelector('#imIframe')?.contentDocument;
   const nodes=[...(d?.querySelectorAll('.message-item[data-msg]')||[])];
   const text=d?.body?.innerText||'';
   return {signature:nodes.map(n=>n.getAttribute('data-msg')).join('\n'),count:nodes.length,empty:/暂无消息|暂无会话|没有聊天记录/.test(text),loading:/加载中/.test(text)};
  });
  const key=JSON.stringify(s);stable=key===prev&&!s.loading?stable+1:0;prev=key;
  if(!s.loading&&((s.count&&stable>=5&&i>=8)||(s.empty&&stable>=5&&i>=8)))return;
  if(i<29)await sleep(page,400);
 }
 throw new MmError('RESULTS_NOT_SETTLED','会话列表尚未加载或没有明确空态，不返回虚假空列表');
}

async function threadSnapshot(page){
 return page.evaluate(()=>{
  const d=document.querySelector('#imIframe')?.contentDocument;
  const selected=d?.querySelector('.message-item-selected[data-msg]');
  let id=null;try{id=String(JSON.parse(selected?.getAttribute('data-msg')).mid)}catch{}
  return {threadId:id,name:d?.querySelector('.dialogue-header-username')?.innerText||'',contextText:d?.querySelector('.dialogue_list_container')?.innerText||''};
 });
}
async function waitThreadContent(page,target,before){
 let previous='',stable=0;
 for(let i=0;i<30;i++){
  await assertReadSafety(page);const s=await threadSnapshot(page);
  const key=JSON.stringify(s);stable=key===previous?stable+1:0;previous=key;
  const changed=before.threadId===target.threadId||!before.contextText||s.contextText!==before.contextText;
  if(s.threadId===target.threadId&&s.name===target.name&&s.contextText.trim()&&!/加载中/.test(s.contextText)&&changed&&stable>=4&&i>=5)return {...s,coverage:'loaded_messages',mayMarkRead:true};
  if(i<29)await sleep(page,400);
 }
 throw new MmError('THREAD_NOT_SETTLED','无法确认上下文属于指定会话，未返回旧消息');
}
