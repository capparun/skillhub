async function readLists(page,source){
 const jobId=ARGS['job-id']||'',limit=Number(ARGS.limit||20),pages=Number(ARGS.pages||1);
 const rows=[];let visited=0,pageSize=0;
 try{
  await navigateReadView(page,source,jobId);
  for(let i=0;i<pages;i++){
   const current=await readCandidateRows(page,source,jobId);visited++;if(!i)pageSize=current.total;
   for(const r of current.rows){if(rows.length>=limit)break;rows.push(r);}
   if(rows.length>=limit||!current.total||i+1>=pages)break;
   if(!await gotoNextPage(page,p=>waitReadView(p,source,jobId)))break;
  }
  emit(true,'OK',{source,jobId,rows,pageSize,pages:visited,rowCount:rows.length,coverage:'collected_sample'},'仅读取；未筛选通过、拒绝或联系候选人');
 }catch(e){emit(false,e.code||'OBSERVER_ERROR',{source,jobId,rows,pageSize,pages:visited,errors:[{code:e.code||'OBSERVER_ERROR',error:e.hint||e.message}]},e.hint||e.message);}
}
async function overview(page){
 await page.goto('https://maimai.cn/ent/v41/ent');
 await page.waitForSelector('text="最近浏览职位"',{timeout:15000});
 await assertReadSafety(page);
 const data=await page.evaluate(()=>{
  const metrics={};
  for(const label of ['待处理投递','通过初筛','沟通中','个人储备']){
   const labels=[...document.querySelectorAll('div,span')].filter(n=>!n.children.length&&n.innerText===label);
   let raw=null;
   for(const node of labels){let p=node.parentElement;for(let i=0;i<3&&p;i++,p=p.parentElement){const text=p.innerText.trim();if(text.startsWith(label)&&text.length<65&&/\d/.test(text)){raw=text;break;}}if(raw)break;}
   metrics[label]={value:raw?.match(/\d+/)?.[0]||null,evidence:raw,status:raw?'observed':'unknown'};
  }
  const alerts=[...document.querySelectorAll('[role="alert"],.ant-notification,.ant-message')].map(n=>n.innerText).filter(Boolean);
  return {metrics,alerts,source:'overview',sourceUrl:location.href,collectedAt:new Date().toISOString(),coverage:'visible_dashboard',note:'首页计数不等于全租户统计；未出现提醒不证明不存在异常'};
 });
 emit(true,'OK',data);
}
async function readInbox(page){
 if(new URL(await page.url()).pathname!=='/ent/v41/im')await page.goto('https://maimai.cn/ent/v41/im');
 await page.waitForSelector('#imIframe',{timeout:15000});
 await page.waitForFunction(()=>document.querySelector('#imIframe')?.contentDocument?.querySelector('.virtualized-message-list'),undefined,{timeout:15000});
 await waitInbox(page);
 await page.evaluate(()=>{document.querySelector('#imIframe').contentDocument.querySelector('.virtualized-message-list').scrollTop=0;});
 await waitInbox(page);
 const rows=[],seen=new Set();let scanned=0,exhausted=false;
 const limit=Number(ARGS.limit||20),pages=Number(ARGS.pages||1);
 for(let i=0;i<pages;i++){
  await assertReadSafety(page);
  const data=await page.evaluate(()=>{
   const d=document.querySelector('#imIframe').contentDocument;
   const list=d.querySelector('.virtualized-message-list');
   return {rows:[...d.querySelectorAll('.message-item[data-msg]')].map(n=>{
    let id=null;try{id=JSON.parse(n.getAttribute('data-msg')).mid}catch{}
    return {threadId:id?String(id):null,name:n.querySelector('.message-user-name')?.innerText||'',title:n.querySelector('.message-user-title')?.innerText||'',preview:n.querySelector('.message-latest-text')?.innerText||'',time:n.querySelector('.message-time')?.innerText||'',unread:n.querySelector('.message-badge')?.innerText||null};
   }),bottom:list.scrollTop+list.clientHeight>=list.scrollHeight-2};
  });
  scanned++;for(const row of data.rows)if(row.threadId&&!seen.has(row.threadId)){seen.add(row.threadId);if(rows.length<limit)rows.push(row);}
  exhausted=data.bottom;if((ARGS.__readCommand==='thread'&&rows.some(r=>r.threadId===ARGS['thread-id']))||rows.length>=limit||data.bottom||i+1>=pages)break;
  await page.evaluate(()=>{const list=document.querySelector('#imIframe').contentDocument.querySelector('.virtualized-message-list');list.scrollTop+=list.clientHeight;});
  await waitInbox(page);
 }
 if(ARGS.__readCommand==='inbox'){emit(true,'OK',{source:'inbox',rows,pages:scanned,coverage:exhausted?'list_end_observed':'loaded_sample',sourceUrl:await page.url(),collectedAt:new Date().toISOString()},'仅列出已有会话，不发送');return;}
 const target=rows.filter(r=>r.threadId===ARGS['thread-id']);
 if(target.length!==1)throw new MmError('THREAD_NOT_FOUND','指定会话不在本次扫描范围；先 inbox 定位，必要时增加 pages/limit', {observedCount:rows.length,scannedPages:scanned});
 const marked=await page.evaluate(id=>{
  const d=document.querySelector('#imIframe').contentDocument;
  for(const n of d.querySelectorAll('[data-mm-thread]'))n.removeAttribute('data-mm-thread');
  const matches=[...d.querySelectorAll('.message-item[data-msg]')].filter(n=>{try{return String(JSON.parse(n.getAttribute('data-msg')).mid)===id}catch{return false}});
  if(matches.length===1)matches[0].setAttribute('data-mm-thread','target');return matches.length;
 },ARGS['thread-id']);
 if(marked!==1)throw new MmError('THREAD_NOT_FOUND','会话已离开可见列表，未按姓名猜测');
 const before=await threadSnapshot(page);
 await page.click('[data-mm-thread="target"]');
 const data=await waitThreadContent(page,target[0],before);
 emit(true,'OK',{...data,threadId:ARGS['thread-id'],source:'thread',sourceUrl:await page.url(),collectedAt:new Date().toISOString()},'读取已加载上下文；可能产生已读状态，不输入、不发送、不下载会话附件');
}
async function main(){
 const cmd=ARGS.__readCommand,page=getPage(await getTask());
 if(READ_VIEWS[cmd])return readLists(page,cmd);
 if(cmd==='jobs'){emit(true,'OK',await readJobs(page,{status:ARGS.status||'open',query:ARGS.query||'',limit:Number(ARGS.limit||20)}));return;}
 if(cmd==='overview')return overview(page);
 if(cmd==='inbox'||cmd==='thread')return readInbox(page);
 throw new MmError('USAGE','未知只读命令');
}
main().catch(e=>emit(false,e.code||'OBSERVER_ERROR',e.data||null,e.hint||e.message));
