const RESOURCE_LABELS = {personal:'个人储备',enterprise:'企业储备',friends:'我的好友',history:'沟通管理'};
async function assertResourceSelected(page, source) {
  const selected=await page.evaluate(label=>{
    const items=[...document.querySelectorAll('[class*="subItem___"][class*="selectedItem___"]')];
    return items.length===1&&(items[0].innerText||'').trim().split(/\r?\n/)[0].trim()===label;
  },RESOURCE_LABELS[source]);
  if(!selected)throw new MmError('RESOURCE_NOT_SELECTED','目标资源栏目未选中，停止避免读取错误来源');
}
async function waitResource(page, source) {
  let previous=null,stable=0;
  for(let attempt=0;attempt<30;attempt++){
    const state=await page.evaluate(kind=>{
      const text=document.body.innerText;
      let cards=[...document.querySelectorAll(kind==='friends'?'[class*="card___"]':'.talent-common-card')];
      if(kind==='friends')cards=cards.filter(n=>n.querySelector('h3,[role="heading"]')?.textContent?.trim()&&n.querySelector('[class*="cardContent___"]'));
      return {login:/扫码登录|密码登录/.test(text),risk:/请完成验证|安全验证/.test(text),loading:/加载中|正在加载/.test(text)||[...document.querySelectorAll('.ant-spin-spinning')].some(n=>n.getClientRects().length),count:cards.length,signature:cards.map(n=>n.innerText).join('\n'),empty:/暂无好友|暂无数据|暂无人才|暂无匹配|暂无结果|没有找到|无匹配|没有相关/.test(text)};
    },source);
    if(state.login)throw new MmError('NOT_LOGGED_IN','登录已失效');
    if(state.risk)throw new MmError('RATE_LIMITED','页面要求验证');
    const key=JSON.stringify([state.count,state.empty,state.signature]);
    stable=!state.loading&&key===previous?stable+1:0;previous=state.loading?null:key;
    if(!state.loading&&((state.count>0&&stable>=2&&attempt>=4)||(state.empty&&stable>=6&&attempt>=10)))return;
    await sleep(page,500);
  }
  throw new MmError('RESULTS_NOT_SETTLED','资源结果未稳定，未读取');
}
async function navigateResource(page, row) {
  const source=row.resourceSource || row.source || 'personal';
  if (!RESOURCE_LABELS[source]) throw new MmError('USAGE','资源来源必须为 personal/enterprise/friends/history');
  await page.goto('https://maimai.cn/ent/v41/groups');
  await page.waitForSelector('text="'+RESOURCE_LABELS[source]+'"',{timeout:15000});
  // Let the initial personal view finish hydration before changing source.
  await waitResource(page, 'personal');
  const count=await page.evaluate(label=>{
    const items=[...document.querySelectorAll('[class*="subItem___"]')];
    for(const item of items)item.removeAttribute('data-mm-source');
    const matches=items.filter(item=>(item.innerText||'').trim().split(/\r?\n/)[0].trim()===label);
    if(matches.length===1)matches[0].setAttribute('data-mm-source','target');
    return matches.length;
  },RESOURCE_LABELS[source]);
  if(count!==1)throw new MmError('RESOURCE_NOT_SELECTED','目标资源栏目未找到或不唯一');
  await page.click('[data-mm-source="target"]');
  await page.waitForFunction(label=>{
    const items=[...document.querySelectorAll('[class*="subItem___"][class*="selectedItem___"]')];
    return items.length===1&&(items[0].innerText||'').trim().split(/\r?\n/)[0].trim()===label;
  },RESOURCE_LABELS[source],{timeout:10000});
  await waitResource(page, source);
  await assertResourceSelected(page,source);
  if (row.resourceGroup) {
    if(source!=='personal') throw new MmError('USAGE','分组仅支持个人储备');
    const groupCount=await page.evaluate(label=>{
      const tags=[...document.querySelectorAll('[class*="tags___"] .ant-tag-checkable')];
      for(const tag of tags)tag.removeAttribute('data-mm-resource-group');
      const matches=tags.filter(tag=>(tag.innerText||'').trim().replace(/\s*·\s*\d+\s*$/, '').trim()===label.trim());
      if(matches.length===1)matches[0].setAttribute('data-mm-resource-group','selected');
      return matches.length;
    },row.resourceGroup);
    if(groupCount!==1)throw new MmError('GROUP_UNCERTAIN','资源分组未找到或不唯一，未点击');
    await page.click('[data-mm-resource-group="selected"]');
    await waitResource(page,source);
  }
  if(row.sourceQuery) {
    await page.fill('input[placeholder="请输入"]',row.sourceQuery);
    await page.press('input[placeholder="请输入"]','Enter');
    await waitResource(page,source);
  }
}
async function readResourceRows(page, source) {
  await assertResourceSelected(page,source);
  if(source!=='friends') {
    const count=await page.evaluate(()=>document.querySelectorAll('.talent-common-card').length);
    if(count)return await markAndReadRows(page);
    const empty=await page.evaluate(()=>/暂无好友|暂无数据|暂无人才|暂无匹配|暂无结果|没有找到|无匹配|没有相关/.test(document.body.innerText));
    if(!empty)throw new MmError('RESULTS_NOT_SETTLED','未找到有效资源列表，也未观察到空结果提示');
    return {rows:[],total:0};
  }
  const rows=await page.evaluate(()=>[...document.querySelectorAll('[class*="card___"]')].filter(n=>n.querySelector('h3,[role="heading"]')?.textContent?.trim()&&n.querySelector('[class*="cardContent___"]')).map((n,i)=>{
    const lines=(n.innerText||'').split('\n').map(x=>x.trim()).filter(Boolean);
    n.setAttribute('data-mm-row',String(i));
    return {i,lines,name:n.querySelector('h3,[role="heading"]').textContent.trim(),fingerprint:lines.join('\n'),candidateId:null,profileUrl:null,identityStatus:'unknown'};
  }));
  if(!rows.length){
    const empty=await page.evaluate(()=>/暂无好友|暂无数据|暂无人才|暂无匹配|暂无结果|没有找到|无匹配|没有相关/.test(document.body.innerText));
    if(!empty)throw new MmError('RESULTS_NOT_SETTLED','未找到有效好友卡片，也未观察到空结果提示');
  }
  return {rows,total:rows.length};
}
