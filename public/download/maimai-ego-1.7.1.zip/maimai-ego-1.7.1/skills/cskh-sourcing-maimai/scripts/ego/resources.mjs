async function main(){
  const source=ARGS.source || 'personal', limit=Number(ARGS.limit||20), pages=Number(ARGS.pages||1);
  if(!RESOURCE_LABELS[source] || !Number.isInteger(limit)||limit<1||!Number.isInteger(pages)||pages<1) throw new MmError('USAGE','资源来源或数量参数无效');
  if(ARGS.group && source!=='personal') throw new MmError('USAGE','分组仅支持个人储备');
  const page=getPage(await getTask());
  const meta={source,resourceSource:source,resourceGroup:ARGS.group||'',sourceQuery:ARGS.query||''};
  await navigateResource(page,meta);
  const login=await detectLogin(page);if(!login.loggedIn)throw new MmError('NOT_LOGGED_IN','请先登录');
  const rows=[];let risk=null,actualPages=0,pageSize=0;
  try {
  for(let i=0;i<pages;i++){
    if((await detectRisk(page)).hasCaptcha){risk='captcha';break;}
    const current=await readResourceRows(page,source); actualPages++; if(!i)pageSize=current.total;
    const sourceUrl=await page.url();
    for(const row of current.rows){if(rows.length>=limit)break;rows.push({...row,...meta,sourceUrl});}
    if(rows.length>=limit || !current.total || i+1>=pages)break;
    if(!await gotoNextPage(page,p=>waitResource(p,source)))break;
  }
  } catch(e) {
    emit(false,e.code||'INTERNAL',{...meta,query:ARGS.query||'',rows,rowCount:rows.length,pageSize,pages:actualPages,risk,errors:[{code:e.code||'INTERNAL',error:e.hint||e.message}]},e.hint||e.message);
    return;
  }
  emit(!risk,risk?'RATE_LIMITED':'OK',{...meta,query:ARGS.query||'',rows,rowCount:rows.length,pageSize,pages:actualPages,risk},'仅读取资源列表，未打开聊天或修改记录');
}
main().catch(e=>emit(false,e.code||'INTERNAL',e.data||null,e.hint||e.message));
