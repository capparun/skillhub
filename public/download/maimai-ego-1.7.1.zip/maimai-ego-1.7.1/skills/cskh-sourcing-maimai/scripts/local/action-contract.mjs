import { createHash } from 'node:crypto';
import fs from 'node:fs';

export const ACTION_COMMANDS = new Set(['note', 'job-assign', 'follow', 'reserve', 'public-profile']);

function invalid(hint, code = 'USAGE') {
  const error = new Error(hint);
  error.code = code;
  throw error;
}

/** Validate before starting a browser; preview is the default. */
export function validateAction(action, input) {
  if (!ACTION_COMMANDS.has(action)) invalid('不支持的候选人动作');
  const allowed = new Set(['candidate-id', 'apply', ...({
    note: ['text', 'visibility'], 'job-assign': ['job', 'company'],
    follow: ['state'], reserve: ['group', 'scope'], 'public-profile': [],
  }[action])]);
  for (const key of Object.keys(input)) if (!allowed.has(key)) invalid(`不支持的参数：--${key}`);
  if (typeof input['candidate-id'] !== 'string' || !/^[1-9]\d*$/.test(input['candidate-id'])) invalid('--candidate-id 必须是正整数字符串');
  if (input.apply !== undefined && input.apply !== true) invalid('--apply 必须单独使用，不接受字符串值');
  if (action === 'public-profile' && input.apply !== undefined) invalid('public-profile 是只读命令，不接受 --apply');
  const args = {...input, action, apply: input.apply === true};
  const text = (key, required) => {
    if (args[key] === undefined && !required) return;
    if (typeof args[key] !== 'string' || !args[key].trim()) invalid(`--${key} 需要非空文本`);
  };
  if (action === 'note') {
    text('text', true);
    if (args.text.length > 100) invalid('--text 最多 100 个 UTF-16 字符');
    args.visibility ??= 'self';
    if (!['self', 'team'].includes(args.visibility)) invalid('--visibility 只能为 self 或 team');
  }
  if (action === 'job-assign') {
    text('job', args.apply); text('company', args.apply);
  }
  if (action === 'follow') {
    args.state ??= 'on';
    if (!['on', 'off'].includes(args.state)) invalid('--state 只能为 on 或 off');
  }
  if (action === 'reserve') {
    text('group', args.apply);
    args.scope ??= 'personal';
    if (!['personal', 'enterprise'].includes(args.scope)) invalid('--scope 只能为 personal 或 enterprise');
  }
  args.operationKey = actionOperationKey(args);
  return args;
}

/** Hash only the action identity and payload, never transient browser state. */
export function actionOperationKey(args) {
  const payload = Object.fromEntries(Object.entries(args)
    .filter(([key]) => !['apply', 'operationKey'].includes(key)).sort(([a], [b]) => a.localeCompare(b)));
  return createHash('sha256').update(JSON.stringify(payload)).digest('hex');
}

export function readActionLedger(file) {
  if (!fs.existsSync(file)) return [];
  try {
    return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map(line => {
      const item = JSON.parse(line);
      if (!item || typeof item.operationKey !== 'string' || !['pending', 'unknown', 'verified', 'not_submitted'].includes(item.status)) throw new Error('invalid receipt');
      return item;
    });
  } catch {
    invalid('动作记录无法读取；请先核查记录，不自动重试写入', 'ACTION_LEDGER_INVALID');
  }
}

function appendReceipt(file, record) {
  const fd = fs.openSync(file, 'a', 0o600);
  try { fs.writeSync(fd, JSON.stringify(record) + '\n'); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
}

/** Caller must hold the CLI command lock. Unknown prior results fail closed. */
export function beginAction(file, args) {
  const records = readActionLedger(file);
  const relevant = records.filter(row => row.action === args.action && row.candidateId === args['candidate-id']);
  // An unresolved different payload for this same action is also unsafe to repeat.
  const latestByKey = new Map(relevant.map(row => [row.operationKey, row]));
  if ([...latestByKey.values()].some(row => ['pending', 'unknown'].includes(row.status))) {
    invalid('上次动作结果不明；先核对页面及动作记录，禁止自动重试', 'ACTION_UNCERTAIN');
  }
  const previous = latestByKey.get(args.operationKey);
  const latestVerified = relevant.findLast(row => row.status === 'verified');
  if (previous?.status === 'verified' && (args.action !== 'follow' || latestVerified?.operationKey === args.operationKey)) {
    return { ok: true, code: 'ALREADY_RECORDED',
      data: {operationKey: args.operationKey, candidateId: args['candidate-id'], action: args.action,
        submitted: false, verified: false, verifiedAt: previous.at, replayed: true, verification: 'previous-receipt'},
      hint: '此动作已有历史成功回执，本次未重复提交；历史回执不代表当前状态，请先用不带 --apply 的命令核对页面' };
  }
  appendReceipt(file, {operationKey: args.operationKey, action: args.action,
    candidateId: args['candidate-id'], status: 'pending', at: new Date().toISOString()});
  return null;
}

export function completeAction(file, args, env) {
  const status = env.ok === true && env.data?.verified === true ? 'verified'
    : env.data?.submitted === false ? 'not_submitted' : 'unknown';
  if (status !== 'verified' && env.ok) {
    env = {...env, ok: false, code: status === 'unknown' ? 'ACTION_UNCERTAIN' : 'ACTION_NOT_APPLIED',
      hint: status === 'unknown' ? '动作未获得独立回读确认，不自动重试' : '动作未提交，也未验证目标状态'};
  }
  appendReceipt(file, {operationKey: args.operationKey, action: args.action,
    candidateId: args['candidate-id'], status, at: new Date().toISOString(), receipt: env});
  return env;
}

/** A PREVIEW may invalidate a historical success only with exact current-state evidence. */
function previewShowsStateChange(args, env) {
  if (env.code !== 'PREVIEW' || env.data?.verified !== false) return false;
  const preview = env.data.preview;
  if (!preview || env.data.alreadyApplied) return false;
  if (args.action === 'follow') {
    return ['on', 'off'].includes(preview.before) && preview.after === args.state && preview.before !== preview.after;
  }
  if (args.action === 'reserve') {
    return typeof args.group === 'string' && preview.add?.name === args.group &&
      preview.add?.scope === args.scope && preview.add?.selected === false;
  }
  if (args.action === 'job-assign') {
    const job = preview.job;
    return typeof args.job === 'string' && typeof args.company === 'string' &&
      job?.title === args.job && job?.company === args.company &&
      typeof job?.owner === 'string' && Boolean(job.owner.trim()) &&
      typeof job?.date === 'string' && Boolean(job.date.trim()) && preview.status === '待沟通';
  }
  return false;
}

/** Reconcile from read-only evidence; never unlock an uncertain write from absence alone. */
export function reconcileAction(file, args, env) {
  if (args.apply || args.action === 'public-profile' || env.ok !== true ||
      env.data?.submitted !== false) return env;
  const previous = readActionLedger(file).findLast(row => row.operationKey === args.operationKey &&
    row.action === args.action && row.candidateId === args['candidate-id']);
  if (!previous) return env;
  let status, marker;
  if (['pending', 'unknown'].includes(previous.status) && env.data.verified === true) {
    status = 'verified'; marker = {reconciledBy:'read-only-verification'};
  } else if (previous.status === 'verified' && previewShowsStateChange(args, env)) {
    status = 'not_submitted'; marker = {invalidatedBy:'read-only-state-change'};
  } else return env;
  const receipt = {...env, data:{...env.data, ...marker}};
  appendReceipt(file, {operationKey:args.operationKey, action:args.action,
    candidateId:args['candidate-id'], status, at:new Date().toISOString(), ...marker, receipt});
  return receipt;
}
