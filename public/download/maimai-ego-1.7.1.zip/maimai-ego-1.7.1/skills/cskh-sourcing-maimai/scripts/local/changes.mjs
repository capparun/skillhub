import path from 'node:path';
import {loadRun,diffRecords,saveReport,usage} from './read-model.mjs';
export async function run({args,paths,helpers}){
 const before=loadRun(paths.OUTPUT_DIR,args.before).rows,after=loadRun(paths.OUTPUT_DIR,args.after).rows;
 const runs=helpers.readJson(paths.STATE_FILE,{runs:{}}).runs;
 const scope=id=>{const r=runs[id];if(!r)throw usage('缺少任务来源信息');return JSON.stringify([r.source||'search',r.query||'',r.jobId||'',r.resourceGroup||'',r.filters||{}]);};
 if(scope(args.before)!==scope(args.after))throw usage('两个任务来源或条件不同，不能进行变化对比');
 const result=diffRecords(before,after),output=path.resolve(args.output||path.join(paths.OUTPUT_DIR,args.after,'changes-'+Date.now()+'.json'));
 result.coverage={before:runs[args.before].status,after:runs[args.after].status,scope:'collected_sample',note:'未再次观察到不等于删除或离职；字段差异可能来自页面显示或采集完整度变化'};
 saveReport(output,JSON.stringify(result,null,2));
 return {ok:true,code:'OK',data:{output,added:result.added.length,changed:result.changed.length,notObserved:result.notObserved.length,unresolved:result.unresolved.before.length+result.unresolved.after.length,coverage:result.coverage}};
}
