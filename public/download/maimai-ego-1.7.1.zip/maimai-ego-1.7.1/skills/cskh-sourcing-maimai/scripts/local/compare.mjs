import path from 'node:path';
import fs from 'node:fs';
import {loadRun,compareRecords,renderComparison,saveReport,usage} from './read-model.mjs';
export async function run({args,paths}){
 let config=null;
 if(args.criteria && args['criteria-file'])throw usage('criteria 和 criteria-file 只能选一个');
 if(args.criteria||args['criteria-file'])config=JSON.parse(args['criteria-file']?fs.readFileSync(args['criteria-file'],'utf8'):args.criteria);
 let {rows}=loadRun(paths.OUTPUT_DIR,args.run);
 if(args['candidate-ids']){const ids=String(args['candidate-ids']).split(',');for(const id of ids)if(rows.filter(r=>r.candidateId&&String(r.candidateId)===id).length!==1)throw usage('候选人不存在或身份重复：'+id);rows=rows.filter(r=>r.candidateId&&ids.includes(String(r.candidateId)));}
 const result=compareRecords(rows,config),format=args.format||'html';if(!['html','json'].includes(format))throw usage('format 为 html 或 json');
 const output=path.resolve(args.output||path.join(paths.OUTPUT_DIR,args.run,'compare-'+Date.now()+'.'+format));
 saveReport(output,format==='html'?renderComparison(result):JSON.stringify(result,null,2));
 return {ok:true,code:'OK',data:{output,count:result.length,criteriaCount:config?.criteria?.length||0},hint:'本地证据比较，不自动判断合格或允许触达'};
}
