import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { loadRun, usage } from './read-model.mjs';

function required(args, key) {
  if (typeof args[key] !== 'string' || !args[key].trim()) throw usage('需要填写 ' + key);
  return args[key].trim();
}

function allow(args, keys) {
  const invalid = Object.keys(args).find(key => !keys.includes(key));
  if (invalid) throw usage('当前操作不支持参数 ' + invalid);
}

function requireExcerpt(excerpt, source) {
  if (!source.includes(excerpt)) throw usage('找不到这段依据，请从已读取资料选择原文');
}

function makeReply(args, paths) {
  allow(args, ['action','kind','thread-file','thread-id','evidence','text']);
  const file = fs.realpathSync(required(args, 'thread-file'));
  if (path.dirname(file) !== fs.realpathSync(paths.OUTPUT_DIR) || !/^thread-\d+\.json$/.test(path.basename(file))) {
    throw usage('thread-file 必须是当前输出目录中 thread 命令保存的会话回执');
  }
  const thread = JSON.parse(fs.readFileSync(file,'utf8'));
  const threadId = required(args, 'thread-id');
  if (thread.source !== 'thread' || String(thread.threadId) !== threadId || !thread.name || typeof thread.contextText !== 'string') {
    throw usage('会话回执与目标不符，请重新核对 thread-id');
  }
  const evidence = required(args, 'evidence');
  requireExcerpt(evidence, thread.contextText);
  return {
    kind:'reply', channel:'脉脉', target:{threadId, name:thread.name},
    evidence, text:required(args, 'text'), source:path.basename(file)
  };
}

function makeCandidateDraft(args, paths) {
  allow(args, ['action','kind','run','candidate-id','fingerprint','evidence','text','channel','opportunity']);
  const runId = required(args,'run');
  const idKey = args['candidate-id'] ? 'candidate-id' : 'fingerprint';
  if (args['candidate-id'] && args.fingerprint) throw usage('candidate-id 和 fingerprint 只能选一个');
  const id = required(args,idKey);
  const field = idKey === 'candidate-id' ? 'candidateId' : 'fingerprint';
  const matches = loadRun(paths.OUTPUT_DIR, runId).rows.filter(row => row[field] != null && String(row[field]) === id);
  if (matches.length !== 1) throw usage('无法在本次列表唯一定位候选人');
  const row = matches[0];
  const name = row.name || row.lines?.[0];
  if (!name) throw usage('候选人姓名缺失，请先核实资料');
  const opportunity = required(args,'opportunity');
  const channel = required(args,'channel');
  const evidence = required(args,'evidence');
  requireExcerpt(evidence, [...(row.lines || []), row.text || ''].join('\n'));
  const intro = args.kind === 'first' ? '想和您聊聊' : '这次想和您聊一个新机会，';
  const text = 'text' in args ? required(args,'text') :
    name + '您好，看到您资料中提到“' + evidence + '”。' + intro + opportunity + '。您方便了解一下吗？';
  return {kind:args.kind,channel,target:{run:runId,[field]:id,name},opportunity,evidence,text};
}

function loadLedger(file) {
  if (!fs.existsSync(file)) return [];
  const ledger = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(ledger)) throw new Error('跟进记录格式错误');
  return ledger;
}

// mm.mjs holds the state lock across each command. Rename keeps interrupted writes out of the ledger.
function persist(file, ledger) {
  const temp = file + '.' + randomUUID() + '.tmp';
  try {
    fs.writeFileSync(temp, JSON.stringify(ledger,null,2)+'\n',{flag:'wx',mode:0o600});
    fs.renameSync(temp,file);
  } finally {
    fs.rmSync(temp,{force:true});
  }
}

export function run({args,paths}) {
  const action = required(args,'action');
  const file = path.join(paths.STATE_ROOT,'follow-up.json');
  const ledger = loadLedger(file);
  const ok = data => ({ok:true,code:'OK',data,hint:'记录保存在本机，可用 follow-up --action list 回查。'});
  if (action === 'list') {
    allow(args,['action']);
    return ok({drafts:ledger});
  }
  const now = new Date().toISOString();
  if (action === 'draft') {
    if (!['first','reply','reactivate'].includes(args.kind)) throw usage('kind 请选择 first、reply 或 reactivate');
    const data = args.kind === 'reply' ? makeReply(args,paths) : makeCandidateDraft(args,paths);
    const id = createHash('sha256').update(JSON.stringify(data)).digest('hex');
    const existing = ledger.find(item => item.id === id);
    if (existing) return ok(existing);
    const record = {...data,id,status:'draft',history:[{event:'draft',at:now}]};
    ledger.push(record);
    persist(file,ledger);
    return ok(record);
  }
  if (!['approve','record'].includes(action)) throw usage('action 请选择 draft、approve、record 或 list');
  allow(args,action === 'approve' ? ['action','draft-id'] : ['action','draft-id','note']);
  const id = required(args,'draft-id');
  const record = ledger.find(item => item.id === id);
  if (!record) throw usage('草稿不存在');
  if (action === 'approve') {
    if (record.status === 'approved') return ok(record);
    record.status = 'approved';
    record.history.push({event:'approved',at:now});
  } else {
    const note = required(args,'note');
    const latest = record.history.at(-1);
    if (latest.event === 'note' && latest.note === note) return ok(record);
    record.history.push({event:'note',at:now,note});
  }
  persist(file,ledger);
  return ok(record);
}
