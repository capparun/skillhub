import fs from 'node:fs';
import path from 'node:path';
export function usage(message){return Object.assign(new Error(message),{code:'USAGE'});}
export function loadRun(root,id){
 if(typeof id!=='string'||!id||! /^[\w\u4e00-\u9fff.-]+$/.test(id)||id==='.'||id==='..')throw usage('需要有效的任务标识');
 const dir=path.join(root,id),file=path.join(dir,'list.jsonl');
 if(!fs.existsSync(file))throw usage('任务列表不存在：'+id);
 const read=f=>fs.existsSync(f)?fs.readFileSync(f,'utf8').split('\n').filter(Boolean).map(l=>JSON.parse(l)):[];
 const rows=read(file),details=read(path.join(dir,'detail.jsonl'));
 const latest=new Map(details.filter(d=>identity(d)).map(d=>[identity(d),d]));
 return {rows:rows.map(r=>{
  let d=latest.get(identity(r));
  if(d && ((r.name||r.lines?.[0])&&d.name&&d.name!==(r.name||r.lines?.[0])||r.profileUrl&&d?.profileUrl&&r.profileUrl!==d.profileUrl))d=null;
  if(!d&&!identity(r)&&r.fingerprint&&rows.filter(x=>x.fingerprint===r.fingerprint).length===1){
   const matches=details.filter(x=>x.fingerprint===r.fingerprint);const ids=new Set(matches.map(identity).filter(Boolean));
   if(ids.size<=1)d=matches.at(-1);
  }
  return {...r,...(d||{}),candidateId:r.candidateId||d?.candidateId||null,source:r.source,sourceUrl:r.sourceUrl};
 })};
}
export function identity(r){return r.candidateId?'id:'+String(r.candidateId):r.profileUrl?'url:'+r.profileUrl:null;}
export function compareRecords(rows,config){
 if(config!==null&&config!==undefined&&(typeof config!=='object'||Array.isArray(config)))throw usage('比较条件必须是对象');
 const criteria=config?.criteria||[];
 if(!Array.isArray(criteria)||criteria.length>30)throw usage('criteria 必须是至多30项的数组');
 for(const c of criteria)if(!c||typeof c.label!=='string'||!c.label.trim()||!Array.isArray(c.terms)||!c.terms.length||c.terms.some(t=>typeof t!=='string'||!t.trim()))throw usage('每个标准需要 label 和非空 terms 数组');
 return rows.map(r=>{
  const text=[...(r.lines||[]),r.text||''].join('\n');
  return {...r,name:r.name||r.lines?.[0]||'姓名待确认',identityStatus:identity(r)?'known':'unknown',evidence:criteria.map(c=>{
   const term=c.terms.find(t=>text.toLowerCase().includes(t.toLowerCase()));
   const index=term?text.toLowerCase().indexOf(term.toLowerCase()):-1;
   return {label:c.label,status:term?'observed':'not_observed',matchedTerm:term||null,excerpt:term?text.slice(Math.max(0,index-30),index+term.length+70):null};
  })};
 });
}
export function diffRecords(before,after){
 const group=rows=>{const m=new Map();for(const r of rows){const k=identity(r);if(k)m.set(k,[...(m.get(k)||[]),r]);}return m;};
 const b=group(before),a=group(after),keys=new Set([...b.keys(),...a.keys()]);
 const out={added:[],notObserved:[],changed:[],unchanged:0,unresolved:{before:before.filter(r=>!identity(r)),after:after.filter(r=>!identity(r))}};
 for(const key of keys){const x=b.get(key)||[],y=a.get(key)||[];if(x.length>1||y.length>1){out.unresolved.before.push(...x);out.unresolved.after.push(...y);continue;}
  if(!x.length){out.added.push(y[0]);continue;}if(!y.length){out.notObserved.push(x[0]);continue;}
  const changes=['name','lines','text'].filter(f=>JSON.stringify(x[0][f]??null)!==JSON.stringify(y[0][f]??null)).map(field=>({field,before:x[0][field]??null,after:y[0][field]??null}));
  if(changes.length)out.changed.push({identity:key,changes});else out.unchanged++;
 }
 return out;
}
export function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function renderComparison(rows){return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><title>脉脉候选人比较</title><style>body{font:16px/1.6 system-ui,"PingFang SC",sans-serif;margin:24px;color:#24352e}h1{font-size:24px}h2{font-size:18px;margin:0}article{border-top:1px solid #ddd;padding:12px 0}p{margin:4px 0}table{border-collapse:collapse;width:100%}td,th{text-align:left;border-bottom:1px solid #ddd;padding:8px}small{font-size:14px}pre{white-space:pre-wrap;font:inherit}</style><h1>候选人比较 · ${rows.length} 人</h1><p>只整理已读取的证据；未观察到不等于不具备。不自动淘汰、联系或修改平台状态。</p>${rows.map(r=>`<article><h2>${esc(r.name)}</h2><small>身份：${esc(identity(r)||'待确认')} · 来源：${esc(r.source||'待确认')}</small>${r.evidence.length?`<table><tr><th>标准</th><th>证据</th></tr>${r.evidence.map(e=>`<tr><td>${esc(e.label)}</td><td>${e.status==='observed'?esc(e.excerpt):'待补证据'}</td></tr>`).join('')}</table>`:'<p>未指定比较标准，仅展示资料。</p>'}<details><summary>资料与来源</summary><p>${esc(r.sourceUrl)}</p><pre>${esc(r.text||(r.lines||[]).join('\n'))}</pre></details></article>`).join('')}</html>`;}
export function saveReport(file,body){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,body,{flag:'wx'});return file;}
