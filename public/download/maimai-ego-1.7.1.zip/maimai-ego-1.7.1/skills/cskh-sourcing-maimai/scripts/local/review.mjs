import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { esc, identity, loadRun, saveReport, usage } from './read-model.mjs';

const labels = { select: '入选', reject: '淘汰', defer: '暂缓', pending: '待审' };
const decisions = ['select', 'reject', 'defer'];
const selectors = { 'candidate-id': 'candidateId', fingerprint: 'fingerprint', 'profile-url': 'profileUrl' };

function decisionKey(row) {
  return identity(row) || (row.fingerprint ? 'fingerprint:' + row.fingerprint : null);
}

function csvCell(value) {
  let text = String(value ?? '');
  if (/^[\s]*[=+@-]/u.test(text)) text = "'" + text;
  return '"' + text.replaceAll('"', '""') + '"';
}

function report(rows, format) {
  if (format === 'json') return JSON.stringify(rows, null, 2);
  if (format === 'csv') return '\uFEFF' + [['姓名','身份','决定','理由','审核时间'], ...rows.map(r => [r.name,r.key,labels[r.decision],r.reason,r.updatedAt])].map(row => row.map(csvCell).join(',')).join('\r\n');
  return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>候选人审核</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:72rem;margin:2rem auto;padding:0 1rem}article{border-top:1px solid #ccc;padding:1rem 0}h2,p{margin:.3rem 0}select,input,button{font:inherit;margin:.3rem;padding:.3rem}input{max-width:90%}</style><h1>候选人审核</h1><p>修改决定后填写理由，导出入选名单或保存全部决定。保存的决定文件可导入本地审核记录。</p><button id="short">导出入选名单</button><button id="all">保存全部决定</button>${rows.map(r => `<article data-key="${esc(r.key)}"><h2>${esc(r.name)}</h2><details><summary>资料</summary><p style="white-space:pre-wrap">${esc(r.summary)}</p></details>${r.reviewable ? `<label>决定<select>${Object.entries(labels).filter(([k])=>k !== 'pending' || r.decision === 'pending').map(([k,v]) => `<option value="${k}" ${r.decision===k?'selected':''}>${v}</option>`).join('')}</select></label><label>理由<input value="${esc(r.reason)}"></label>` : '<p>身份无法唯一确认</p>'}</article>`).join('')}<script>
function download(onlySelected){const rows=[];for(const item of document.querySelectorAll('article')){const sel=item.querySelector('select');if(!sel || sel.value==='pending'||(onlySelected&&sel.value!=='select'))continue;const reason=item.querySelector('input').value.trim();if(!reason){item.querySelector('input').focus();alert('请填写审核理由');return}rows.push({key:item.dataset.key,name:item.querySelector('h2').textContent,decision:sel.value,reason})}const url=URL.createObjectURL(new Blob([JSON.stringify(rows,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=onlySelected?'shortlist.json':'review-decisions.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
document.getElementById('short').onclick=()=>download(true);document.getElementById('all').onclick=()=>download(false);
</script></html>`;
}

export async function run({ args, paths }) {
  const allowed = new Set(['run',...Object.keys(selectors),'decision','reason','filter','format','output','import']);
  for (const key of Object.keys(args)) if (!allowed.has(key)) throw usage('未知审核参数：' + key);
  const {rows} = loadRun(paths.OUTPUT_DIR, args.run);
  const keys = rows.map(decisionKey);
  const unique = key => key && keys.indexOf(key) !== -1 && keys.indexOf(key) === keys.lastIndexOf(key);
  const dir = path.join(paths.OUTPUT_DIR, args.run, 'manual-review');
  const history = path.join(dir, 'decisions.json');
  const flags = Object.keys(selectors).filter(k => Object.hasOwn(args,k));
  const write = flags.length || args.decision !== undefined || args.reason !== undefined || args.import !== undefined;
  if (args.filter !== undefined && !Object.hasOwn(labels,args.filter)) throw usage('未知审核过滤条件');
  if (args.format !== undefined && !['csv','json','html'].includes(args.format)) throw usage('导出支持 csv、json、html');
  if (args.output !== undefined && (!args.format || typeof args.output !== 'string')) throw usage('输出路径需要同时指定格式');
  if (write && (args.filter || args.format || args.output)) throw usage('先保存审核记录，再单独导出');
  const read = () => fs.existsSync(history) ? JSON.parse(fs.readFileSync(history,'utf8')) : [];
  if (write) {
    let updates;
    if (args.import !== undefined) {
      if (typeof args.import !== 'string' || flags.length || args.decision !== undefined || args.reason !== undefined) throw usage('导入需要单独指定决定文件');
      updates = JSON.parse(fs.readFileSync(args.import,'utf8'));
      if (!Array.isArray(updates)) throw usage('决定文件必须为数组');
    } else {
      if (flags.length !== 1 || typeof args[flags[0]] !== 'string' || !args[flags[0]].trim()) throw usage('请指定唯一的候选人标识');
      const matches = rows.filter(r => String(r[selectors[flags[0]]] ?? '') === args[flags[0]]);
      if (matches.length !== 1) throw usage('候选人不存在或身份重复');
      updates = [{key:decisionKey(matches[0]),decision:args.decision,reason:args.reason}];
    }
    const touched = new Set();
    for (const u of updates) {
      if (!u || !unique(u.key) || touched.has(u.key)) throw usage('候选人不存在或身份重复');
      if (!decisions.includes(u.decision) || typeof u.reason !== 'string' || !u.reason.trim()) throw usage('需要有效决定和审核理由');
      touched.add(u.key);
    }
    fs.mkdirSync(dir,{recursive:true});
    const lock = path.join(dir,'write.lock');
    const fd = fs.openSync(lock,'wx');
    try {
      const events = read();
      const latest = new Map(events.map(e=>[e.key,e]));
      for (const u of updates) {
        const prior = latest.get(u.key), reason=u.reason.trim();
        if (prior?.decision !== u.decision || prior.reason !== reason) events.push({key:u.key,decision:u.decision,reason,updatedAt:new Date().toISOString()});
      }
      const tmp = path.join(dir,randomUUID()+'.tmp');
      fs.writeFileSync(tmp, JSON.stringify(events,null,2),{flag:'wx'});
      fs.renameSync(tmp,history);
    } finally { fs.closeSync(fd); fs.unlinkSync(lock); }
  }
  const latest = new Map(read().map(e=>[e.key,e]));
  const result = rows.map((r,i) => {
    const key=keys[i], record=unique(key) && latest.get(key);
    return {key,reviewable:Boolean(unique(key)),name:r.name || r.lines?.[0] || '姓名待确认',summary:r.text || (r.lines || []).join('\n'),decision:record?.decision || 'pending',reason:record?.reason || '',updatedAt:record?.updatedAt || null};
  }).filter(r => !args.filter || r.decision === args.filter);
  let output;
  if (args.format) {
    output=path.resolve(args.output || path.join(paths.OUTPUT_DIR,args.run,'review-'+randomUUID()+'.'+args.format));
    saveReport(output,report(result,args.format));
  }
  return {ok:true,code:'OK',data:{count:result.length,rows:result,output},hint:'审核记录保存在本次任务目录'};
}
