#!/usr/bin/env node
// mm.mjs — cskh-sourcing-maimai 原子 CLI wrapper（宿主无关）
//
// 架构：mm.mjs 持有全部 state（~/.maimai-scout/），ego 脚本无状态。
//   - ego 侧命令：读 scripts/ego/lib.mjs + <cmd>.mjs，把参数/page-map 内联拼成单个自包含 JS，
//     通过 stdin 喂给 `ego-browser nodejs`，捕获 stdout 信封。
//   - 本地命令（export）：直接在本进程执行，不启动 ego。
//   - 各 ego 命令的结果由 mm.mjs 落盘：search→list.jsonl，harvest→detail.jsonl，
//     explore→page-map.json，state.runs 跟踪游标。
//
// 统一信封：stdout 单行 JSON {ok, code, data, hint}；失败 exit 1。

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { ACTION_COMMANDS, validateAction, beginAction, completeAction, reconcileAction } from './local/action-contract.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EGO_DIR = path.join(__dirname, 'ego');
const LOCAL_DIR = path.join(__dirname, 'local');
const STATE_ROOT = path.resolve(process.env.MAIMAI_STATE_DIR || path.join(os.homedir(), '.maimai-scout'));
const STATE_FILE = path.join(STATE_ROOT, 'state.json');
const PAGE_MAP_FILE = path.join(STATE_ROOT, 'page-map.json');
const SEEN_FILE = path.join(STATE_ROOT, 'seen.json');
const OUTPUT_DIR = path.join(STATE_ROOT, 'output');
const DOWNLOADS_DIR = path.join(STATE_ROOT, 'downloads');

const READ_COMMANDS = new Set(['applications','recommendations','visitors','jobs','overview','inbox','thread']);
const EGO_COMMANDS = new Set(['login', 'health', 'explore', 'search', 'harvest', 'resources', 'candidate', 'finish', 'application-review', ...READ_COMMANDS, ...ACTION_COMMANDS]);
const LOCAL_COMMANDS = new Set(['export','compare','changes','review','follow-up']);

// ---------- 信封 ----------
function emit(ok, code, data = null, hint = null) {
  process.stdout.write(JSON.stringify({ ok, code, data, hint }) + '\n');
}
function fail(code, hint, data = null) { emit(false, code, data, hint); process.exit(1); }

// ---------- argv ----------
function parseArgs(argv) {
  const cmd = argv[0];
  const args = {};
  for (let i = 1; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) args[key] = true;
      else { args[key] = next; i++; }
    }
  }
  return { cmd, args };
}

// ---------- state / json ----------
function ensureDirs() { for (const d of [STATE_ROOT, OUTPUT_DIR]) fs.mkdirSync(d, { recursive: true }); }
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJsonAtomic(file, obj) {
  const tmp = file + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, file);
}
function loadState() { return readJson(STATE_FILE, { version: 1, space: null, login: { status: 'unknown', checkedAt: null }, runs: {} }); }

// ---------- 环境探测（PRD：诚实，不静默失败） ----------
function detectEgoBinary() {
  if (process.env.EGO_BROWSER_BIN) return process.env.EGO_BROWSER_BIN;
  if (process.platform === 'win32') {
    for (const entry of (process.env.PATH || '').split(path.delimiter)) {
      const dir = entry.replace(/^"|"$/g, '');
      if (!path.isAbsolute(dir)) continue;
      for (const name of ['ego-browser.exe', 'ego-browser.cmd', 'ego-browser.bat']) {
        const file = path.join(dir, name);
        if (fs.statSync(file, { throwIfNoEntry: false })?.isFile()) return file;
      }
    }
    return null;
  }
  const candidates = [path.join(os.homedir(), '.local', 'bin', 'ego-browser'), '/usr/local/bin/ego-browser', '/opt/homebrew/bin/ego-browser'];
  for (const c of candidates) { if (c.includes('/') && fs.existsSync(c)) return c; }
  return 'ego-browser'; // 回退 PATH；不在则由 runEgo 的 spawn error 报 EGO_NOT_FOUND
}

// ---------- 拼装 + spawn ego ----------
function runEgo(cmdName, args, state, pageMap) {
  const libPath = path.join(EGO_DIR, 'lib.mjs');
  const cmdPath = path.join(EGO_DIR, (ACTION_COMMANDS.has(cmdName) ? 'actions' : READ_COMMANDS.has(cmdName) ? 'read-only' : cmdName) + '.mjs');
  if (!fs.existsSync(libPath) || !fs.existsSync(cmdPath)) fail('INTERNAL', `缺少 ego 脚本：${cmdName}`);
  const lib = fs.readFileSync(libPath, 'utf8') + '\n' + fs.readFileSync(path.join(EGO_DIR, 'resources-lib.mjs'), 'utf8');
  const readLib = READ_COMMANDS.has(cmdName) || ['candidate','harvest','application-review'].includes(cmdName) ? fs.readFileSync(path.join(EGO_DIR, 'read-only-lib.mjs'), 'utf8') : '';
  const body = readLib + '\n' + fs.readFileSync(cmdPath, 'utf8');

  const injected = [
    `const ARGS = ${JSON.stringify(args)};`,
    `const CTX = ${JSON.stringify({ spaceId: state.space ? state.space.id : null, pageLabel: state.space ? state.space.pageLabel : 'p1', stateRoot: STATE_ROOT, outputDir: OUTPUT_DIR, jobLookups: state.jobLookups || {} })};`,
    `const PAGE_MAP = ${JSON.stringify(pageMap)};`,
  ].join('\n');

  const js = injected + '\n' + lib + '\n' + body;
  const egoBin = detectEgoBinary();

  if (!egoBin) return { ok:false, code:'EGO_NOT_FOUND', data:null, hint:'请打开 Ego Lite 完成首次设置，然后完全退出并重开 WorkBuddy，用 Get-Command ego-browser 检查。' };
  const batch = process.platform === 'win32' && /\.(cmd|bat)$/i.test(egoBin);
  const options = { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true };
  // For batch launchers cmd needs a quoted command string. Only the fixed
  // nodejs verb enters cmd; all generated source and user input stay on stdin.
  const child = batch
    ? spawn(path.join(process.env.SystemRoot, 'System32', 'cmd.exe'),
        ['/d', '/v:off', '/s', '/c', '""%MAIMAI_EGO_LAUNCHER%" nodejs"'],
        { ...options, windowsVerbatimArguments:true, env:{...process.env, MAIMAI_EGO_LAUNCHER:egoBin} })
    : spawn(egoBin, ['nodejs'], options);
  return new Promise((resolve) => {
    let out = '', err = '';
    const timer = setTimeout(() => { child.kill('SIGTERM'); resolve({ok:false,code:'EGO_TIMEOUT',data:null,hint:'执行超时，已停止 CLI；先核查页面与任务记录，不自动重试。'}); }, Number(process.env.MAIMAI_TIMEOUT_MS || 180000));
    child.once('close', () => clearTimeout(timer));
    child.once('error', () => clearTimeout(timer));
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', (e) => resolve({ ok: false, code: 'EGO_NOT_FOUND', hint: `无法启动 ego-browser（${egoBin}）：${e.message}。请确认已安装 ego-lite 且 ego-browser 在 PATH。`, data: null }));
    child.on('close', () => {
      // ego-browser 把脚本 console.log 写到 stderr（stdout 恒为空），且前面可能混有 [ego-browser:notice] 行。
      // 合并两路流，取最后一个「带 ok 布尔的合法 JSON 行」作为信封；notice 等非 JSON 行自然被跳过。
      const lines = (out + '\n' + err).split('\n').map((l) => l.trim()).filter(Boolean);
      let env = null;
      for (let i = lines.length - 1; i >= 0; i--) {
        try { const j = JSON.parse(lines[i]); if (j && typeof j.ok === 'boolean') { env = j; break; } } catch { /* keep looking */ }
      }
      if (!env) resolve({ ok: false, code: 'EGO_NO_ENVELOPE', hint: `ego 脚本未返回有效信封。stderr: ${err.slice(0, 400)}`, data: { stdout: out.slice(-800), stderr: err.slice(-800) } });
      else resolve(env);
    });
    child.stdin.on('error', (e) => resolve({ok:false, code:'EGO_INPUT_ERROR', data:null, hint:e.message}));
    child.stdin.end(js, 'utf8');
  });
}

// ---------- 本地命令 ----------
async function runLocal(cmdName, args) {
  const mod = await import(pathToFileURL(path.join(LOCAL_DIR, cmdName + '.mjs')).href);
  return mod.run({ args, paths: { STATE_FILE, PAGE_MAP_FILE, SEEN_FILE, OUTPUT_DIR, STATE_ROOT }, helpers: { readJson, writeJsonAtomic } });
}

// ---------- runId ----------
function makeRunId(query) {
  const ds = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const slug = String(query || 'run').replace(/[^\w一-龥]+/g, '-').slice(0, 20);
  return ds + '-' + slug;
}

// ---------- ego 结果落盘 + state 更新 ----------
function handleEgoResult(cmd, args, env, state) {
  if (!env) return;
  const data = env.data || {};

  // __statePatch（login/health/finish 的 space/login）
  if (data.__statePatch) {
    const patch = data.__statePatch;
    delete data.__statePatch;
    if (patch.space !== undefined) state.space = patch.space;
    if (patch.login) state.login = patch.login;
  }

  if (cmd === 'explore' && data.pageMap) {
    writeJsonAtomic(PAGE_MAP_FILE, data.pageMap);
  }

  if (['search','resources','applications','recommendations','visitors'].includes(cmd) && Array.isArray(data.rows)) {
    const runId = args.run;
    const runDir = path.join(OUTPUT_DIR, runId);
    fs.mkdirSync(runDir, { recursive: true });
    const rows = data.rows || [];
    fs.writeFileSync(path.join(runDir, 'list.jsonl'), rows.length ? rows.map((r) => JSON.stringify(r)).join('\n') + '\n' : '');
    state.runs[runId] = { query: data.query, pageSize: data.pageSize || 30, list: { count: rows.length }, harvest: { cursor: 0, status: 'pending' }, status: env.ok ? 'completed' : (rows.length ? 'partial' : 'failed'), errors: data.errors || [], createdAt: new Date().toISOString(), source: data.source || 'search', resourceSource: data.resourceSource || null, resourceGroup: data.resourceGroup || '', jobId: data.jobId || '', coverage: data.coverage || 'collected_sample' };
    // 筛选条件随 run 持久化：harvest 重新导航后筛选不会保留（纯前端状态），必须能重放
    if (args.filters && typeof args.filters === 'object') state.runs[runId].filters = args.filters;
    data.runId = runId;
  }

  if (cmd === 'harvest' || cmd === 'candidate') {
    const runId = args.run;
    if (!runId || !state.runs[runId]) return;
    const runDir = path.join(OUTPUT_DIR, runId);
    fs.mkdirSync(runDir, { recursive: true });
    const details = data.details || [];
    if (details.length) fs.appendFileSync(path.join(runDir, 'detail.jsonl'), details.map((d) => JSON.stringify(d)).join('\n') + '\n');
    if (cmd === 'candidate' && !env.ok) {
      const harvest = state.runs[runId].harvest ||= {};
      const targetIndex = (args.expectedRows || []).findIndex(row => args['candidate-id']
        ? String(row.candidateId) === String(args['candidate-id'])
        : args.fingerprint && row.fingerprint === args.fingerprint);
      const target = args.expectedRows?.[targetIndex] || {};
      const fallback = {code:env.code,hint:env.hint,candidateId:target.candidateId || args['candidate-id'] || null,
        profileUrl:target.profileUrl || null,...(targetIndex >= 0 ? {rowIndex:targetIndex} : {})};
      harvest.errors = [...(harvest.errors || []), ...(data.errors?.length ? data.errors : [fallback])];
    }
    if (cmd === 'harvest' && state.runs[runId]) {
      state.runs[runId].harvest = state.runs[runId].harvest || {};
      if (Number.isInteger(data.cursor) && data.cursor >= 0) state.runs[runId].harvest.cursor = data.cursor;
      state.runs[runId].harvest.status = env.ok ? (data.cursor >= state.runs[runId].list.count ? 'completed' : 'partial') : (details.length ? 'partial' : 'failed');
      state.runs[runId].harvest.errors = [...(state.runs[runId].harvest.errors || []), ...(data.errors || []), ...(!env.ok && !data.errors?.length ? [{code:env.code,hint:env.hint}] : [])];
    }
  }

  if (cmd==='jobs' && env.ok) {
    state.jobLookups ||= {};
    for(const row of data.rows || []) if(row.jobId && row.title) state.jobLookups[row.jobId]={title:row.title,query:data.query || row.title,status:data.status};
  }
  if (['jobs','overview','inbox','thread'].includes(cmd) && env.ok) {
    const file = path.join(OUTPUT_DIR, cmd + '-' + Date.now() + '.json');
    writeJsonAtomic(file, data); data.output = file;
  }

  if (cmd === 'health') {
    const pm = readJson(PAGE_MAP_FILE, null);
    data.pageMapAge = pm && pm.version ? pm.version : null;
    const seen = readJson(SEEN_FILE, {});
    data.seenCount = Object.keys(seen).length;
  }
}

// ---------- 主流程 ----------
async function main() {
  const parsed = parseArgs(process.argv.slice(2));
  const cmd = parsed.cmd;
  let args = parsed.args;
  if (!cmd) fail('USAGE', '用法：node mm.mjs <login|health|explore|search|harvest|export|finish> [参数]。详见 SKILL.md。');
  if (cmd === '--help' || cmd === 'help' || args.help) { emit(true, 'HELP', {commands:[...EGO_COMMANDS,...LOCAL_COMMANDS]}); return; }
  if (ACTION_COMMANDS.has(cmd)) args = validateAction(cmd, args);
  if (READ_COMMANDS.has(cmd)) {
    const allowed = {applications:['run','job-id','limit','pages'],recommendations:['run','job-id','limit','pages'],visitors:['run','job-id','limit','pages'],jobs:['status','query','limit'],overview:[],inbox:['limit','pages'],thread:['thread-id','limit','pages']}[cmd];
    for(const key of Object.keys(args)) if(!allowed.includes(key)) fail('USAGE','只读命令不支持参数：'+key);
    if(args['job-id'] !== undefined && !/^\d+$/.test(String(args['job-id'])))fail('USAGE','job-id 必须为数字ID');
    if(cmd==='thread' && !/^\d+$/.test(String(args['thread-id']||'')))fail('USAGE','thread 需要 inbox 返回的 thread-id');
    if(cmd==='jobs' && args.status && !['open','closed'].includes(args.status))fail('USAGE','status 为 open 或 closed');
    if(cmd==='recommendations'&&!args['job-id'])fail('USAGE','推荐需要已有职位的 job-id；先运行 jobs，不自动发布职位');
    args.__readCommand=cmd;
  }
  if (args.run && !/^[\w\u4e00-\u9fff.-]+$/.test(String(args.run)) || args.run === '.' || args.run === '..') fail('USAGE', 'run 必须是安全的任务标识，不能包含路径');
  for (const key of ['pages','limit']) if (args[key] !== undefined && (!/^\d+$/.test(String(args[key])) || Number(args[key]) < 1)) fail('USAGE', key + ' 必须是正整数');
  ensureDirs();
  const lock = path.join(STATE_ROOT, 'command.lock');
  try { fs.writeFileSync(lock, String(process.pid), {flag:'wx'}); } catch { fail('BUSY', '已有任务执行或遗留锁，请核查后再运行'); }
  process.once('exit', () => { try { fs.unlinkSync(lock); } catch {} });
  const state = loadState();

  if (LOCAL_COMMANDS.has(cmd)) {
    const env = await runLocal(cmd, args);
    emit(env.ok, env.code, env.data ?? null, env.hint ?? null);
    if (!env.ok) process.exit(1);
    return;
  }
  if (cmd === 'application-review') {
    const allowed = ['run', 'candidate-id', 'fingerprint', 'decision'];
    const identifiers = ['candidate-id', 'fingerprint'].filter(key => typeof args[key] === 'string' && args[key].trim());
    if (Object.keys(args).some(key => !allowed.includes(key)) || identifiers.length !== 1 ||
        !['pass', 'reject'].includes(args.decision) || state.runs?.[args.run]?.source !== 'applications') {
      fail('USAGE', '投递预览需要 applications 任务、唯一候选人标识和 pass 或 reject 决定');
    }
    const key = identifiers[0];
    const field = key === 'candidate-id' ? 'candidateId' : 'fingerprint';
    const file = path.join(OUTPUT_DIR, args.run, 'list.jsonl');
    const rows = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line));
    const matches = rows.filter(row => row[field] != null && String(row[field]) === args[key]);
    if (matches.length !== 1) fail('IDENTITY_UNCERTAIN', '投递记录不存在或身份不唯一');
    args.__row = matches[0];
  }
  if (!EGO_COMMANDS.has(cmd)) fail('USAGE', `未知命令：${cmd}。可用：${[...EGO_COMMANDS, ...LOCAL_COMMANDS].join(', ')}`);

  // --filters 提前校验：必须是合法 JSON 对象（面板筛选传字符串值，结果 chip 传 true）
  if (args.filters) {
    if (typeof args.filters === 'string') {
      try { args.filters = JSON.parse(args.filters); }
      catch { fail('USAGE', `--filters 不是合法 JSON。示例：--filters '{"workyears":"5-10年","city":"北京","hasPdf":true}'`); }
    }
    if (typeof args.filters !== 'object' || Array.isArray(args.filters) || args.filters === null) {
      fail('USAGE', '--filters 必须是 JSON 对象。示例：--filters \'{"workyears":"5-10年","degree":"本科及以上"}\'');
    }
  }

  if (['search','resources','applications','recommendations','visitors'].includes(cmd)) {
    if (args.run && (state.runs[args.run] || fs.existsSync(path.join(OUTPUT_DIR,args.run)))) fail('RUN_EXISTS','任务已存在，请使用新run，禁止覆盖');
    if (!args.run) { const base=makeRunId(args.query || args.source); let id=base,n=1; while(state.runs[id] || fs.existsSync(path.join(OUTPUT_DIR,id))) id=base+'-'+n++; args.run=id; }
  }
  const pageMap = readJson(PAGE_MAP_FILE, null);

  // harvest 注入 run 上下文（query/cursor/pageSize/totalFromSearch/filters）
  if ((cmd === 'harvest' || cmd === 'candidate') && args.run && state.runs[args.run]) {
    const run = state.runs[args.run];
    const listPath = path.join(OUTPUT_DIR, args.run, 'list.jsonl');
    args.expectedRows = fs.existsSync(listPath) ? fs.readFileSync(listPath, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line)) : [];
    args.query = run.query;
    args.cursor = run.harvest ? run.harvest.cursor : 0;
    args.pageSize = run.pageSize || 30;
    args.totalFromSearch = run.list ? run.list.count : 0;
    if (run.filters) args.filters = run.filters;
    if (args['with-attachment'] || args.withAttachment || args['with-pdf'] || args.withPdf) {
      args.withAttachment = true; // --with-pdf 是旧别名，继续兼容
      args.dlDir = path.join(DOWNLOADS_DIR, args.run);
      fs.mkdirSync(args.dlDir, { recursive: true });
    }
  }

  const actionLedger = path.join(STATE_ROOT, 'actions.jsonl');
  if (ACTION_COMMANDS.has(cmd) && args.apply) {
    const previous = beginAction(actionLedger, args);
    if (previous) { emit(previous.ok, previous.code, previous.data, previous.hint); return; }
  }
  let env = await runEgo(cmd, args, state, pageMap);
  if (env.data?.rateLimited || env.data?.risk) { env.ok = false; env.code = 'RATE_LIMITED'; }
  if (env.data?.errors?.length && env.ok) { env.ok = false; env.code = 'PARTIAL_FAILURE'; }
  if (ACTION_COMMANDS.has(cmd)) {
    env = args.apply ? completeAction(actionLedger, args, env) : reconcileAction(actionLedger, args, env);
  }
  handleEgoResult(cmd, args, env, state);
  writeJsonAtomic(STATE_FILE, state);
  emit(env.ok, env.code, env.data ?? null, env.hint ?? null);
  if (!env.ok) process.exit(1);
}

main().catch((e) => fail(e.code || 'INTERNAL', e && e.message ? e.message : String(e)));
