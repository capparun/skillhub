// export.mjs — 本地后处理：解析 list+detail → 去重 → 岗位匹配度 → 增量 → CSV/JSON
// 用法：mm export --run <runId> [--format csv|json] [--incremental] [--persona-file <path>|--persona '<json>'] [--output <path>]
// 被 mm.mjs 以 run({args, paths, helpers}) 调用（完整 Node 环境，可用 fs）。

import fs from 'node:fs';
import path from 'node:path';

const DEGREES = ['博士', 'MBA', '硕士', '本科', '专科'];
const DEGREE_RANK = { '专科': 1, '大专': 1, '本科': 2, '硕士': 3, 'MBA': 3, '博士': 4 };

// ---------- 解析 ----------
// 真实脉脉候选人卡片（.talent-common-card）的 innerText 行格式：
//   [姓名, 活跃度, 立即沟通, N年, 学历, 现居地, (期望：...)?, (求职意向)?, (近期有动向)?, 职业标签：, ...标签,
//    工作段(period, 公司, ·, 职位)..., 教育段(period, 学校, ·, 专业, ·, 学历)...]
// 当前职位取「至今」那一段（同公司多段经历时，至今才是现任）。
function parseRow(lines) {
  const name = lines[0] || '';
  const activity = lines[1] || '';
  const yearsLine = lines.find((l) => /^\d+年/.test(l)) || '';
  const years = (yearsLine.match(/(\d+)年/) || [])[1] || '';
  // 学历取行序第一个命中（卡片头部那个），不是 DEGREES 数组序
  const degree = lines.find((l) => DEGREES.includes(l)) || '';
  const intent = (lines.find((l) => /^(急求职|正在看机会|关注行情|半年不看机会)$/.test(l)) || '');
  // 工作经历段：period 行后跟 公司、·、职位；跳过教育段（公司位是学校）
  const periodRe = /^\d{4}[.\-]\d{2}/;
  const entries = [];
  for (let i = 0; i < lines.length; i++) {
    if (!periodRe.test(lines[i])) continue;
    const comp = lines[i + 1], sep = lines[i + 2], role = lines[i + 3];
    if (comp && sep === '·' && role && !/大学|学院/.test(comp)) {
      entries.push({ period: lines[i], company: comp, role });
    }
  }
  const cur = entries.find((e) => /至今/.test(e.period)) || entries[0] || { company: '', role: '' };
  const school = (lines.find((l) => /大学|学院/.test(l)) || '');
  return {
    name, activity, years, degree, intent,
    current_company: cur.company, current_role: cur.role, school,
    // 卡片里没有年龄/性别/现任时长，留空
    age: '', gender: '', tenure: '',
  };
}

function block(lines, startRe, endRe) {
  const s = lines.findIndex((l) => startRe.test(l));
  if (s < 0) return [];
  let e = lines.findIndex((l, i) => i > s && endRe.test(l));
  if (e < 0) e = lines.length;
  return lines.slice(s + 1, e);
}

function parseDetail(text) {
  const lines = (text || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const exp = block(lines, /^期望偏好$/, /^工作经历$/);
  // 逐行剥离「期望城市：」「期望岗位：」「期望薪资：」等标签前缀后分类，只留值
  const strip = (s) => String(s || '').replace(/^[^：:]{1,6}[：:]\s*/, '').trim();
  let salary = '', expCities = '', expRoles = '';
  for (const raw of exp) {
    const v = strip(raw);
    if (!v) continue;
    if (!salary && /k|薪|\/月/.test(v)) salary = v;
    else if (!expCities && /、|，|\/|北京|上海|深圳|广州|杭州|海外/.test(v)) expCities = v;
    else if (!expRoles) expRoles = v;
  }
  const work = block(lines, /^工作经历$/, /^教育经历$/);
  const companies = [];
  for (let i = 0; i < work.length; i++) {
    if (/\d{4}[-.]\d{2}|至今/.test(work[i]) && i >= 2) {
      const company = work[i - 2], role = work[i - 1];
      if (company && company !== '·' && !/大学|学院/.test(company)) companies.push(`${company}·${role}`);
    }
  }
  const highlight = work.filter((l) => l.length > 60).sort((a, b) => b.length - a.length)[0] || '';
  // 英文线索：「海外」须跟留学/工作/经历等语境词才算，避免「海外数据采集」这类业务词误判为英语能力
  const engHit = (text || '').match(/CET[- ]?[46]|大学英语[四六]级|英语[四六]级|雅思[\d.]*|托福[\d.]*|IELTS|TOEFL|英语流利|英文流利|商务英语|海外(?:留学|工作|经历|背景|沟通)|英语可作为工作语言|双语/i);
  return {
    salary, expCities, expRoles,
    workCompanies: companies.slice(0, 3).join(' / '),
    highlight: highlight.slice(0, 80),
    english: engHit ? engHit[0] : '',
  };
}

// ---------- 岗位匹配度（终极目标是匹配岗位，不是匹配文本） ----------
function shortLabel(b) {
  if (/英文|英语|english/i.test(b)) return '英文';
  if (/管理|团队|lead|带/i.test(b)) return '管理';
  if (/海外|国际|global/i.test(b)) return '海外';
  return String(b).slice(0, 4);
}

function evalBonus(b, cand) {
  const t = String(b);
  // 全文兜底：highlight 只抓长行，短描述候选人会漏判；优先用详情全文匹配
  const full = (cand._text || '') + ' ' + (cand.highlight || '') + ' ' + (cand.workCompanies || '');
  if (/英文|英语|english/i.test(t)) return { ok: !!cand.english };
  // 管理加分：意图只认「管理/团队/lead/manager」，证据要真正的带队信号（团队/管理/带领/带N人/lead/manager/汇报），
  // 不把「负责…搭建…」这类工程师自述误判为管理经验
  if (/管理|团队|lead|manager/i.test(t)) return { ok: /团队|管理|带领|带\s*\d+\s*人|lead|manager|汇报/i.test(full) };
  const kw = t.replace(/(经验|背景|能力|优先|加分)/g, '').trim();
  if (kw) return { ok: full.includes(kw) };
  return { ok: false };
}

function evalJobFit(persona, cand) {
  if (!persona) return { label: '', hits: 0, hardOk: true };
  const parts = [];
  let hits = 0;
  let hardOk = true;
  const hardFails = [];
  const unknown = [];
  if (persona.hard) {
    if (persona.hard.years) {
      const m = String(persona.hard.years).match(/(\d+)\s*[-~到]\s*(\d+)/);
      const y = parseInt(cand.years, 10);
      if (!m || isNaN(y)) unknown.push('年限');
      if (m && !isNaN(y) && !(y >= +m[1] && y <= +m[2])) { hardOk = false; hardFails.push('年限'); }
    }
    if (persona.hard.degree) {
      const need = DEGREE_RANK[persona.hard.degree];
      if (!need || !DEGREE_RANK[cand.degree]) unknown.push('学历');
      if (need && DEGREE_RANK[cand.degree] && DEGREE_RANK[cand.degree] < need) { hardOk = false; hardFails.push('学历'); }
    }
  }
  for (const b of (persona.bonus || [])) {
    const r = evalBonus(b, cand);
    parts.push(shortLabel(b) + (r.ok ? '✓' : '✗'));
    if (r.ok) hits++;
  }
  parts.push(!hardOk ? '硬性✗(' + hardFails.join('/') + ')' : unknown.length ? '待确认(' + unknown.join('/') + ')' : '硬性✓');
  if (unknown.length) hardOk = false;
  return { label: parts.join(' '), hits, hardOk };
}

// ---------- CSV ----------
function csvCell(v) {
  v = String(v ?? '');
  if (/^[\s]*[=+@-]/.test(v) || /^[\t\r]/.test(v)) v = "'" + v;
  return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
}
function toCsv(rows) {
  const header = ['姓名', '活跃度', '求职意向', '年龄', '性别', '年限', '学历', '现公司', '现职位', '现任时长', '毕业学校', '期望城市', '期望岗位', '期望薪资', '英文线索', '附件简历', '附件文件', '历任公司(近3)', '亮点摘要', '来源query', '岗位匹配度', '候选人ID', '来源类型', '详情读取状态', '详情读取错误', '职位ID', '来源事件', '附件错误'];
  const lines = [header.join(',')];
  for (const o of rows) {
    // 附件只放文件名（不带目录），目录固定是 ~/.maimai-scout/downloads/<runId>/
    const attName = o.attachment ? path.win32.basename(String(o.attachment)) : '';
    const readStatus = {read:'已读取',failed:'读取失败',pending_identity_or_detail:'待确认'}[o.detailStatus] || '待确认';
    lines.push([o.name, o.activity, o.intent, o.age, o.gender, o.years, o.degree, o.current_company, o.current_role, o.tenure, o.school, o.expCities, o.expRoles, o.salary, o.english, o.hasPdf ? '有' : '', attName, o.workCompanies, o.highlight, o.sourceQuery, o.jobFit, o.candidateId, o.source, readStatus, o.detailError, o.jobId, o.sourceContext, o.attachmentError].map(csvCell).join(','));
  }
  return '﻿' + lines.join('\n');
}

// ---------- 主入口 ----------
export async function run({ args, paths, helpers }) {
  const format = args.format || 'csv';
  if (!['csv','json','html'].includes(format)) return {ok:false,code:'USAGE',hint:'format must be csv, json or html'};
  const runId = args.run;
  if (!runId) return { ok: false, code: 'USAGE', hint: '缺少 --run 参数。示例：mm export --run <runId> --format csv' };

  const runDir = path.join(paths.OUTPUT_DIR, runId);
  const listFile = path.join(runDir, 'list.jsonl');
  const detailFile = path.join(runDir, 'detail.jsonl');
  if (!fs.existsSync(listFile)) return { ok: false, code: 'NOT_FOUND', hint: '找不到列表文件：' + listFile + '。请先运行 search。' };

  const list = fs.readFileSync(listFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  const details = fs.existsSync(detailFile) ? fs.readFileSync(detailFile, 'utf8').split('\n').filter(Boolean).map(JSON.parse) : [];
  const stableKey = o => o.candidateId ? 'id:' + o.candidateId : o.profileUrl ? 'url:' + o.profileUrl : '';

  const state = helpers.readJson(paths.STATE_FILE, { runs: {} });
  const runMeta = (state.runs && state.runs[runId]) || {};
  const sourceQuery = runMeta.query || '';

  // persona
  let persona = null;
  if (args['persona-file']) {
    try { persona = JSON.parse(fs.readFileSync(args['persona-file'], 'utf8')); }
    catch (e) { return { ok: false, code: 'USAGE', hint: 'persona 文件读取失败：' + e.message }; }
  } else if (args.persona && typeof args.persona === 'string') {
    try { persona = JSON.parse(args.persona); }
    catch (e) { return { ok: false, code: 'USAGE', hint: 'persona JSON 解析失败：' + e.message }; }
  }

  // 合并 list + detail（按姓名对齐）
  const merged = list.map((l, rowIndex) => {
    const row = parseRow(l.lines || []);
    const key = stableKey(l);
    let matches = key ? details.filter(d => stableKey(d) === key) : [];
    if (!matches.length && !key && l.readSource && l.fingerprint && list.filter(x=>x.fingerprint===l.fingerprint).length===1) matches=details.filter(d=>d.fingerprint===l.fingerprint);
    if (!matches.length && !key && !l.readSource && list.filter(x => x.lines?.[0] === row.name).length === 1) {
      matches = details.filter(d => d.name === row.name && !stableKey(d));
    }
    // Repeated reads of one stable identity are versions, not multiple people.
    // Reject conflicting names or profile URLs even if an ID happens to match.
    const names = new Set(matches.map(x => x.name).filter(Boolean));
    const urls = new Set([l.profileUrl, ...matches.map(x => x.profileUrl)].filter(Boolean));
    const conflict = new Set(matches.map(stableKey).filter(Boolean)).size > 1 || names.size > 1 || (names.size === 1 && !names.has(row.name)) || urls.size > 1;
    const valid = matches.filter(x => !x.error && typeof x.text === 'string' && x.text.trim());
    const d = !conflict && (key || l.readSource && l.fingerprint || matches.length === 1) ? (valid.at(-1) || matches.at(-1)) : null;
    const failures = (runMeta.harvest?.errors || []).filter(e => {
      if (e.candidateId != null) return l.candidateId != null && String(e.candidateId) === String(l.candidateId);
      if (e.profileUrl) return Boolean(l.profileUrl && e.profileUrl === l.profileUrl);
      return Number.isInteger(e.rowIndex) && e.rowIndex === rowIndex;
    });
    const failure = failures.at(-1);
    const readOk = Boolean(d && !d.error && typeof d.text === 'string' && d.text.trim());
    const detailError = readOk ? '' : d?.error || failure?.error || failure?.hint || failure?.code || '';
    const det = d ? parseDetail(d.text) : {};
    const cand = { ...row, ...det, hasPdf: d ? !!d.hasPdf : false, attachment: d ? (d.attachment || '') : '', sourceQuery, _text: d ? (d.text || '') : '' };
    Object.assign(cand, { candidateId: l.candidateId || d?.candidateId || '', jobId:l.jobId || '', sourceContext:l.sourceContext || '', sourceUrl:l.sourceUrl || '', attachmentError:d?.attachmentErr || '', profileUrl: l.profileUrl || '', source: l.source || runMeta.source || 'search',
      detailStatus: readOk ? 'read' : detailError ? 'failed' : 'pending_identity_or_detail',
      missingFields: ['years', 'degree', 'current_company'].filter(f => !cand[f]),
      detailError });
    const fit = evalJobFit(persona, cand);
    cand.jobFit = fit.label;
    cand._hits = fit.hits;
    cand._hardOk = fit.hardOk;
    return cand;
  });

  // 去重（name + current_company）
  const seenKey = new Set();
  const deduped = merged.filter((o) => {
    const k = stableKey(o);
    if (!k) return true;
    if (seenKey.has(k)) return false;
    seenKey.add(k);
    return true;
  });

  // 增量过滤
  let rows = deduped;
  let newCount = deduped.length;
  let pendingSeen = null;
  if (args.incremental) {
    const seen = helpers.readJson(paths.SEEN_FILE, {});
    const now = new Date().toISOString();
    const fresh = [];
    for (const o of deduped) {
      const k = stableKey(o);
      if (!k) { fresh.push(o); continue; }
      if (seen[k]) { seen[k].lastRun = now; }
      else { seen[k] = { firstSeen: now, lastRun: now }; fresh.push(o); }
    }
    pendingSeen = seen;
    rows = fresh;
    newCount = fresh.length;
  }

  // 排序：岗位匹配度（硬性优先，再按加分命中数）
  rows.sort((a, b) => (b._hardOk - a._hardOk) || (b._hits - a._hits));

  // 输出成功后才提交增量账本，失败不能消耗未交付候选人。
  const outPath = args.output || path.join(runDir, 'candidates.' + format);
  if (format === 'json') {
    helpers.writeJsonAtomic(outPath, rows.map(({ _hits, _hardOk, _text, ...rest }) => rest));
  } else if (format === 'html') {
    fs.writeFileSync(outPath, toHtml(rows));
  } else {
    fs.writeFileSync(outPath, toCsv(rows));
  }

  if (pendingSeen) helpers.writeJsonAtomic(paths.SEEN_FILE, pendingSeen);

  return {
    ok: true, code: 'OK',
    data: { runId, output: outPath, total: deduped.length, exported: rows.length, newCount, format },
    hint: '导出 ' + rows.length + ' 人（去重后共 ' + deduped.length + ' 人）→ ' + outPath,
  };
}

function toHtml(rows) {
  const sourceLabels = {search:"人才搜索",personal:"个人储备",enterprise:"企业储备",friends:"我的好友",history:"沟通管理",applications:"主动投递",recommendations:"推荐人才",visitors:"职位访客"};
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><title>脉脉候选人审核</title><style>body{font:16px/1.5 system-ui,"PingFang SC",sans-serif;margin:24px;color:#24352e}article{border-top:1px solid #ddd;padding:12px 0}h1{font-size:24px}h2{font-size:18px;margin:0}p{margin:4px 0}.meta{font-size:14px;color:#53665b}pre{white-space:pre-wrap;font:inherit}summary{cursor:pointer}</style><h1>候选人审核 · ${rows.length} 人</h1><p>仅供审核，本报告不执行任何平台操作。</p>${rows.map(o => `<article><h2>${esc(o.name)} · ${esc(o.current_company)} · ${esc(o.current_role)}</h2><p>${esc(o.years || '年限待确认')} 年 / ${esc(o.degree || '学历待确认')} · ${esc(o.jobFit || '未指定评估标准')}</p><p class="meta">来源：${esc(sourceLabels[o.source] || o.source)} / ${esc(o.sourceQuery)} · 详情：${esc(({read:"已读取",failed:"读取失败",pending_identity_or_detail:"身份或详情待确认"})[o.detailStatus] || o.detailStatus)} · 缺失：${esc(o.missingFields.join('、') || '无')} ${esc(o.detailError)}</p><p class="meta">${esc(o.sourceContext)} ${o.attachmentError?'附件未下载：'+esc(o.attachmentError):''}</p><details><summary>查看资料与来源标识</summary><p>${esc(o.candidateId)} ${esc(o.profileUrl)}</p><pre>${esc(o._text || '详情尚未读取或身份待确认')}</pre></details></article>`).join('')}</html>`;
}
