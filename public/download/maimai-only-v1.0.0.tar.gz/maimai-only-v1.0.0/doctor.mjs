#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolveInstallTargets } from './target-distribution.mjs';
const root = path.dirname(fileURLToPath(import.meta.url));
const receipt = JSON.parse(fs.readFileSync(path.join(root, 'distribution.json'), 'utf8'));
const targets = resolveInstallTargets();
const checks = [];
const check = (label, ok, detail) => checks.push({ label, ok, detail });
const atLeast = (actual, minimum) => {
  const a = actual.split('.').map(Number), b = minimum.split('.').map(Number);
  for (let i=0;i<3;i++) { if (a[i]>b[i]) return true; if (a[i]<b[i]) return false; }
  return true;
};
check('Node.js 20.18.1+', atLeast(process.versions.node,'20.18.1'), process.version);
check('实际寻访系统', ['darwin','linux'].includes(process.platform), process.platform);
const candidates = [process.env.EGO_BROWSER_BIN,path.join(os.homedir(),'.local/bin/ego-browser'),'/usr/local/bin/ego-browser','/opt/homebrew/bin/ego-browser'].filter(Boolean);
const binary = process.env.EGO_BROWSER_BIN || candidates.find(p=>fs.existsSync(p)) || 'ego-browser';
const result = spawnSync(binary,['--version'],{encoding:'utf8',timeout:10000});
const output = `${result.stdout||''}${result.stderr||''}`.trim();
const version = output.match(/\b(\d+\.\d+\.\d+)\b/)?.[1];
check('ego-lite 0.5.1+', !result.error && result.status===0 && Boolean(version) && atLeast(version,'0.5.1'), result.error?.message || output || '未取得版本');
for (const {id} of receipt.skills) {
  const hits=targets.skillRoots.filter(p=>fs.existsSync(path.join(p,id,'SKILL.md')));
  check(`Skill ${id}`,hits.length>0,hits.join('、')||'未安装');
}
const ok=checks.every(c=>c.ok);
const unverified=Boolean(result.error);
if (process.argv.includes('--json')) console.log(JSON.stringify({ok,unverified,checks,targets,note:'仅验证本地安装；登录、连接与真实寻访需另行验收。'},null,2));
else { for(const c of checks)console.log(`${c.ok?'✓':'✗'} ${c.label}: ${c.detail}`);console.log(ok?'本地安装检查通过。请继续验证脉脉登录与首次寻访。':'本地检查未通过，请处理失败项。'); }
process.exit(unverified?2:ok?0:1);
