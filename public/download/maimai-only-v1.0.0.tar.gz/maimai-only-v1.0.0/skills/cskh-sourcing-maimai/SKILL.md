---
name: cskh-sourcing-maimai
description: |
  脉脉（maimai）寻访 pipeline 编排 skill。基于 ego-lite 独立浏览器直连 CDP，绕开 opencli/chrome.debugger 被脉脉风控秒杀的问题。
  接收寻访画像（可由 JD 分析得出）→ 关键词搜索缩池 → 详情批量收割 → 岗位匹配度评估 → 结构化 CSV/JSON 交付。
  触发词: 脉脉寻访 / maimai sourcing / 脉脉人才搜索 / 脉脉候选人 / maimai 候选人 / 在脉脉上招 / 脉脉 scout
  与通用 sourcing 词共用范围，但优先在脉脉场景触发。
metadata:
  type: skill
  version: 1.3.0
  status: ready
  disable: false
---

# cskh-sourcing-maimai: 脉脉寻访 Pipeline

编排"寻访画像 → 脉脉关键词搜索 → 详情收割 → 岗位匹配度评估 → 结构化交付"的脉脉寻访工作流。

底层运行时是 **ego-lite**（`ego-browser`，独立 Chromium + 直连 CDP）。脉脉对日常 Chrome + chrome.debugger 风控极敏感（实测 ~7 分钟杀会话），ego-lite 实测 20h+ 存活、120+ 自动点击零风控。本 skill 因此不用 opencli 的脉脉适配器。

**终极目标是对"我们要找的岗位"做匹配，不是对 JD 文本做匹配。** 寻访画像（可由 JD 分析得出）是评估的唯一事实源；搜索阶段用关键词缩池，硬性条件（年限/学历）由 export 阶段对照实际字段复核。

## 触发条件

以下任一情况自动触发：
- 用户说"脉脉寻访"、"maimai sourcing"、"在脉脉上招"
- 用户说"脉脉人才搜索"、"脉脉候选人"、"maimai 候选人"
- 用户给出脉脉链接或要求从脉脉找候选人
- 用户从 `cskh-sourcing` 分发器选择脉脉

输入可以是一句话，也可以是 **JD 分析后得出的寻访画像**（JSON）。只有零散要求时，先向用户澄清画像的硬性条件与加分项，不得自行编造。

## 运行环境（必须先自检）

本 skill 的运行时分两层，适配边界不同：

| 层 | 依赖 | macOS | Linux | Windows |
|---|---|---|---|---|
| 消费层（SKILL.md 编排、export 本地处理） | Node ≥ 18 | ✅ | ✅ | ✅ |
| 运行时层（login/search/harvest，驱动 ego 浏览器） | ego-browser ≥ 0.5.1 | ✅ | ✅ | ❌ 暂不支持 |

**ego-lite 目前没有 Windows 版。** Windows 上运行时会得到 `UNSUPPORTED_PLATFORM` 错误并明确提示，不会静默失败。WorkBuddy 装在 Windows 上时，消费层可正常读取本 skill 并给出诚实提示；要真正跑寻访需在 macOS/Linux 机器执行。

自检（每次新会话首次进入时执行一次）：

```bash
node --version          # 需 ≥ 18
ego-browser --version   # 需 ≥ 0.5.1；不存在则说明运行时层不可用
```

ego-browser 不在 PATH 时，可用环境变量 `EGO_BROWSER_BIN` 指定绝对路径。

## 关键规则（不可违反）

1. **绝不触发任何写操作。** 本 skill 不提供、也不得间接调用脉脉的"立即沟通 / 电话沟通 / 加好友 / 加入储备"等任何写接口。所有命令都是只读的搜索与详情读取。
2. **节奏下限 ≥ 1.6 秒/人。** harvest 内置硬下限，不得为提速绕过。单轮 harvest 建议 ≤ 30 人，长任务分多轮。
3. **不落任何凭据。** 不读取、不保存、不打印 cookie / token / 密码。登录完全由人在 ego 弹出的浏览器窗口里完成。
4. **每个 space 串行。** 同一时刻只允许一个 ego 命令在跑；上一条结束、页面稳定后才执行下一条。禁止并发跑 search/harvest。
5. **中断靠 state 恢复，不靠重跑。** 所有进度落在 `~/.maimai-scout/`（state.json / page-map.json / seen.json / output/）。中断后从游标续跑，不要从头重搜。
6. **账号权限每次执行都检查。** 账号可能不是付费账号、可能权限不足。每次执行先 `health` 探登录态与权限；权限不足时明确报告，不得静默返回空结果。
7. **诚实报错。** 页面改版导致选择器失效时报 `PAGE_MAP_DRIFT`，重跑 `explore` 自愈；不得猜旧选择器硬点。

## 命令参考

统一入口是 `node <SKILL_DIR>/scripts/mm.mjs <cmd> [args]`。所有命令输出单行 JSON 信封 `{ok, code, data, hint}`，失败时 exit 1。`<SKILL_DIR>` 指本 skill 安装目录的绝对路径。

| 命令 | 说明 | 关键参数 |
|---|---|---|
| `login` | 建/复用浏览器 space；未登录则交还用户人工登录 | `--resume`（登录完成后接管并验证） |
| `health` | 探登录态、space 存活、page-map 版本、已见人数 | — |
| `explore` | 生成页面地图（选择器断言），写入 page-map.json | — |
| `search` | 关键词搜索 + 页面筛选 + 翻页，采集候选人列表到 list.jsonl | `--query --pages N [--filters '<json>'] [--run <id>]` |
| `harvest` | 从游标续跑，批量收割详情到 detail.jsonl；`--with-attachment` 顺手下载附件简历 | `--run <id> [--limit N] [--with-attachment]` |
| `export` | 解析 list+detail → 去重 → 岗位匹配度 → CSV/JSON | `--run <id> [--format csv\|json] [--incremental] [--persona '<json>'\|--persona-file <path>]` |
| `finish` | 释放浏览器 space | `--keep`（保留页面） |

错误码：`NOT_LOGGED_IN` / `PAGE_MAP_DRIFT` / `SPACE_LOST` / `RATE_LIMITED` / `SELECTOR_MISSING` / `FILTER_NOT_APPLIED` / `UNSUPPORTED_PLATFORM` / `EGO_NOT_FOUND` / `USAGE`。

## 页面筛选（--filters）

search 支持 `--filters '<json>'`，模拟真人点击搜索页筛选（实测：筛选不进 URL，只能点 UI）。筛选随 run 持久化，**harvest 会自动重放**（筛选是纯前端状态，重新导航后不点就没了，不重放会收割错人）。

```bash
node <SKILL_DIR>/scripts/mm.mjs search --query "数据采集" --pages 1 \
  --filters '{"workyears":"5-10年","degree":"本科及以上","city":"北京","hasPdf":true}'
```

面板筛选（值 = 页面上的选项原文）：

| key | 页面筛选项 | 示例值 |
|---|---|---|
| `city` | 城市地区 | `"北京"`（热门城市直选；也可填省名） |
| `cityMode` | （city 弹层内）期望/现居 | `"期望"` / `"现居"`，默认两个都勾=不限 |
| `degree` | 学历要求 | `"本科及以上"` / `"硕士及以上"` / `"专科及以上"` / `"博士"` |
| `workyears` | 工作年限 | `"5-10年"` / `"3-5年"` / `"1-3年"` / `"10年以上"` / `"在校/应届"` / `"1年以内"` |
| `gender` | 性别 | `"男"` / `"女"` |
| `company` | 就职公司 | `"BAT"` / `"一线互联网公司"` 等预设标签 |
| `companyTab` | （company 弹层内）正任职/曾任职 | `"正任职"` / `"曾任职"`，默认两个都勾=不限 |
| `jobtitle` | 职位名称 | `"算法"` / `"后端开发"` 等预设标签 |
| `industry` | 行业方向 | `"IT/互联网/游戏"`；**支持数组多选（≤10）**：`["IT/互联网/游戏","金融业"]` |
| `school` | 毕业学校 | `"985"` / `"211"` / `"QS排名Top500"` 等 |
| `major` | 专业 | `"计算机"`——联想式搜索，自动点第一个匹配联想项 |
| `hometown` | 家乡 | 同 city |
| `aiTalent` | AI人才类型 | `"全部AI人才"` 等 |

区间筛选（值 = `"下限-上限"`，单边开放 `"-40"` / `"30-"` 也行）：

| key | 页面筛选项 | 示例值 |
|---|---|---|
| `age` | 年龄 | `"30-40"`（岁） |
| `salary` | 期望月薪 | `"30-50"`（k） |

结果区筛选：

- **chip**（值固定 `true`）：`intent`（公开求职意向）、`active`（近期有动向）、`hasPdf`（**有附件简历**）、`hadIntent`、`enterprise`、`notViewed`、`notContacted`、`hasNote`、`noNote`、`followed`、`notFollowed`
- `smartFilter`：智能筛选开关（值 `true`，已开则跳过）
- `friend`：好友关系，`"是"` / `"否"`
- `sort`：排序，`"综合排序"` / `"活跃优先"` / `"匹配度优先"`
- `match`：关键词匹配模式，`"所有"` / `"任一"`

特殊行为（实测）：带子弹层的选项（如 `本科及以上` → 不限/只看统招本科）默认选「不限」，可用 `<key>Sub` 指定（如 `"degreeSub":"只看统招本科"`）。

**诚实性保证**：每个面板筛选应用后会校验筛选栏出现「标签：值」，没生效报 `FILTER_NOT_APPLIED`，绝不静默返回未筛选的结果。可选值全集见 [references/filters.md](references/filters.md)。

## 状态与文件

所有状态在 `~/.maimai-scout/`（skill 私有，不依赖 hunter 也能独立用）：

```
~/.maimai-scout/
├── state.json          # space、login、runs（query/cursor/pageSize）
├── page-map.json       # explore 产物，运行时断言用
├── seen.json           # 增量去重账本 {"姓名|公司": {firstSeen, lastRun}}
├── downloads/<runId>/    # --with-attachment 下载的附件简历原件
└── output/<runId>/
    ├── list.jsonl      # search 产物（候选人列表行）
    ├── detail.jsonl    # harvest 产物（详情文本，按全局行号 rowIndex 对齐）
    └── candidates.csv  # export 产物（带 BOM，Excel 直接开）
```

写操作一律 tmp+rename，防中断留半个 JSON。

## Recipes

### 1. 首次登录（人在环）

```bash
node <SKILL_DIR>/scripts/mm.mjs login
```

ego 会弹出浏览器窗口。若未登录，命令返回 `NEEDS_LOGIN` 并交还控制权——**把提示原样转达用户**，请用户在弹出的 ego 窗口里扫码/账号登录脉脉（不要代填任何凭据）。用户登录完成后：

```bash
node <SKILL_DIR>/scripts/mm.mjs login --resume
```

验证通过后会话即建立。每次执行寻访前用 `health` 复查登录态与账号权限。

### 2. 关键词矩阵一轮寻访

画像里有多个搜索角度时，逐关键词跑（串行，不并发）。每个关键词一轮：

```bash
node <SKILL_DIR>/scripts/mm.mjs health
node <SKILL_DIR>/scripts/mm.mjs search --query "数据采集 负责人" --pages 2
# search 返回 data.runId，例如 20260924-数据采集-负责人
node <SKILL_DIR>/scripts/mm.mjs harvest --run 20260924-数据采集-负责人 --limit 20
node <SKILL_DIR>/scripts/mm.mjs export --run 20260924-数据采集-负责人 --persona '{"hard":{"years":"5-10","degree":"本科"},"bonus":["英文工作语言","团队管理经验"]}'
```

多组关键词时，每组用不同 `--run`（search 自动按 query+日期生成），最后可分别 export 或合并。

### 3. 增量日巡

每天对同一批关键词重跑 search + harvest，export 加 `--incremental`，只导出相对 `seen.json` 的新人：

```bash
node <SKILL_DIR>/scripts/mm.mjs search --query "数据采集 负责人" --pages 1
node <SKILL_DIR>/scripts/mm.mjs harvest --run <新runId> --limit 30
node <SKILL_DIR>/scripts/mm.mjs export --run <新runId> --incremental --persona-file <画像.json>
```

### 4. 岗位匹配度评估（核心）

export 的 `--persona` 是评估的唯一事实源，结构：

```json
{
  "hard": { "years": "5-10", "degree": "本科" },
  "bonus": ["英文工作语言", "团队管理经验", "出海背景"]
}
```

- `hard.years`：年限区间（如 `"3-5"`、`"5-10"`），候选人年限不在区间内 → `硬性✗`
- `hard.degree`：学历下限（`大专`/`本科`/`硕士`/`博士`/`MBA`），候选人学历低于它 → `硬性✗`
- `bonus`：加分项数组，逐项在候选人亮点/历任公司里找证据，命中标 `✓`

输出的 `岗位匹配度` 列形如 `英文✓ 管理✓ 硬性✓`，排序规则：硬性通过优先，再按加分命中数降序。**硬性✗ 的候选人不会被删除**，只排在后面并标注原因，由人判断。

## 数据获取边界（必须向用户讲清）

"全量简历"的定义是 **脉脉页面公开展示的完整资料**，有三个客观边界：

1. 候选人自己没填的字段（如期望薪资、完整教育经历）拿不到
2. 页面折叠/截断的部分，实现会尽量自动展开（点"展开更多"），但极端长文可能仍有截断
3. **附件简历：harvest 加 `--with-attachment` 可下载原件**（v1.3.0），存到 `~/.maimai-scout/downloads/<runId>/`，CSV 多一列「附件文件」。
   注意两个边界：① 附件格式不假定是 PDF（页面上什么文件名就存什么，实测样例为 .pdf）；
   ② 实测下载的 PDF 是图片型（Pillow 渲染），文字不进 CSV，要全文检索需另做 OCR（v2 再看）

所以 CSV 是"脉脉公开资料的完整结构化"，不是"候选人原始简历附件的全文"。

## Pitfalls

以下都是 2026-09-24 对真实脉脉招聘端实测踩过的坑，不是猜测：

- **抽屉关闭用 Escape**：详情是 antd 抽屉，但**没有 `.ant-drawer-close` 按钮**，点 mask 也关不掉，实测只有按 `Escape` 能关。且抽屉打开时再点其他卡片不会切换内容——必须先 Escape 关掉再点下一张。收割循环是「点卡 → 读 → Escape 关 → 点下一张」。
- **抽屉遮挡点不到**：收割时对卡片用 `data-mm-row` 标记 + `force:true` 点击，绕开抽屉/浮层遮挡。
- **登录态不用 data-testid**：脉脉招聘端页面没有任何 `data-testid` 属性。登录判断靠导航信号（已登录有「人才库/沟通中/个人储备」，登录墙是「扫码/密码登录」）。
- **SPA 异步加载**：搜索结果要 1.5~4 秒才渲染，偶发不触发搜索 XHR。`gotoSearch` 用 `waitForFunction` 等卡片出现（options 是第三参，省略 argument 传 `undefined`），等不到就 `reload()` 重试一次。别用固定 sleep。
- **跨会话列表会重排**：脉脉按活跃度等排序，search 时第 N 行 ≠ harvest 时第 N 行。所以详情按**姓名**对齐（harvest 给每条详情打了卡片姓名），不靠行号；rowIndex 仅作参考，不做兜底（避免把错的详情安到错的人）。
- **分页是编号页码**：`[class*="pagesItem"]`，当前页带 `current` 类。`gotoNextPage` 点「当前页+1」那个页码，不是"下一页"文本按钮。
- **风控信号**：出现验证码即 `RATE_LIMITED`，已安全收割的部分保留，停止并建议稍后续跑，不硬闯。
- **space 丢失**：ego 浏览器被关/崩溃 → `SPACE_LOST`，重新 `login` 即可，state 里的 run 游标还在。
- **卡片行格式**：候选人卡片（`.talent-common-card`）的 innerText 是 `[姓名, 活跃度, 立即沟通, N年, 学历, 现居地, (期望)?, (意向)?, 职业标签：, ...标签, 工作段..., 教育段...]`。当前职位取「至今」那段。详见 [references/selectors.md](references/selectors.md)。

选择器细节、page-map 结构、漂移自愈流程见 [references/selectors.md](references/selectors.md)。

## 与 cskh-sourcing 分发器的关系

- `cskh-sourcing` 是通用入口，收到 sourcing 请求时先问平台。
- 用户选择脉脉后，`cskh-sourcing` 把上下文交给 `cskh-sourcing-maimai` 执行。
- 用户直接说脉脉相关词时，优先触发本 skill，跳过平台选择。

## See also

- `cskh-align`：JD → 寻访画像（SourcingRequest）
- `cskh-sourcing`：多平台分发器
- `ego-browser` skill：ego-lite API 事实源
- [references/selectors.md](references/selectors.md)：page-map 结构与漂移自愈
- [references/filters.md](references/filters.md)：筛选码表（年限/学历/排序）
- [references/hunter-export.md](references/hunter-export.md)：tags.csv / sourcing raw json 出口契约（v2）
