# Hunter ATS 出口契约（v2 计划）

> **状态：v2，MVP 不实现。** MVP 的 `export` 只产出本地 CSV/JSON（见 SKILL.md）。本文件描述未来把脉脉候选人接入 Hunter ATS（谷露 gllue）时的出口契约，数据源是 `hunter/packages/hunter-maimai/scout.js` 已验证的格式。实现 `export --hunter` 时以此为准。

## 背景

Hunter 体系里，脉脉渠道的候选人要进 ATS，走两个落点：

1. `~/.hunter/channels/maimai/tags.csv` — 标签账本，供 gllue 查重/打标
2. `~/.hunter/sourcing/<title>-<YYYYMMDD>-maimai-raw.json` — 标准化原始数据，供后续 LLM 评估与报告

MVP 的 `cskh-sourcing-maimai` 不依赖 hunter 也能独立跑（状态全在 `~/.maimai-scout/`），v2 才桥接回 hunter 目录。

## tags.csv 契约

位置：`~/.hunter/channels/maimai/tags.csv`

```csv
profileId,name,tags,searchKeyword,searchCity,searchTime,processed
```

| 列 | 含义 |
|---|---|
| `profileId` | 脉脉候选人唯一 id（详情页 URL 里的 id） |
| `name` | 姓名 |
| `tags` | 标签（多个用分号/逗号分隔，来自 `item.tag_list`） |
| `searchKeyword` | 命中的搜索关键词 |
| `searchCity` | 搜索城市 |
| `searchTime` | 入库时间（`YYYY-MM-DD HH:mm:ss`） |
| `processed` | 是否已处理（`false` 初始，gllue 处理后置 true） |

每行追加写入；文件不存在时先写 header。这是增量与查重的账本，**不得覆盖，只能追加**。

## sourcing raw json 契约

位置：`~/.hunter/sourcing/<title>-<YYYYMMDD>-maimai-raw.json`

```json
{
  "meta": {
    "channel": "maimai",
    "keywords": ["..."],
    "city": "...",
    "timestamp": "...",
    "totalCollected": 0,
    "listPageFiltered": 0
  },
  "candidates": [ { "...": "标准化候选人" } ],
  "filteredOut": [ { "...": "被硬性条件淘汰的候选人 + failReasons" } ]
}
```

候选人核心字段（scout.js 第 178-187 行附近）：

| 字段 | 来源 |
|---|---|
| `profileId` | 候选人 id |
| `name` | 姓名 |
| `position` / `company` | 现职位 / 现公司 |
| `work_year` | 工作年限（`work_time`/`worktime`） |
| `degree` | 学历（`schoolInfo.sdegree` / `hover.school_level`） |
| `tags` | 标签数组 |
| `listPageText` | 列表页文本拼接（`name position company tags`），供 LLM 列表初评 |

`filteredOut` 里每人带 `failReasons`（如 `学历本科 不匹配 硕士`），保留被淘汰者与原因，不静默删除。

## MVP export 与 v2 --hunter 的字段映射

MVP 的 `export` 产出列（见 SKILL.md）与 hunter 候选人的对应关系：

| MVP CSV 列 | hunter 字段 |
|---|---|
| 姓名 | `name` |
| 现公司 | `company` |
| 现职位 | `position` |
| 年限 | `work_year` |
| 学历 | `degree` |
| 来源query | `meta.keywords` |
| 亮点摘要 | `listPageText`（或详情 highlight） |

MVP 目前没有 `profileId`（详情抽屉 URL 未采集），v2 实现 `--hunter` 时需补采 `profileId` 才能写入 tags.csv 做查重。

## 桥接原则

- v2 的 `export --hunter` 在 `--incremental` 去重后，把**新人**追加进 tags.csv，把整轮（含 filteredOut）写进 raw json
- 写 hunter 目录前确认 `HUNTER_DATA_DIR`（默认 `~/.hunter`），项目级安装不得回退写别的 agent 的用户目录
- 本 skill 的 `~/.maimai-scout/` 仍是主状态；hunter 目录只是出口副本，不反向依赖
