# 脉脉页面地图（page-map）与漂移自愈

脉脉前端会改版。本 skill 不硬编码"永远正确"的选择器，而是用一份**页面地图**（page-map.json）在运行时断言关键定位标记还在；一旦缺失就报 `PAGE_MAP_DRIFT`，重跑 `explore` 自愈。

> 本文的选择器是 2026-09-24 对真实脉脉招聘端（maimai.cn/ent）实测校准的，不是猜的。

## page-map.json 结构

由 `mm explore` 生成，落在 `~/.maimai-scout/page-map.json`：

```json
{
  "version": "2026-09-24",
  "generatedAt": "2026-09-24T08:00:00.000Z",
  "selectors": {
    "talentCard": ".talent-common-card",
    "searchInput": "input[placeholder*=\"搜索\"], input[type=\"text\"]"
  },
  "drawer": { "open": ".ant-drawer-open", "close": ".ant-drawer-close" },
  "probes": { "rowCount": 30, "detailOk": true, "loginOk": true },
  "missing": [],
  "notes": "..."
}
```

| 字段 | 含义 |
|---|---|
| `version` | 生成日期（`YYYY-MM-DD`），`mm health` 显示它作为 page-map 年龄 |
| `selectors` | **search 页断言用**的选择器（运行时 `assertPageMap` 只断言这里的 `talentCard`） |
| `drawer` | 抽屉选择器，**点击后才存在**，不参与 search 页断言 |
| `probes` | explore 时的探测结果（行数/详情可读/登录态），用于判断地图健康度 |
| `missing` | explore 时探测失败项；非空说明页面结构有变化，需人工关注 |

## 各选择器的作用（实测）

| key | 选择器 | 用途 | 实测备注 |
|---|---|---|---|
| `talentCard` | `.talent-common-card` | 候选人卡片，search/harvest 的数据源 | 稳定类名（无 CSS-module hash），一页约 30 张 |
| `searchInput` | `input[placeholder*="搜索"]` | 搜索输入框（备用，当前走 URL 直达） | 仅供参考，不参与断言 |
| `drawer.open` | `.ant-drawer-open` | 详情抽屉容器，`readDetailText` 抓全文 | antd 抽屉，点击卡片后打开 |
| `drawer.close` | `.ant-drawer-close` | 见下方警告 | **脉脉抽屉没有这个按钮，实际用 Escape 关闭** |

### 关键实测结论（容易踩坑）

1. **登录态不用 data-testid**：脉脉招聘端页面**没有任何 `data-testid` 属性**，`[data-testid="viewer-name"]` 不存在。`detectLogin` 改用导航信号判断——已登录的招聘后台有「人才库/沟通中/个人储备/待处理投递」，登录墙则是「扫码/密码/验证码登录」。

2. **抽屉关闭用 Escape，不是点按钮**：抽屉打开后盖住右侧，**没有 `.ant-drawer-close` 关闭按钮**，点 `.ant-drawer-mask` 也关不掉。实测**只有按 `Escape` 能关**。且抽屉打开时再点其他卡片不会切换内容——必须先 Escape 关掉再点下一张。

3. **列表容器不是 `.talent-list`**：真实候选人卡片是 `.talent-common-card`，列表容器是 `recruitTalentsContainer___<hash>`（CSS modules，hash 会变）。所以按卡片类名取，不按容器。

4. **卡片行格式**（`markAndReadRows` 抓的 innerText 行）：
   ```
   [姓名, 活跃度, 立即沟通, N年, 学历, 现居地, (期望：...)?, (求职意向)?, (近期有动向)?,
    职业标签：, ...标签, 工作段(period, 公司, ·, 职位)..., 教育段(period, 学校, ·, 专业, ·, 学历)...]
   ```
   当前职位取「至今」那一段（同公司多段经历时，至今才是现任）。

## 运行时断言流程

`search` / `harvest` 开头调用 `assertPageMap(page)`：

1. 若 `~/.maimai-scout/page-map.json` 不存在（还没 explore 过），跳过断言，直接跑
2. 断言 `selectors.talentCard` 存在（`drawer` 里的选择器点击后才用，此处不断言，避免误报）
3. 不存在 → 抛 `PAGE_MAP_DRIFT`，提示：`页面定位标记缺失：talentCard = ...。脉脉页面可能改版，请运行 explore 重新生成 page-map。`

## 漂移自愈

```
search/harvest 报 PAGE_MAP_DRIFT
  → mm explore        # 重新探测当前页面结构，生成新 page-map.json
  → 重跑原命令         # 断言通过，继续
```

`explore` 自己会探测：登录态（`detectLogin`）、卡片（`.talent-common-card`）、卡片可读性（`markAndReadRows`）、详情抽屉（打开第一张卡验证 `readDetailText` 能拿到 >50 字）。任何一项失败会记入 `missing` 并在提示里列出。

**实测验证过的自愈**：改坏 `talentCard` → search 报 `PAGE_MAP_DRIFT` → `explore` 重生成 → search 恢复。

## SPA 异步加载（重要）

搜索结果是 **SPA 异步渲染**的，`page.goto` 后页面先显示"加载中..."，卡片要 1.5~4 秒才出现，且**偶发不触发搜索 XHR**。所以：

- `gotoSearch` 用 `page.waitForFunction` 等 `.talent-common-card` 出现（不是固定 sleep）
- `waitForFunction` 签名是 `(fn, argument, options)`，**options 是第三个参数**，省略 argument 要显式传 `undefined`
- 等不到就 `page.reload()` 刷新重试一次

## 已知脆弱点

- `.talent-common-card` 是类名，脉脉改版换类名就会漂移 → 靠 `explore` 重新探测；但 `explore.mjs` 里的候选选择器本身也是硬编码，极端改版时需人工更新
- 分页是编号页码（`[class*="pagesItem"]`，当前页带 `current` 类），`gotoNextPage` 点「当前页+1」那个页码，不是"下一页"文本按钮
- 列表**跨会话会重排**（脉脉按活跃度等排序）：search 时第 N 行 ≠ harvest 时第 N 行。所以详情按**姓名**对齐，不靠行号（见 SKILL.md「跨页游标对齐」）
