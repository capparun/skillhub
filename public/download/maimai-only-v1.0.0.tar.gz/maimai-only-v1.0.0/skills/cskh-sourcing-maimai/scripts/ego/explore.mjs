// explore.mjs — build-time 页面地图：探测关键选择器并生成 page-map.json
// 用法：mm explore [--query 测试关键词]
// 依赖 lib.mjs 注入：ARGS, CTX, PAGE_MAP
// 产出：信封 data.pageMap（由 mm.mjs 写入 ~/.maimai-scout/page-map.json）

async function main() {
  if (CTX.spaceId == null) throw new MmError('NOT_LOGGED_IN', '请先运行 mm login 登录脉脉。');
  const task = await getTask();
  const page = getPage(task);

  const query = ARGS.query || '产品经理';
  const selectors = {};
  const missing = [];

  // 1) 登录态信号（招聘端无 data-testid，靠 detectLogin 的导航/登录墙信号）
  const login = await detectLogin(page);
  if (!login.loggedIn) {
    emit(false, 'NOT_LOGGED_IN', { loggedIn: false, url: login.url }, '当前未登录，无法探测页面。请先运行 mm login。');
    return;
  }

  // 2) 搜索页结构（真实招聘端：候选人卡片是 .talent-common-card）
  await gotoSearch(page, query);
  const listProbe = await page.evaluate(() => {
    const sels = {
      talentCard: '.talent-common-card',
      searchInput: 'input[placeholder*="搜索"], input[type="text"]',
    };
    const found = {};
    for (const k of Object.keys(sels)) found[k] = !!document.querySelector(sels[k]);
    return found;
  });
  Object.assign(selectors, {
    talentCard: '.talent-common-card',
    searchInput: 'input[placeholder*="搜索"], input[type="text"]',
  });
  if (!listProbe.talentCard) missing.push('talentCard');

  // 3) 卡片可读性
  let rowCount = 0;
  try {
    const rows = await markAndReadRows(page);
    rowCount = rows.total;
  } catch (e) { missing.push('talentCard-rows'); }

  // 4) 详情抽屉（打开第一张卡验证；抽屉选择器只在点击后存在，不进 search 页断言）
  let detailOk = false;
  try {
    await openDetail(page, 0);
    const d = await readDetailText(page);
    detailOk = !d.error && (d.text || '').length > 50;
    await closeDetail(page);
  } catch (e) { missing.push('drawer'); }

  const pageMap = {
    version: new Date().toISOString().slice(0, 10),
    generatedAt: new Date().toISOString(),
    selectors,                                   // search 页断言用
    drawer: { open: '.ant-drawer-open', close: '.ant-drawer-close' },  // 点击后才用，不参与 search 页断言
    probes: { rowCount, detailOk, loginOk: true },
    missing,
    notes: '由 mm explore 生成。运行时 search/harvest 先断言 selectors（search 页）；抽屉选择器仅在点击后使用。缺失报 PAGE_MAP_DRIFT，重跑 explore 自愈。',
  };

  emit(true, 'OK', { pageMap, rowCount, detailOk, missing },
    missing.length ? ('page-map 已生成，但有 ' + missing.length + ' 项探测失败：' + missing.join(', ')) : 'page-map 生成成功，关键选择器全部可用。');
}

main().catch((e) => emit(false, e.code || 'INTERNAL', e.data || null, e.hint || e.message));
