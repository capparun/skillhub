// finish.mjs — 释放 task space（默认关闭，--keep 保留页面）
// 用法：mm finish [--keep]
// 依赖 lib.mjs 注入：ARGS, CTX, PAGE_MAP

async function main() {
  if (CTX.spaceId == null) { emit(true, 'OK', { released: false }, '没有需要释放的会话。'); return; }
  const task = await getTask();
  const keep = ARGS.keep ? ['p1'] : [];
  let receipt = null;
  try { receipt = await task.finish({ keep }); }
  catch (e) { throw new MmError('INTERNAL', '释放会话失败：' + (e && e.message ? e.message : e)); }
  emit(true, 'OK', { released: true, receipt, __statePatch: { space: null, login: { status: 'unknown', checkedAt: null, accountHint: null } } },
    ARGS.keep ? '会话已保留（keep），space 记录已清除。' : '会话已释放并关闭。');
}

main().catch((e) => emit(false, e.code || 'INTERNAL', e.data || null, e.hint || e.message));
