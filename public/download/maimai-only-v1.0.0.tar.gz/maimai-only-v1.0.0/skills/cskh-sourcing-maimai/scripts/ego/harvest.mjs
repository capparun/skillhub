// harvest.mjs — 详情抽屉批量收割（断点续跑，跨页，节奏 ≥1.6s/人）
// 用法：mm harvest --run <runId> [--limit 10] [--with-attachment]
// 依赖 lib.mjs 注入：ARGS（含 run/query/cursor/pageSize/totalFromSearch）、CTX、PAGE_MAP
// 说明：
//   - cursor 是全局行号（与 search 的扁平 rows 下标一致）。先翻到 cursor 所在页，再跨页收割。
//   - search 与 harvest 之间列表会重排（脉脉按活跃度等排序），所以每条详情都打上卡片姓名（name），
//     由 export 按姓名对齐，不依赖 rowIndex，也不重抓列表（避免多页截断）。
//   - --with-attachment：有附件简历的人顺手下载附件，存到 mm.mjs 注入的 dlDir（downloads/<runId>/），
//     文件名用页面上的原始文件名（格式不假定，实测样例为图片型 .pdf）。单条下载失败不致命，记 attachmentErr 继续。
// 返回：信封 data {runId, cursor, details:[{rowIndex,name,text,hasPdf,attachment,attachmentErr}], errors}
//   mm.mjs 负责把 details 追加写入 detail.jsonl、更新 state.runs[runId].harvest.cursor

async function main() {
  const runId = ARGS.run;
  if (!runId) throw new MmError('USAGE', '缺少 --run 参数。示例：mm harvest --run <runId> --limit 10');
  const query = ARGS.query;
  if (!query) throw new MmError('USAGE', 'state 里该 run 没有 query，无法收割。请重新运行 search。');
  const startCursor = parseInt(ARGS.cursor, 10) || 0;
  const limit = parseInt(ARGS.limit, 10) || 10;
  const pageSize = parseInt(ARGS.pageSize, 10) || 30;
  const totalFromSearch = parseInt(ARGS.totalFromSearch, 10) || 0;
  const withAttachment = ARGS.withAttachment === true || ARGS.withAttachment === 'true' || ARGS.withPdf === true || ARGS.withPdf === 'true';
  const dlDir = ARGS.dlDir || '';

  const task = await getTask();
  const page = getPage(task);
  await gotoSearch(page, query);
  // harvest 必须重新应用 search 时的筛选：筛选是纯前端状态，重新 goto 后不会保留；
  // 不重新应用会拿到未筛选的列表，游标/翻页全错（详情仍按姓名对齐，但会收割错人）。
  // filters 由 mm.mjs 从 state.runs[runId].filters 注入。
  if (ARGS.filters && Object.keys(ARGS.filters).length) {
    await applyFilters(page, ARGS.filters);
  }
  // 断言必须在 gotoSearch 之后（同 search.mjs）：先断言会在页面不在搜索页时误报漂移。
  await assertPageMap(page);

  // 翻到 cursor 所在页
  const targetPage = Math.floor(startCursor / pageSize) + 1;
  for (let p = 1; p < targetPage; p++) {
    const ok = await gotoNextPage(page);
    if (!ok) throw new MmError('INTERNAL', '无法翻到第 ' + targetPage + ' 页（候选池可能已变化），请重新运行 search。');
  }

  const details = [];
  const errors = [];
  let cursor = startCursor;
  let startInPage = startCursor % pageSize;
  let rateLimited = false;

  while ((cursor - startCursor) < limit) {
    const rows = await markAndReadRows(page);
    if (!rows.total) break;
    for (let i = startInPage; i < rows.total && (cursor - startCursor) < limit; i++) {
      const cardName = (rows.rows[i] && rows.rows[i].lines[0]) || '';
      try {
        const riskCheck = await detectRisk(page);
        if (riskCheck.hasCaptcha) {
          errors.push({ rowIndex: cursor, name: cardName, error: 'RATE_LIMITED: 触发验证码，停止收割' });
          rateLimited = true;
          break;
        }
        await openDetail(page, i);
        const d = await readDetailText(page);
        let attachment = null;
        let attachmentErr = null;
        if (withAttachment) {
          try {
            const att = await downloadAttachment(page, dlDir);
            if (att.ok) attachment = att.file;
            else attachmentErr = att.reason;
          } catch (e) {
            attachmentErr = e.hint || e.message;
          }
        }
        details.push({ rowIndex: cursor, name: cardName, text: d.text, hasPdf: d.hasPdf, attachment, attachmentErr });
        await closeDetail(page);
        cursor++;
        await sleep(page, 1600); // 节奏 ≥1.6s/人
      } catch (e) {
        errors.push({ rowIndex: cursor, name: cardName, error: e.hint || e.message });
        cursor++;
        try { await closeDetail(page); } catch { /* 忽略 */ }
        await sleep(page, 800);
      }
    }
    if (rateLimited) break;
    if (totalFromSearch && cursor >= totalFromSearch) break;
    if ((cursor - startCursor) >= limit) break;
    const hasNext = await gotoNextPage(page);
    if (!hasNext) break;
    startInPage = 0; // 下一页从头开始
  }

  emit(true, 'OK', { runId, cursor, details, errors, harvested: details.length, rateLimited },
    '收割 ' + details.length + ' 人详情（游标推进到 ' + cursor + '），失败 ' + errors.length + ' 条。' + (rateLimited ? '疑似触发风控，已停止。' : ''));
}

main().catch((e) => emit(false, e.code || 'INTERNAL', e.data || null, e.hint || e.message));
