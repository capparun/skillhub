// health.mjs — 健康检查：space 存活 + 登录态 + 页面可访问
// 用法：mm health
// 依赖 lib.mjs 注入：ARGS, CTX, PAGE_MAP
// 返回 {login, spaceAlive, accountHint}；pageMapAge/seenCount 由 mm.mjs 本地补充

async function main() {
  if (CTX.spaceId == null) {
    emit(false, 'NOT_LOGGED_IN', { spaceAlive: false, login: 'unknown' }, '还没有会话。请先运行 mm login。');
    return;
  }
  let task;
  try { task = await getTask(); }
  catch (e) {
    emit(false, 'SPACE_LOST', { spaceAlive: false, login: 'unknown' }, e.hint || 'space 已失效，请重新运行 mm login。');
    return;
  }
  const page = getPage(task);
  let login = { loggedIn: false, accountHint: null };
  try { login = await detectLogin(page); }
  catch (e) { /* 探测失败按未登录处理 */ }

  emit(true, 'OK', {
    spaceAlive: true,
    login: login.loggedIn ? 'ok' : 'expired',
    accountHint: login.accountHint,
    __statePatch: { login: { status: login.loggedIn ? 'ok' : 'expired', checkedAt: new Date().toISOString(), accountHint: login.accountHint } },
  }, login.loggedIn ? ('会话正常，已登录：' + (login.accountHint || '')) : 'space 存活但登录已失效，请运行 mm login 重新登录。');
}

main().catch((e) => emit(false, e.code || 'INTERNAL', e.data || null, e.hint || e.message));
