// lib.mjs — ego 环境公共库（被 mm.mjs 内联拼装，无 import/export，纯页面操作）
// 依赖注入的全局：ARGS（命令参数）、CTX（spaceId/pageLabel/路径）、PAGE_MAP（页面地图）
// 只能使用 ego API（page.*）与基础 JS；不得假设 Node fs 可用。

class MmError extends Error {
  constructor(code, hint, data) { super(hint); this.code = code; this.hint = hint; this.data = data || null; }
}

function emit(ok, code, data, hint) {
  console.log(JSON.stringify({ ok, code, data: data === undefined ? null : data, hint: hint || null }));
}

const MM = {
  home: 'https://maimai.cn/ent/index/',
  search: (q) => 'https://maimai.cn/ent/v41/recruit/talents?query=' + encodeURIComponent(q) + '&tab=1',
};

async function sleep(page, ms) { await page.waitForTimeout(ms); }

// 恢复 task space（跨调用持久）；无 spaceId 则报错
async function getTask() {
  if (CTX.spaceId == null) throw new MmError('SPACE_LOST', 'state 里没有 spaceId，请先运行 login 建立会话。');
  let task;
  try { task = await taskSpace(CTX.spaceId); }
  catch (e) { throw new MmError('SPACE_LOST', 'task space 已失效（可能 ego 重启或 space 被关闭）。请重新运行 login。' + (e && e.message ? '：' + e.message : '')); }
  return task;
}
function getPage(task) { return task.page(CTX.pageLabel || 'p1'); }

// 探测登录态：招聘方后台（人才银行）有 人才库/沟通中/个人储备/待处理投递 等导航；登录墙则是 扫码/密码/验证码登录。
// 注：脉脉招聘端页面不用 data-testid，不能靠 viewer-name 探针。
async function detectLogin(page) {
  await page.goto(MM.home).catch(() => {});
  await sleep(page, 1800);
  const r = await page.evaluate(() => {
    const text = document.body ? (document.body.innerText || '') : '';
    const hasRecruiterNav = /人才库|沟通中|个人储备|待处理投递/.test(text);
    const hasLoginWall = /扫码登录|密码登录|验证码登录|手机号登录|立即登录|登录\/注册/.test(text);
    return {
      loggedIn: hasRecruiterNav && !hasLoginWall,
      accountHint: null,
      url: location.href,
      hasRecruiterNav,
      hasLoginWall,
    };
  });
  return r;
}

// page-map 断言：运行前校验关键选择器仍在；缺失则提示重跑 explore
// 只断言 search 页关键选择器（talentCard）；drawer 选择器在 PAGE_MAP.drawer，点击后才用，此处不断言。
async function assertPageMap(page) {
  if (!PAGE_MAP || !PAGE_MAP.selectors) return; // 未 explore 过则跳过
  const critical = ['talentCard'];
  for (const key of critical) {
    const sel = PAGE_MAP.selectors[key];
    if (!sel) continue;
    let found = false;
    try { found = await page.evaluate((s) => !!document.querySelector(s), sel); } catch { found = false; }
    if (!found) throw new MmError('PAGE_MAP_DRIFT', `页面定位标记缺失：${key} = ${sel}。脉脉页面可能改版，请运行 explore 重新生成 page-map。`);
  }
}

// 导航到搜索页并等待结果渲染（SPA 异步加载，固定 sleep 不可靠；偶发不加载则刷新重试一次）
// 注：waitForFunction 签名是 (fn, argument, options)，options 是第三参，省略 argument 须显式传 undefined。
async function gotoSearch(page, query) {
  const waitCards = async (timeout) => {
    try {
      await page.waitForFunction(() => document.querySelectorAll('.talent-common-card').length > 0, undefined, { timeout, polling: 500 });
      return true;
    } catch { return false; }
  };
  await page.goto(MM.search(query));
  if (await waitCards(15000)) { await sleep(page, 400); return; }
  // 偶发 SPA 不触发搜索 XHR：整页刷新重试一次
  await page.reload();
  if (await waitCards(15000)) { await sleep(page, 400); return; }
  await sleep(page, 400); // 仍无卡片，交给 markAndReadRows 报 SELECTOR_MISSING
}

// 点击"下一页"翻页；成功返回 true 并等待渲染
// 翻到下一页：真实脉脉分页是编号页码（[class*=pagesItem]，当前页带 current 类），点「当前页+1」那个页码。
// 点击后等当前页标记真正切到下一页，避免读到旧页卡片。
async function gotoNextPage(page) {
  const clicked = await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('[class*="pagesItem"]'));
    const cur = items.find((el) => /current/.test(el.className));
    const curNum = cur ? parseInt((cur.innerText || '').trim(), 10) : NaN;
    if (isNaN(curNum)) return { ok: false };
    const next = items.find((el) => parseInt((el.innerText || '').trim(), 10) === curNum + 1);
    if (!next) return { ok: false }; // 没有下一页
    try { next.click(); } catch { return { ok: false }; }
    return { ok: true, to: curNum + 1 };
  });
  if (!clicked.ok) return false;
  try {
    await page.waitForFunction((n) => {
      const cur = document.querySelector('[class*="current"][class*="pagesItem"]');
      return cur && parseInt((cur.innerText || '').trim(), 10) === n;
    }, clicked.to, { timeout: 10000, polling: 300 });
  } catch { /* 页码未切换，交由后续读取报错 */ }
  await sleep(page, 400);
  return true;
}

// 给候选人卡片打 data-mm-row 标记，返回每卡文本行（按行数组）
// 真实脉脉招聘端：候选人卡片类名是 .talent-common-card（稳定，无 CSS-module hash），一页约 30 张。
async function markAndReadRows(page) {
  const rows = await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('.talent-common-card'));
    if (!items.length) return { error: 'no-list' };
    const out = [];
    items.forEach((el, i) => {
      const text = (el.innerText || '').trim();
      if (!text) return;
      el.setAttribute('data-mm-row', String(i));
      out.push({ i, lines: text.split('\n').map((s) => s.trim()).filter(Boolean) });
    });
    return { rows: out, total: out.length };
  });
  if (rows.error === 'no-list') throw new MmError('SELECTOR_MISSING', '未找到候选人卡片（.talent-common-card）。页面结构可能变了，请运行 explore。');
  return rows;
}

// 点击第 i 行打开详情抽屉
async function openDetail(page, i) {
  // ego 选择器支持裸 CSS；css:/css= 前缀均非此处所需。force:true 绕开抽屉/浮层遮挡。
  await page.click(`[data-mm-row="${i}"]`, { force: true, timeout: 5000 });
  await sleep(page, 1200);
  // 等待抽屉打开
  try { await page.waitForSelector('.ant-drawer-open', { timeout: 5000 }); } catch { /* 某些布局无抽屉 */ }
}

// 抓详情抽屉全文（含期望偏好/工作经历/教育经历/附件简历）
async function readDetailText(page) {
  const r = await page.evaluate(() => {
    const drawer = document.querySelector('.ant-drawer-open') || document.querySelector('.ant-drawer-content');
    if (!drawer) return { error: 'no-drawer' };
    // 尝试点"展开更多"抓全量
    const expanders = Array.from(drawer.querySelectorAll('*')).filter((e) => /展开更多|查看更多|全部/.test((e.innerText || '').trim()) && (e.innerText || '').trim().length <= 6);
    expanders.forEach((e) => { try { e.click(); } catch {} });
    const text = (drawer.innerText || '').trim();
    const hasPdf = /\.pdf/i.test(text);
    return { text, hasPdf };
  });
  if (r.error === 'no-drawer') throw new MmError('SELECTOR_MISSING', '未找到详情抽屉（.ant-drawer-open）。');
  return r;
}

// 关闭详情抽屉
// 脉脉抽屉没有 .ant-drawer-close 按钮，点 mask 也关不掉；实测 Escape 可靠。
async function closeDetail(page) {
  await page.press('body', 'Escape').catch(() => {});
  try { await page.waitForFunction(() => !document.querySelector('.ant-drawer-open'), undefined, { timeout: 3000 }); } catch { /* 兜底再睡 */ }
  await sleep(page, 400);
}

// ---------- 附件简历下载（--with-pdf） ----------
// 抽屉附件区结构（2026-09-24 实测）：「附件简历」标题 → 文件名 div[class*=resumeName] → 操作按钮 div[class*=resumeAction]（预览/下载/转发邮箱）。
// 注意：抽屉里另有「下载在线简历」按钮，必须限定在附件区容器内找「下载」，绝不在全局点。
// 附件格式不假定是 PDF：文件名带什么扩展名就存什么（实测样例为 .pdf，但上传方可能传图片/word）。
async function downloadAttachment(page, saveDir) {
  const info = await page.evaluate(() => {
    const drawer = document.querySelector('.ant-drawer-open') || document.querySelector('.ant-drawer-content');
    if (!drawer) return { error: 'no-drawer' };
    const own = (e) => Array.from(e.childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join('').trim();
    const title = Array.from(drawer.querySelectorAll('span,div')).find((e) => own(e) === '附件简历');
    if (!title) return { error: 'no-attachment-section' };
    let box = title.parentElement;
    for (let i = 0; i < 5 && box; i++) {
      if (box.querySelector('[class*="resumeName"]') && Array.from(box.querySelectorAll('div,span,button')).some((e) => own(e) === '下载')) break;
      box = box.parentElement;
    }
    if (!box) return { error: 'no-attachment-box' };
    const nameEl = box.querySelector('[class*="resumeName"]');
    const fileName = nameEl ? (nameEl.innerText || '').trim() : '';
    document.querySelectorAll('[data-mm-dl]').forEach((e) => e.removeAttribute('data-mm-dl'));
    const dl = Array.from(box.querySelectorAll('div,span,button')).find((e) => own(e) === '下载');
    if (!dl) return { error: 'no-download-btn', fileName };
    dl.setAttribute('data-mm-dl', '1');
    return { fileName };
  });
  if (info.error) return { ok: false, reason: info.error };
  // 先 arm 下载事件再点（ego API：waitForEvent("download") 必须在触发动作前挂上）
  const dlPromise = page.waitForEvent('download', { timeout: 15000 });
  await page.click('[data-mm-dl="1"]', { timeout: 5000 });
  const download = await dlPromise.catch(() => null);
  if (!download) return { ok: false, reason: 'download-event-timeout', fileName: info.fileName };
  const suggested = (download.suggestedFilename ? download.suggestedFilename() : '') || info.fileName || 'attachment';
  const safe = suggested.replace(/[\/\\:*?"<>|]+/g, '_').slice(0, 120);
  const abs = saveDir.replace(/\/+$/, '') + '/' + safe;
  await download.saveAs(abs);
  const failReason = download.failure ? await download.failure() : null;
  return { ok: !failReason, reason: failReason || null, file: abs, suggested };
}

// 判断是否触发风控（验证码/异常空结果）
async function detectRisk(page) {
  return await page.evaluate(() => {
    const t = document.body ? (document.body.innerText || '') : '';
    const hasCaptcha = /验证码|安全验证|滑块|拖动/.test(t);
    return { hasCaptcha };
  });
}

// ---------- 页面筛选（UI 点击路线） ----------
// 实测（2026-09-24）：筛选条件不进 URL，是纯前端状态；搜索接口是 POST 且路径带 anti_automation。
// 所以筛选只能模拟真人点击，分两类：
//   面板筛选：点 .search-item-text 精确 label → 弹层点选项 → 多选/自定义点「确定」→ Escape 关弹层
//   结果 chip：「从结果中筛选」区的开关（公开求职意向/有附件简历等），已激活则跳过避免误关
// 实测要点：
//   - 选项（.list-item/.option）对合成 el.click() 不 reliably 生效，必须用 ego page.click 真实鼠标事件
//   - 筛选标题是开关：点之前不知道弹层当前开没开，必须以「选项是否可见」为准，不可盲点
//   - 标题应用筛选后文案会变成「标签：值」，所以标题匹配用 startsWith 不能用精确匹配
//   - 部分选项带子弹层（如 本科及以上 → 不限/只看统招本科），必须再选子项才真正应用
//   - 应用后必须验证筛选栏出现「标签：值」，没生效要诚实报错，绝不静默带错结果
const FILTER_PANEL = {
  city: '城市地区', degree: '学历要求', workyears: '工作年限', gender: '性别',
  company: '就职公司', jobtitle: '职位名称', industry: '行业方向',
  school: '毕业学校', hometown: '家乡', aiTalent: 'AI人才类型',
};
const FILTER_CHIPS = {
  intent: '公开求职意向', active: '近期有动向', hasPdf: '有附件简历',
  hadIntent: '有过意向', enterprise: '企业号互动',
  notViewed: '近期未查看', notContacted: '近期未沟通',
  hasNote: '有备注', noNote: '无备注', followed: '已跟进', notFollowed: '未跟进',
};
// 区间筛选：值形如 "30-40"、"-40"、"30-"。两个 ant-select 下拉（最低X/最高X）+ 确定。
const FILTER_RANGE = {
  age: { label: '年龄', min: '最低年龄', max: '最高年龄' },
  salary: { label: '期望月薪', min: '最低月薪', max: '最高月薪' },
};
// 文本输入筛选：值直接进输入框（React 受控组件走 native setter + input 事件 + Enter）
const FILTER_TEXT = {
  major: { label: '专业', placeholder: '请输入专业' },
};
// 其余特殊筛选：
//   cityMode   "期望"/"现居"   → city 弹层内的切换，配合 city 用（默认现居）
//   companyTab "正任职"/"曾任职" → company 弹层内的 Tab，配合 company 用（默认正任职）
//   friend     "是"/"否"      → 好友关系区 checkbox，必须限定在「好友关系」容器内点
//   sort       综合排序/活跃优先/匹配度优先 → 结果工具栏内联 tab
//   match      所有/任一      → 「满足[所有]关键词」下拉
//   smartFilter true        → 智能筛选开关（已开则跳过）

// 弹层里是否可见指定文本的选项（list-item 用于学历/年限等，option 用于城市级联，text___ 用于行业方向）
async function isFilterOptionVisible(page, text, sel) {
  return await page.evaluate(({ t, s }) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    return Array.from(document.querySelectorAll(s))
      .some((e) => visible(e) && (e.innerText || '').trim() === t);
  }, { t: text, s: sel || '[class*="list-item"],[class*="option"]' });
}

// 点当前可见的「确定」（多选面板/自定义区间用）；找不到返回 false（可能弹层已自行关闭）
async function clickVisibleConfirm(page) {
  const has = await page.evaluate(() => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-confirm]').forEach((e) => e.removeAttribute('data-mm-confirm'));
    const btn = Array.from(document.querySelectorAll('div,span,button')).find((el) =>
      visible(el) &&
      !Array.from(el.children).some((c) => (c.innerText || '').trim()) &&
      /^(确 定|确定)$/.test((el.innerText || '').trim()));
    if (btn) { btn.setAttribute('data-mm-confirm', '1'); return true; }
    return false;
  });
  if (has) {
    await page.click('[data-mm-confirm="1"]', { timeout: 3000 }).catch(() => {});
    await sleep(page, 600);
  }
  return has;
}

async function applyPanelFilter(page, key, value) {
  const label = FILTER_PANEL[key];
  const values = Array.isArray(value) ? value.map(String) : [String(value)]; // industry 支持多选（≤10）
  // 各面板的选项选择器不同：行业方向选项是 text___ 类，不在通用 list-item/option 里
  const optSel = key === 'industry' ? '[class*="text___"]' : '[class*="list-item"],[class*="option"]';
  // 0) 先 Escape 清掉上一个筛选可能残留的弹层，避免叠加态下标题点击失效
  await page.press('body', 'Escape').catch(() => {});
  await sleep(page, 400);
  // 1) 确保弹层打开（标题是开关，以选项可见性为准，最多点两次标题；标题可能是「学历要求」或「学历要求：本科及以上」）
  let open = await isFilterOptionVisible(page, values[0], optSel);
  for (let i = 0; i < 2 && !open; i++) {
    await page.evaluate((lb) => {
      const el = Array.from(document.querySelectorAll('.search-item-text')).find((e) => (e.innerText || '').trim().startsWith(lb));
      if (el) el.click();
    }, label);
    await sleep(page, 1000);
    open = await isFilterOptionVisible(page, values[0], optSel);
  }
  if (!open) throw new MmError('SELECTOR_MISSING', `筛选「${label}」的弹层打不开，或选项不存在：${values.join('、')}。可选值见 references/filters.md。`);
  // 1.5) 修饰键：city 弹层的 期望/现居、company 弹层的 正任职/曾任职——实测都是 checkbox（默认都勾=不限）。
  //      按目标态逐个对齐：该勾的勾上、该去的去掉，不盲目点（实测盲点点掉的是勾选方）。
  const MODIFIERS = {
    city: { options: ['期望', '现居'] },
    company: { options: ['正任职', '曾任职'] },
  };
  const modifier = key === 'city' ? (ARGS.filters && ARGS.filters.cityMode) : key === 'company' ? (ARGS.filters && ARGS.filters.companyTab) : null;
  if (modifier) {
    const modConf = MODIFIERS[key];
    if (!modConf.options.includes(String(modifier))) throw new MmError('USAGE', `「${key === 'city' ? 'cityMode' : 'companyTab'}」只支持：${modConf.options.join(' / ')}`);
    for (const opt of modConf.options) {
      const want = opt === String(modifier);
      const st = await page.evaluate(({ opt: o, want: w }) => {
        const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
        document.querySelectorAll('[data-mm-mod]').forEach((e) => e.removeAttribute('data-mm-mod'));
        const els = Array.from(document.querySelectorAll('div,span,li,label')).filter((e) =>
          visible(e) &&
          !Array.from(e.children).some((c) => (c.innerText || '').trim()) &&
          (e.innerText || '').trim() === o);
        if (!els.length) return 'missing';
        const wrap = els[els.length - 1].closest('.ant-checkbox-wrapper') || els[els.length - 1];
        const active = /checked|active|selected/i.test(String(wrap.className || ''));
        if (active === w) return 'ok';
        wrap.setAttribute('data-mm-mod', '1');
        return 'click';
      }, { opt, want });
      if (st === 'missing') throw new MmError('SELECTOR_MISSING', `筛选「${label}」弹层里找不到「${opt}」切换项`);
      if (st === 'click') {
        await page.click('[data-mm-mod="1"]', { timeout: 4000 });
        await sleep(page, 600);
      }
    }
  }
  // 2) 逐个标记选项 + ego 真实鼠标点击（合成 el.click() 对选项不 reliably 生效，实测）。
  //    点最后一个匹配：城市级联里底部热门城市可直接选（省名那个只展开不选中）。
  for (const v of values) {
    const marked = await page.evaluate(({ t, s }) => {
      const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      document.querySelectorAll('[data-mm-opt]').forEach((e) => e.removeAttribute('data-mm-opt')); // 清残留标记
      const els = Array.from(document.querySelectorAll(s))
        .filter((e) => visible(e) && (e.innerText || '').trim() === t);
      if (!els.length) return false;
      els[els.length - 1].setAttribute('data-mm-opt', '1');
      return true;
    }, { t: v, s: optSel });
    if (!marked) throw new MmError('SELECTOR_MISSING', `筛选「${label}」选项消失：${v}`);
    await page.click('[data-mm-opt="1"]', { timeout: 5000 });
    await sleep(page, 800);
  }
  // 2.5) 部分选项带子弹层（实测：本科及以上 → 不限/只看统招本科），不选子项不会真正应用。
  //      默认选「不限」；子层选择可用 filters 的 <key>Sub 指定（如 degreeSub:"只看统招本科"）。
  if (values.length === 1) {
    const subPicked = await page.evaluate((subText) => {
      const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      document.querySelectorAll('[data-mm-sub]').forEach((e) => e.removeAttribute('data-mm-sub'));
      const items = Array.from(document.querySelectorAll('[class*="sub-select-item"]')).filter((e) => visible(e));
      if (!items.length) return 'none';
      const target = items.find((e) => (e.innerText || '').trim() === subText) || items[0];
      target.setAttribute('data-mm-sub', '1');
      return 'picked';
    }, String(ARGS.filters && ARGS.filters[key + 'Sub'] || '不限'));
    if (subPicked === 'picked') {
      await page.click('[data-mm-sub="1"]', { timeout: 4000 }).catch(() => {});
      await sleep(page, 800);
    }
  }
  // 3) 多选/自定义类弹层点完选项不关闭，需点可见的「确定」；单选已关闭时这步跳过
  if (await isFilterOptionVisible(page, values[0], optSel)) await clickVisibleConfirm(page);
  await page.press('body', 'Escape').catch(() => {});
  await sleep(page, 300);
  // 4) 验证真正生效：筛选栏必须出现「标签：值」。不生效就诚实报错，绝不静默带错结果。
  const tags = await readFilterTags(page);
  if (!tags.some((t) => t.indexOf(label + '：') === 0)) {
    throw new MmError('FILTER_NOT_APPLIED', `筛选「${label}=${values.join('、')}」点击后未生效（当前生效：${tags.join('、') || '无'}）。页面行为可能变了，请运行 explore 并检查 references/filters.md。`);
  }
}

async function applyResultChip(page, key) {
  const label = FILTER_CHIPS[key];
  const state = await page.evaluate((t) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-chip]').forEach((e) => e.removeAttribute('data-mm-chip')); // 清掉上一个 chip 的标记
    const els = Array.from(document.querySelectorAll('div,span,li,button,a')).filter((el) =>
      visible(el) &&
      !Array.from(el.children).some((c) => (c.innerText || '').trim()) &&
      (el.innerText || '').trim() === t);
    if (!els.length) return { found: false };
    const el = els[0];
    const cls = String(el.className || '') + ' ' + String(el.parentElement ? el.parentElement.className : '');
    const active = /active|selected|checked/i.test(cls);
    if (!active) el.setAttribute('data-mm-chip', '1');
    return { found: true, active };
  }, label);
  if (!state.found) throw new MmError('SELECTOR_MISSING', `页面上找不到结果筛选：${label}。页面可能改版，请运行 explore。`);
  if (!state.active) {
    // 点击可能被加载遮罩拦截（筛选触发重新搜索时），等列表渲染稳定后重试
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await page.waitForFunction(() => document.querySelectorAll('.talent-common-card').length > 0, undefined, { timeout: 8000, polling: 500 });
      } catch { /* 继续尝试点击 */ }
      await sleep(page, 600);
      try {
        await page.click('[data-mm-chip="1"]', { timeout: 4000 });
        break;
      } catch (e) {
        if (attempt === 2) throw new MmError('SELECTOR_MISSING', `结果筛选「${label}」点击被页面拦截：${e.message}`);
        await sleep(page, 1200);
      }
    }
    await sleep(page, 800);
  }
  return state.active ? 'already-active' : 'clicked';
}

// ---------- 区间筛选（年龄/期望月薪）：两个 ant-select 下拉 + 确定 ----------
async function setRangeBound(page, conf, boundLabel, num) {
  // 点对应下拉的触发器，等选项浮层出来，再点精确文本选项
  const marked = await page.evaluate((bl) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-sel]').forEach((e) => e.removeAttribute('data-mm-sel'));
    const wraps = Array.from(document.querySelectorAll('[class*="select-wrapper"]'))
      .filter((e) => visible(e) && (e.innerText || '').includes(bl));
    if (!wraps.length) return false;
    const trigger = wraps[0].querySelector('[class*="ant-select-selector"],[class*="ant-select"],[class*="select-selector"]') || wraps[0];
    trigger.setAttribute('data-mm-sel', '1');
    return true;
  }, boundLabel);
  if (!marked) throw new MmError('SELECTOR_MISSING', `「${conf.label}」弹层里找不到「${boundLabel}」下拉`);
  await page.click('[data-mm-sel="1"]', { timeout: 5000 });
  await sleep(page, 800);
  // 选项浮层是虚拟滚动列表（实测年龄下拉只渲染前 ~15 项），要边滚边找
  const findOption = (n) => page.evaluate((nn) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-opt]').forEach((e) => e.removeAttribute('data-mm-opt'));
    const want = parseInt(nn, 10);
    const match = (t) => (Number.isNaN(want) ? t === nn : parseInt(t, 10) === want);
    const els = Array.from(document.querySelectorAll('[class*="ant-select-item"],[class*="select-item"],[class*="option"],[class*="list-item"]'))
      .filter((e) => visible(e) && match((e.innerText || '').trim()));
    if (!els.length) return false;
    els[els.length - 1].setAttribute('data-mm-opt', '1');
    return true;
  }, String(num));
  let found = await findOption(num);
  for (let i = 0; i < 15 && !found; i++) {
    await page.evaluate(() => {
      const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      // 必须挑「真实可滚」的容器：外层 rc-virtual-list 滚了不生效，要滚内层 holder
      const holders = Array.from(document.querySelectorAll('[class*="virtual-list"],[class*="item-list"],[class*="dropdown"] ul,[class*="dropdown"] [class*="holder"]'))
        .filter((e) => visible(e) && e.scrollHeight > e.clientHeight + 10 && e.clientHeight > 40);
      const h = holders[0];
      if (h) { h.scrollTop = (h.scrollTop || 0) + 240; h.dispatchEvent(new Event('scroll', { bubbles: true })); }
    });
    await sleep(page, 400);
    found = await findOption(num);
  }
  if (!found) {
    const seen = await page.evaluate(() => {
      const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      return Array.from(document.querySelectorAll('[class*="ant-select-item"],[class*="select-item"],[class*="option"]'))
        .filter((e) => visible(e)).map((e) => (e.innerText || '').trim()).filter(Boolean).slice(0, 30);
    });
    throw new MmError('USAGE', `「${boundLabel}」没有选项「${num}」。页面上可见的选项：${seen.join('、') || '（没抓到）'}`);
  }
  await page.click('[data-mm-opt="1"]', { timeout: 5000 });
  await sleep(page, 600);
}

async function applyRangeFilter(page, key, value) {
  const conf = FILTER_RANGE[key];
  const m = String(value).match(/^\s*(\d*)\s*[-~—到]\s*(\d*)\s*$/);
  if (!m || (!m[1] && !m[2])) throw new MmError('USAGE', `筛选「${conf.label}」的值必须是区间，如 "30-40"、"-40"、"30-"`);
  // 开弹层：以「最低X」文本可见为准（标题是开关，同面板筛选）
  const boundVisible = (t) => page.evaluate((txt) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    return Array.from(document.querySelectorAll('div,span')).some((e) => visible(e) && (e.innerText || '').trim() === txt);
  }, t);
  let open = await boundVisible(conf.min);
  for (let i = 0; i < 2 && !open; i++) {
    await page.evaluate((lb) => {
      const el = Array.from(document.querySelectorAll('.search-item-text')).find((e) => (e.innerText || '').trim().startsWith(lb));
      if (el) el.click();
    }, conf.label);
    await sleep(page, 800);
    open = await boundVisible(conf.min);
  }
  if (!open) throw new MmError('SELECTOR_MISSING', `筛选「${conf.label}」的弹层打不开`);
  if (m[1]) await setRangeBound(page, conf, conf.min, m[1]);
  if (m[2]) await setRangeBound(page, conf, conf.max, m[2]);
  await clickVisibleConfirm(page);
  await page.press('body', 'Escape').catch(() => {});
  // 验证：筛选栏出现「标签：…」（区间标签具体格式页面自定，宽松匹配前缀）
  const tags = await readFilterTags(page);
  if (!tags.some((t) => t.indexOf(conf.label) === 0)) {
    throw new MmError('FILTER_NOT_APPLIED', `筛选「${conf.label}=${value}」点击后未生效（当前生效：${tags.join('、') || '无'}）`);
  }
}

// ---------- 文本输入筛选（专业：搜索联想式，必须点联想项，Enter/自由文本不生效，实测） ----------
async function applyTextFilter(page, key, value) {
  const conf = FILTER_TEXT[key];
  const inputVisible = () => page.evaluate((ph) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    return Array.from(document.querySelectorAll('input')).some((e) => visible(e) && (e.placeholder || '').includes(ph));
  }, conf.placeholder);
  let open = await inputVisible();
  for (let i = 0; i < 2 && !open; i++) {
    await page.evaluate((lb) => {
      const el = Array.from(document.querySelectorAll('.search-item-text')).find((e) => (e.innerText || '').trim().startsWith(lb));
      if (el) el.click();
    }, conf.label);
    await sleep(page, 800);
    open = await inputVisible();
  }
  if (!open) throw new MmError('SELECTOR_MISSING', `筛选「${conf.label}」的弹层打不开`);
  // React 受控输入：native setter + input 事件触发联想搜索
  const filled = await page.evaluate(({ ph, v }) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-text]').forEach((e) => e.removeAttribute('data-mm-text'));
    const input = Array.from(document.querySelectorAll('input')).find((e) => visible(e) && (e.placeholder || '').includes(ph));
    if (!input) return false;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(input, v);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.setAttribute('data-mm-text', '1');
    return true;
  }, { ph: conf.placeholder, v: String(value) });
  if (!filled) throw new MmError('SELECTOR_MISSING', `「${conf.label}」输入框找不到`);
  await sleep(page, 2000); // 联想是远端搜索，要等返回
  // 点联想项：优先精确匹配，其次包含，最后第一个（实测：不点联想项筛选项永远不生效）
  const sugPicked = await page.evaluate((v) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-sug]').forEach((e) => e.removeAttribute('data-mm-sug'));
    const input = document.querySelector('[data-mm-text="1"]');
    if (!input) return false;
    // 联想项在弹层容器里（实测 class 形如 container___xxx）；input 的最近祖先
    // ant-input-affix-wrapper 也含 "wrapper" 字样，不能拿它当容器
    const wrap = input.closest('[class*="container___"]') || input.closest('[class*="wrapper___"]');
    if (!wrap) return false;
    // 联想项 class 形如 content___xxx；注意它的文字是逐字高亮 span（一个字一个子节点），
    // 按叶子文本匹配会拆成单字，必须拿 content___ 元素本身
    const items = Array.from(wrap.querySelectorAll('[class*="content___"]')).filter((e) =>
      visible(e) && (e.innerText || '').trim());
    if (!items.length) return false;
    const exact = items.find((e) => (e.innerText || '').trim() === v);
    const target = exact || items.find((e) => (e.innerText || '').trim().includes(v)) || items[0];
    target.setAttribute('data-mm-sug', '1');
    return true;
  }, String(value));
  if (!sugPicked) throw new MmError('SELECTOR_MISSING', `「${conf.label}」输入「${value}」后没有联想项返回。换个关键词试试。`);
  await page.click('[data-mm-sug="1"]', { timeout: 5000 });
  await sleep(page, 1000);
  await page.press('body', 'Escape').catch(() => {});
  const tags = await readFilterTags(page);
  if (!tags.some((t) => t.indexOf(conf.label) === 0)) {
    throw new MmError('FILTER_NOT_APPLIED', `筛选「${conf.label}=${value}」未生效（当前生效：${tags.join('、') || '无'}）`);
  }
}

// ---------- 好友关系（是/否 checkbox，必须限定在「好友关系」容器内点） ----------
async function applyFriendFilter(page, value) {
  const v = String(value);
  if (v !== '是' && v !== '否') throw new MmError('USAGE', '筛选「好友关系」的值只能是 "是" 或 "否"');
  // 文案「是/否」太通用，绝不能在全局点：从「好友关系」标题向上找含 ant-checkbox-group 的容器
  const locate = (val) => page.evaluate((vv) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    const heads = Array.from(document.querySelectorAll('p,div,span')).filter((e) =>
      visible(e) && !Array.from(e.children).some((c) => (c.innerText || '').trim()) && (e.innerText || '').trim() === '好友关系');
    if (!heads.length) return { code: 'no-header' };
    let c = heads[0];
    for (let i = 0; i < 6 && c.parentElement; i++) {
      if (c.querySelector && c.querySelector('.ant-checkbox-group')) break;
      c = c.parentElement;
    }
    const group = c.querySelector ? c.querySelector('.ant-checkbox-group') : null;
    if (!group) return { code: 'no-group' };
    const label = Array.from(group.querySelectorAll('label')).find((l) => (l.innerText || '').trim() === vv);
    if (!label) return { code: 'no-label' };
    const checked = /checked/.test(String(label.className)) || !!label.querySelector('.ant-checkbox-checked');
    if (!checked) label.setAttribute('data-mm-friend', '1');
    return { code: checked ? 'already' : 'marked' };
  }, val);
  const r = await locate(v);
  if (r.code === 'no-header') throw new MmError('SELECTOR_MISSING', '页面上找不到「好友关系」筛选区。页面可能改版，请运行 explore。');
  if (r.code === 'no-group' || r.code === 'no-label') throw new MmError('SELECTOR_MISSING', `「好友关系」里找不到选项「${v}」。页面结构可能变了，请运行 explore。`);
  if (r.code === 'marked') {
    await page.click('[data-mm-friend="1"]', { timeout: 5000 });
    await sleep(page, 800);
    const after = await locate(v);
    if (after.code !== 'already') throw new MmError('FILTER_NOT_APPLIED', `「好友关系=${v}」点击后未勾选`);
  }
}

// ---------- 排序（结果工具栏内联 tab：综合排序/活跃优先/匹配度优先） ----------
async function applySort(page, value) {
  const v = String(value);
  const detect = (val) => page.evaluate((vv) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-sort]').forEach((e) => e.removeAttribute('data-mm-sort'));
    const els = Array.from(document.querySelectorAll('div,span')).filter((e) =>
      visible(e) &&
      !Array.from(e.children).some((c) => (c.innerText || '').trim()) &&
      (e.innerText || '').trim() === vv);
    if (!els.length) return { code: 'not-found' };
    const el = els[0];
    // 激活高亮（bg-[#E5EEFF]）在祖父节点上，实测要往上查 3 层
    let active = false;
    let c = el;
    for (let i = 0; i < 3 && c; i++) {
      if (/E5EEFF|active|selected/i.test(String(c.className || ''))) { active = true; break; }
      c = c.parentElement;
    }
    if (!active) el.setAttribute('data-mm-sort', '1');
    return { code: active ? 'already' : 'marked' };
  }, val);
  let r = await detect(v);
  if (r.code === 'not-found') throw new MmError('USAGE', '筛选「sort」只支持：综合排序 / 活跃优先 / 匹配度优先');
  // 列表重渲染中点击可能落在旧坐标上，重试最多 3 次
  for (let attempt = 0; attempt < 3 && r.code === 'marked'; attempt++) {
    await page.click('[data-mm-sort="1"]', { timeout: 5000 });
    await sleep(page, 1500);
    r = await detect(v);
  }
  if (r.code === 'marked') throw new MmError('FILTER_NOT_APPLIED', `排序「${v}」点击后未生效`);
}

// ---------- 关键词匹配模式（「满足[所有]关键词」下拉） ----------
async function applyMatchMode(page, value) {
  const v = String(value);
  if (v !== '所有' && v !== '任一') throw new MmError('USAGE', '筛选「match」的值只能是 "所有" 或 "任一"');
  const opened = await page.evaluate(() => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-match]').forEach((e) => e.removeAttribute('data-mm-match'));
    // 结构是「满足 [下拉: 所有] 关键词」三段：下拉自身文本只有「所有」，不能按整句匹配
    const sels = Array.from(document.querySelectorAll('[class*="selectContent"] [class*="mui-select"]'))
      .filter((e) => visible(e));
    if (!sels.length) return false;
    sels[0].setAttribute('data-mm-match', '1');
    return true;
  });
  if (!opened) throw new MmError('SELECTOR_MISSING', '页面上找不到「满足所有/任一关键词」下拉。页面可能改版，请运行 explore。');
  await page.click('[data-mm-match="1"]', { timeout: 5000 });
  await sleep(page, 700);
  const picked = await page.evaluate((val) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-opt]').forEach((e) => e.removeAttribute('data-mm-opt'));
    const els = Array.from(document.querySelectorAll('[class*="option"],[class*="item"],li,div,span')).filter((e) =>
      visible(e) &&
      !Array.from(e.children).some((c) => (c.innerText || '').trim()) &&
      (e.innerText || '').trim() === val);
    if (!els.length) return false;
    els[els.length - 1].setAttribute('data-mm-opt', '1');
    return true;
  }, v);
  if (!picked) throw new MmError('SELECTOR_MISSING', `「满足所有/任一关键词」下拉里找不到选项「${v}」`);
  await page.click('[data-mm-opt="1"]', { timeout: 5000 });
  await sleep(page, 800);
  const ok = await page.evaluate((val) => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    // 下拉自身文本就是当前值（「所有」或「任一」）；整句「满足X关键词」是三段拼的
    return Array.from(document.querySelectorAll('[class*="selectContent"] [class*="mui-select"],[class*="mui-select"]'))
      .some((e) => visible(e) && (e.innerText || '').trim() === val);
  }, v);
  if (!ok) throw new MmError('FILTER_NOT_APPLIED', `「满足${v}关键词」点击后未生效`);
}

// ---------- 智能筛选（结果区开关，已开则跳过） ----------
async function applySmartFilter(page) {
  const r = await page.evaluate(() => {
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    document.querySelectorAll('[data-mm-smart]').forEach((e) => e.removeAttribute('data-mm-smart'));
    const heads = Array.from(document.querySelectorAll('div,span,p')).filter((e) =>
      visible(e) && !Array.from(e.children).some((c) => (c.innerText || '').trim()) && (e.innerText || '').trim() === '智能筛选');
    if (!heads.length) return { code: 'no-header' };
    let c = heads[0];
    for (let i = 0; i < 6 && c.parentElement; i++) {
      if (c.querySelector && (c.querySelector('.ant-checkbox-wrapper') || c.querySelector('[class*="switch"]'))) break;
      c = c.parentElement;
    }
    const toggle = c.querySelector ? (c.querySelector('.ant-checkbox-wrapper') || c.querySelector('[class*="switch"]')) : null;
    if (!toggle) return { code: 'no-toggle' };
    const active = /checked|active|ant-switch-checked/i.test(String(toggle.className)) || !!toggle.querySelector('.ant-checkbox-checked');
    if (!active) toggle.setAttribute('data-mm-smart', '1');
    return { code: active ? 'already' : 'marked' };
  });
  if (r.code === 'no-header') throw new MmError('SELECTOR_MISSING', '页面上找不到「智能筛选」。页面可能改版，请运行 explore。');
  if (r.code === 'no-toggle') throw new MmError('SELECTOR_MISSING', '「智能筛选」里找不到开关（checkbox/switch）。页面结构可能变了，请运行 explore。');
  if (r.code === 'marked') {
    await page.click('[data-mm-smart="1"]', { timeout: 5000 });
    await sleep(page, 1000);
  }
}

// 应用一组筛选（filters 为 {key: value} 对象；chip 的 value 传 true，false/null 跳过）
// 返回实际应用的 key 列表；最后等列表重新渲染（筛选会触发重新搜索）
async function applyFilters(page, filters) {
  const applied = [];
  for (const [key, value] of Object.entries(filters)) {
    if (value === false || value === null || value === undefined || value === '') continue;
    // <key>Sub / cityMode / companyTab 是修饰键，由对应面板筛选内部消费，不单独应用
    if (/Sub$/.test(key) || key === 'cityMode' || key === 'companyTab') continue;
    if (FILTER_PANEL[key]) await applyPanelFilter(page, key, value);
    else if (FILTER_CHIPS[key]) await applyResultChip(page, key);
    else if (FILTER_RANGE[key]) await applyRangeFilter(page, key, value);
    else if (FILTER_TEXT[key]) await applyTextFilter(page, key, value);
    else if (key === 'friend') await applyFriendFilter(page, value);
    else if (key === 'sort') await applySort(page, value);
    else if (key === 'match') await applyMatchMode(page, value);
    else if (key === 'smartFilter') await applySmartFilter(page);
    else throw new MmError('USAGE', `未知筛选 key：${key}。面板筛选：${Object.keys(FILTER_PANEL).join('/')}；区间：${Object.keys(FILTER_RANGE).join('/')}；文本：${Object.keys(FILTER_TEXT).join('/')}；结果筛选：${Object.keys(FILTER_CHIPS).join('/')}；特殊：friend/sort/match/smartFilter/cityMode/companyTab。详见 references/filters.md。`);
    applied.push(key);
  }
  if (applied.length) {
    try { await page.waitForFunction(() => document.querySelectorAll('.talent-common-card').length > 0, undefined, { timeout: 10000, polling: 500 }); } catch { /* 交给 markAndReadRows 报错 */ }
    await sleep(page, 500);
  }
  return applied;
}

// 读筛选栏已生效的标签（已选项显示为「工作年限：5-10年」），作为筛选真正生效的证据
async function readFilterTags(page) {
  return await page.evaluate(() => {
    const items = Array.from(document.querySelectorAll('.search-item-text'));
    return items.map((e) => (e.innerText || '').trim()).filter((t) => /：/.test(t));
  });
}
