// login.mjs — 人在环登录：建/复用 space，未登录则 handOff 给用户
// 用法：mm login         首次/检查：建或复用 space，未登录则弹出引导
//       mm login --resume  用户登录后收回控制权并验证
// 依赖 lib.mjs 注入：ARGS, CTX, PAGE_MAP

async function main() {
  if (ARGS.resume) {
    // 用户已登录，收回控制权并验证
    if (CTX.spaceId == null) throw new MmError('SPACE_LOST', 'state 里没有 spaceId，请先运行 mm login（不带 --resume）。');
    let task;
    try { task = await takeOverTaskSpace(CTX.spaceId); }
    catch (e) { throw new MmError('SPACE_LOST', '收回控制权失败，space 可能已失效。请重新运行 mm login。' + (e && e.message ? '：' + e.message : '')); }
    const page = getPage(task);
    const login = await detectLogin(page);
    if (!login.loggedIn) {
      emit(false, 'NOT_LOGGED_IN', { spaceId: CTX.spaceId }, '还没检测到登录态。请在弹出的 ego 窗口里完成脉脉登录后，再运行 mm login --resume。');
      return;
    }
    emit(true, 'LOGGED_IN', {
      spaceId: CTX.spaceId,
      accountHint: login.accountHint,
      __statePatch: { space: { id: CTX.spaceId, pageLabel: CTX.pageLabel }, login: { status: 'ok', checkedAt: new Date().toISOString(), accountHint: login.accountHint } },
    }, '登录成功：' + (login.accountHint || '已登录'));
    return;
  }

  // 首次或检查：建或复用 space。已记录的 space 失效（被关闭/ego 重启）就新建，别直接死。
  let task;
  if (CTX.spaceId != null) {
    try { task = await getTask(); }
    catch { task = await taskSpace('maimai-recruit'); }
  } else {
    task = await taskSpace('maimai-recruit');
  }
  const page = getPage(task);
  const login = await detectLogin(page);

  if (login.loggedIn) {
    emit(true, 'LOGGED_IN', {
      spaceId: task.spaceId,
      accountHint: login.accountHint,
      __statePatch: { space: { id: task.spaceId, pageLabel: 'p1' }, login: { status: 'ok', checkedAt: new Date().toISOString(), accountHint: login.accountHint } },
    }, '已登录：' + (login.accountHint || ''));
    return;
  }

  // 未登录：把控制权交给用户，输出引导
  await task.handOff();
  emit(true, 'NEEDS_LOGIN', {
    spaceId: task.spaceId,
    __statePatch: { space: { id: task.spaceId, pageLabel: 'p1' }, login: { status: 'needed', checkedAt: new Date().toISOString() } },
  }, '请在弹出的 ego-lite 窗口里手动登录脉脉（扫码/密码/验证码都由你本人操作）。登录完成后回复"好了"，我会运行 mm login --resume 收回控制权并继续。');
}

main().catch((e) => emit(false, e.code || 'INTERNAL', e.data || null, e.hint || e.message));
