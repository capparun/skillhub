// search.mjs — 关键词搜索 + 翻页采集候选人列表
// 用法：mm search --query "数据采集 负责人" [--pages 2]
// 说明：MVP 搜索阶段只做关键词粗筛（缩池）；硬性条件（年限/学历/城市）由 export 阶段对照实际字段复核。
// 依赖 lib.mjs 注入：ARGS, CTX, PAGE_MAP
// 返回：信封 data {query, pages, rows:[{lines:[...]}], risk}

async function grabPageRows(page) {
  return await markAndReadRows(page);
}

async function main() {
  const query = ARGS.query;
  if (!query) throw new MmError('USAGE', '缺少 --query 参数。示例：mm search --query "数据采集 负责人" --pages 2');
  const maxPages = parseInt(ARGS.pages, 10) || 1;

  const task = await getTask();
  const page = getPage(task);

  await gotoSearch(page, query);
  // 断言必须在 gotoSearch 之后：页面当前可能在任意位置（dashboard/详情页），
  // 先断言会对搜索页专属的 talentCard 误报 PAGE_MAP_DRIFT。
  // 筛选（UI 点击）也在断言前应用：筛选会触发列表重新渲染，之后断言的才是最终列表页。
  let appliedFilters = [];
  if (ARGS.filters && Object.keys(ARGS.filters).length) {
    appliedFilters = await applyFilters(page, ARGS.filters);
  }
  await assertPageMap(page);

  const rows = [];
  let risk = null;
  let pageSize = 0;
  for (let p = 1; p <= maxPages; p++) {
    const riskCheck = await detectRisk(page);
    if (riskCheck.hasCaptcha) { risk = 'captcha'; break; }
    const pageRows = await grabPageRows(page);
    if (!pageRows.rows || pageRows.rows.length === 0) break;
    if (p === 1) pageSize = pageRows.total; // 第一页行数作为 pageSize（供 harvest 跨页定位）
    for (const r of pageRows.rows) rows.push({ lines: r.lines });
    if (p >= maxPages) break;
    const hasNext = await gotoNextPage(page);
    if (!hasNext) break;
  }

  emit(true, 'OK', { query, pages: maxPages, rowCount: rows.length, pageSize, rows, risk, appliedFilters, filterTags: await readFilterTags(page) },
    risk === 'captcha'
      ? ('疑似触发风控（验证码），已安全拿到 ' + rows.length + ' 人，建议稍后再继续。')
      : ('搜索「' + query + '」完成，采集 ' + rows.length + ' 人到列表（每页约 ' + pageSize + ' 人）。'));
}

main().catch((e) => emit(false, e.code || 'INTERNAL', e.data || null, e.hint || e.message));
