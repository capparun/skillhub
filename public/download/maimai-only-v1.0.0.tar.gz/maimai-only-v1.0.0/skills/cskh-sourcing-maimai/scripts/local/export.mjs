// export.mjs — 本地后处理：解析 list+detail → 去重 → 岗位匹配度 → 增量 → CSV/JSON
// 用法：mm export --run <runId> [--format csv|json] [--incremental] [--persona-file <path>|--persona '<json>'] [--output <path>]
// 被 mm.mjs 以 run({args, paths, helpers}) 调用（完整 Node 环境，可用 fs）。

import fs from 'node:fs';
import path from 'node:path';

const DEGREES = ['博士', 'MBA', '硕士', '本科', '专科'];
const DEGREE_RANK = { '专科': 1, '大专': 1, '本科': 2, '硕士': 3, 'MBA': 3, '博士': 4 };

// ---------- 解析 ----------
// 真实脉脉候选人卡片（.talent-common-card）的 innerText 行格式：
//   [姓名, 活跃度, 立即沟通, N年, 学历, 现居地, (期望：...)?, (求职意向)?, (近期有动向)?, 职业标签：, ...标签,
//    工作段(period, 公司, ·, 职位)..., 教育段(period, 学校, ·, 专业, ·, 学历)...]
// 当前职位取「至今」那一段（同公司多段经历时，至今才是现任）。
function parseRow(lines) {
  const name = lines[0] || '';
  const activity = lines[1] || '';
  const yearsLine = lines.find((l) => /^\d+年/.test(l)) || '';
  const years = (yearsLine.match(/(\d+)年/) || [])[1] || '';
  // 学历取行序第一个命中（卡片头部那个），不是 DEGREES 数组序
  const degree = lines.find((l) => DEGREES.includes(l)) || '';
  const intent = (lines.find((l) => /^(急求职|正在看机会|关注行情|半年不看机会)$/.test(l)) || '');
  // 工作经历段：period 行后跟 公司、·、职位；跳过教育段（公司位是学校）
  const periodRe = /^\d{4}[.\-]\d{2}/;
  const entries = [];
  for (let i = 0; i < lines.length; i++) {
    if (!periodRe.test(lines[i])) continue;
    const comp = lines[i + 1], sep = lines[i + 2], role = lines[i + 3];
    if (comp && sep === '·' && role && !/大学|学院/.test(comp)) {
      entries.push({ period: lines[i], company: comp, role });
    }
  }
  const cur = entries.find((e) => /至今/.test(e.period)) || entries[0] || { company: '', role: '' };
  const school = (lines.find((l) => /大学|学院/.test(l)) || '');
  return {
    name, activity, years, degree, intent,
    current_company: cur.company, current_role: cur.role, school,
    // 卡片里没有年龄/性别/现任时长，留空
    age: '', gender: '', tenure: '',
  };
}

function block(lines, startRe, endRe) {
  const s = lines.findIndex((l) => startRe.test(l));
  if (s < 0) return [];
  let e = lines.findIndex((l, i) => i > s && endRe.test(l));
  if (e < 0) e = lines.length;
  return lines.slice(s + 1, e);
}

function parseDetail(text) {
  const lines = (text || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const exp = block(lines, /^期望偏好$/, /^工作经历$/);
  // 逐行剥离「期望城市：」「期望岗位：」「期望薪资：」等标签前缀后分类，只留值
  const strip = (s) => String(s || '').replace(/^[^：:]{1,6}[：:]\s*/, '').trim();
  let salary = '', expCities = '', expRoles = '';
  for (const raw of exp) {
    const v = strip(raw);
    if (!v) continue;
    if (!salary && /k|薪|\/月/.test(v)) salary = v;
    else if (!expCities && /、|，|\/|北京|上海|深圳|广州|杭州|海外/.test(v)) expCities = v;
    else if (!expRoles) expRoles = v;
  }
  const work = block(lines, /^工作经历$/, /^教育经历$/);
  const companies = [];
  for (let i = 0; i < work.length; i++) {
    if (/\d{4}[-.]\d{2}|至今/.test(work[i]) && i >= 2) {
      const company = work[i - 2], role = work[i - 1];
      if (company && company !== '·' && !/大学|学院/.test(company)) companies.push(`${company}·${role}`);
    }
  }
  const highlight = work.filter((l) => l.length > 60).sort((a, b) => b.length - a.length)[0] || '';
  // 英文线索：「海外」须跟留学/工作/经历等语境词才算，避免「海外数据采集」这类业务词误判为英语能力
  const engHit = (text || '').match(/CET[- ]?[46]|大学英语[四六]级|英语[四六]级|雅思[\d.]*|托福[\d.]*|IELTS|TOEFL|英语流利|英文流利|商务英语|海外(?:留学|工作|经历|背景|沟通)|英语可作为工作语言|双语/i);
  return {
    salary, expCities, expRoles,
    workCompanies: companies.slice(0, 3).join(' / '),
    highlight: highlight.slice(0, 80),
    english: engHit ? engHit[0] : '',
  };
}

// ---------- 岗位匹配度（终极目标是匹配岗位，不是匹配文本） ----------
function shortLabel(b) {
  if (/英文|英语|english/i.test(b)) return '英文';
  if (/管理|团队|lead|带/i.test(b)) return '管理';
  if (/海外|国际|global/i.test(b)) return '海外';
  return String(b).slice(0, 4);
}

function evalBonus(b, cand) {
  const t = String(b);
  // 全文兜底：highlight 只抓长行，短描述候选人会漏判；优先用详情全文匹配
  const full = (cand._text || '') + ' ' + (cand.highlight || '') + ' ' + (cand.workCompanies || '');
  if (/英文|英语|english/i.test(t)) return { ok: !!cand.english };
  // 管理加分：意图只认「管理/团队/lead/manager」，证据要真正的带队信号（团队/管理/带领/带N人/lead/manager/汇报），
  // 不把「负责…搭建…」这类工程师自述误判为管理经验
  if (/管理|团队|lead|manager/i.test(t)) return { ok: /团队|管理|带领|带\s*\d+\s*人|lead|manager|汇报/i.test(full) };
  const kw = t.replace(/(经验|背景|能力|优先|加分)/g, '').trim();
  if (kw) return { ok: full.includes(kw) };
  return { ok: false };
}

function evalJobFit(persona, cand) {
  if (!persona) return { label: '', hits: 0, hardOk: true };
  const parts = [];
  let hits = 0;
  let hardOk = true;
  const hardFails = [];
  if (persona.hard) {
    if (persona.hard.years) {
      const m = String(persona.hard.years).match(/(\d+)\s*[-~到]\s*(\d+)/);
      const y = parseInt(cand.years, 10);
      if (m && !isNaN(y) && !(y >= +m[1] && y <= +m[2])) { hardOk = false; hardFails.push('年限'); }
    }
    if (persona.hard.degree) {
      const need = DEGREE_RANK[persona.hard.degree];
      if (need && (DEGREE_RANK[cand.degree] || 0) < need) { hardOk = false; hardFails.push('学历'); }
    }
  }
  for (const b of (persona.bonus || [])) {
    const r = evalBonus(b, cand);
    parts.push(shortLabel(b) + (r.ok ? '✓' : '✗'));
    if (r.ok) hits++;
  }
  parts.push(hardOk ? '硬性✓' : '硬性✗(' + hardFails.join('/') + ')');
  return { label: parts.join(' '), hits, hardOk };
}

// ---------- CSV ----------
function csvCell(v) {
  v = String(v ?? '');
  return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
}
function toCsv(rows) {
  const header = ['姓名', '活跃度', '求职意向', '年龄', '性别', '年限', '学历', '现公司', '现职位', '现任时长', '毕业学校', '期望城市', '期望岗位', '期望薪资', '英文线索', '附件简历', '附件文件', '历任公司(近3)', '亮点摘要', '来源query', '岗位匹配度'];
  const lines = [header.join(',')];
  for (const o of rows) {
    // 附件只放文件名（不带目录），目录固定是 ~/.maimai-scout/downloads/<runId>/
    const attName = o.attachment ? String(o.attachment).split('/').pop() : '';
    lines.push([o.name, o.activity, o.intent, o.age, o.gender, o.years, o.degree, o.current_company, o.current_role, o.tenure, o.school, o.expCities, o.expRoles, o.salary, o.english, o.hasPdf ? '有' : '', attName, o.workCompanies, o.highlight, o.sourceQuery, o.jobFit].map(csvCell).join(','));
  }
  return '﻿' + lines.join('\n');
}

// ---------- 主入口 ----------
export async function run({ args, paths, helpers }) {
  const runId = args.run;
  if (!runId) return { ok: false, code: 'USAGE', hint: '缺少 --run 参数。示例：mm export --run <runId> --format csv' };

  const runDir = path.join(paths.OUTPUT_DIR, runId);
  const listFile = path.join(runDir, 'list.jsonl');
  const detailFile = path.join(runDir, 'detail.jsonl');
  if (!fs.existsSync(listFile)) return { ok: false, code: 'NOT_FOUND', hint: '找不到列表文件：' + listFile + '。请先运行 search。' };

  const list = fs.readFileSync(listFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  // 详情按「姓名」对齐（search 与 harvest 之间列表会重排，rowIndex 不可靠；harvest 已给每条详情打了姓名）。
  // 只用姓名对齐，不做 rowIndex 兜底——避免重排时把错的详情安到错的人身上。收割到但列表里没有的人（孤儿详情）自然丢弃。
  const detailByName = new Map();
  if (fs.existsSync(detailFile)) {
    for (const l of fs.readFileSync(detailFile, 'utf8').split('\n').filter(Boolean)) {
      const d = JSON.parse(l);
      if (d.name && !detailByName.has(d.name)) detailByName.set(d.name, d); // 重名取先出现的
    }
  }

  const state = helpers.readJson(paths.STATE_FILE, { runs: {} });
  const runMeta = (state.runs && state.runs[runId]) || {};
  const sourceQuery = runMeta.query || '';

  // persona
  let persona = null;
  if (args['persona-file']) {
    try { persona = JSON.parse(fs.readFileSync(args['persona-file'], 'utf8')); }
    catch (e) { return { ok: false, code: 'USAGE', hint: 'persona 文件读取失败：' + e.message }; }
  } else if (args.persona && typeof args.persona === 'string') {
    try { persona = JSON.parse(args.persona); }
    catch (e) { return { ok: false, code: 'USAGE', hint: 'persona JSON 解析失败：' + e.message }; }
  }

  // 合并 list + detail（按姓名对齐）
  const merged = list.map((l) => {
    const row = parseRow(l.lines || []);
    const d = detailByName.get(row.name);
    const det = d ? parseDetail(d.text) : {};
    const cand = { ...row, ...det, hasPdf: d ? !!d.hasPdf : false, attachment: d ? (d.attachment || '') : '', sourceQuery, _text: d ? (d.text || '') : '' };
    const fit = evalJobFit(persona, cand);
    cand.jobFit = fit.label;
    cand._hits = fit.hits;
    cand._hardOk = fit.hardOk;
    return cand;
  });

  // 去重（name + current_company）
  const seenKey = new Set();
  const deduped = merged.filter((o) => {
    const k = o.name + '|' + o.current_company;
    if (seenKey.has(k)) return false;
    seenKey.add(k);
    return true;
  });

  // 增量过滤
  let rows = deduped;
  let newCount = deduped.length;
  if (args.incremental) {
    const seen = helpers.readJson(paths.SEEN_FILE, {});
    const now = new Date().toISOString();
    const fresh = [];
    for (const o of deduped) {
      const k = o.name + '|' + o.current_company;
      if (seen[k]) { seen[k].lastRun = now; }
      else { seen[k] = { firstSeen: now, lastRun: now }; fresh.push(o); }
    }
    helpers.writeJsonAtomic(paths.SEEN_FILE, seen);
    rows = fresh;
    newCount = fresh.length;
  }

  // 排序：岗位匹配度（硬性优先，再按加分命中数）
  rows.sort((a, b) => (b._hardOk - a._hardOk) || (b._hits - a._hits));

  // 输出
  const format = args.format || 'csv';
  const outPath = args.output || path.join(runDir, 'candidates.' + (format === 'json' ? 'json' : 'csv'));
  if (format === 'json') {
    helpers.writeJsonAtomic(outPath, rows.map(({ _hits, _hardOk, _text, ...rest }) => rest));
  } else {
    fs.writeFileSync(outPath, toCsv(rows));
  }

  return {
    ok: true, code: 'OK',
    data: { runId, output: outPath, total: deduped.length, exported: rows.length, newCount, format },
    hint: '导出 ' + rows.length + ' 人（去重后共 ' + deduped.length + ' 人）→ ' + outPath,
  };
}
