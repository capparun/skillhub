#!/usr/bin/env node
// mm.mjs — cskh-sourcing-maimai 原子 CLI wrapper（宿主无关）
//
// 架构：mm.mjs 持有全部 state（~/.maimai-scout/），ego 脚本无状态。
//   - ego 侧命令：读 scripts/ego/lib.mjs + <cmd>.mjs，把参数/page-map 内联拼成单个自包含 JS，
//     通过 stdin 喂给 `ego-browser nodejs`，捕获 stdout 信封。
//   - 本地命令（export）：直接在本进程执行，不启动 ego。
//   - 各 ego 命令的结果由 mm.mjs 落盘：search→list.jsonl，harvest→detail.jsonl，
//     explore→page-map.json，state.runs 跟踪游标。
//
// 统一信封：stdout 单行 JSON {ok, code, data, hint}；失败 exit 1。

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EGO_DIR = path.join(__dirname, 'ego');
const LOCAL_DIR = path.join(__dirname, 'local');
const STATE_ROOT = path.join(os.homedir(), '.maimai-scout');
const STATE_FILE = path.join(STATE_ROOT, 'state.json');
const PAGE_MAP_FILE = path.join(STATE_ROOT, 'page-map.json');
const SEEN_FILE = path.join(STATE_ROOT, 'seen.json');
const OUTPUT_DIR = path.join(STATE_ROOT, 'output');
const DOWNLOADS_DIR = path.join(STATE_ROOT, 'downloads');

const EGO_COMMANDS = new Set(['login', 'health', 'explore', 'search', 'harvest', 'finish']);
const LOCAL_COMMANDS = new Set(['export']);

// ---------- 信封 ----------
function emit(ok, code, data = null, hint = null) {
  process.stdout.write(JSON.stringify({ ok, code, data, hint }) + '\n');
}
function fail(code, hint, data = null) { emit(false, code, data, hint); process.exit(1); }

// ---------- argv ----------
function parseArgs(argv) {
  const cmd = argv[0];
  const args = {};
  for (let i = 1; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) args[key] = true;
      else { args[key] = next; i++; }
    }
  }
  return { cmd, args };
}

// ---------- state / json ----------
function ensureDirs() { for (const d of [STATE_ROOT, OUTPUT_DIR]) fs.mkdirSync(d, { recursive: true }); }
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJsonAtomic(file, obj) {
  const tmp = file + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, file);
}
function loadState() { return readJson(STATE_FILE, { version: 1, space: null, login: { status: 'unknown', checkedAt: null }, runs: {} }); }

// ---------- 环境探测（PRD：诚实，不静默失败） ----------
function detectEgoBinary() {
  if (process.platform === 'win32') {
    fail('UNSUPPORTED_PLATFORM', 'Windows 暂不支持：ego-lite 浏览器目前只有 macOS / Linux 版。请在 macOS 或 Linux 机器上运行，或等待 ego-lite Windows 版。');
  }
  const candidates = [process.env.EGO_BROWSER_BIN, path.join(os.homedir(), '.local', 'bin', 'ego-browser'), '/usr/local/bin/ego-browser', '/opt/homebrew/bin/ego-browser'].filter(Boolean);
  for (const c of candidates) { if (c.includes('/') && fs.existsSync(c)) return c; }
  return 'ego-browser'; // 回退 PATH；不在则由 runEgo 的 spawn error 报 EGO_NOT_FOUND
}

// ---------- 拼装 + spawn ego ----------
function runEgo(cmdName, args, state, pageMap) {
  const libPath = path.join(EGO_DIR, 'lib.mjs');
  const cmdPath = path.join(EGO_DIR, cmdName + '.mjs');
  if (!fs.existsSync(libPath) || !fs.existsSync(cmdPath)) fail('INTERNAL', `缺少 ego 脚本：${cmdName}`);
  const lib = fs.readFileSync(libPath, 'utf8');
  const body = fs.readFileSync(cmdPath, 'utf8');

  const injected = [
    `const ARGS = ${JSON.stringify(args)};`,
    `const CTX = ${JSON.stringify({ spaceId: state.space ? state.space.id : null, pageLabel: state.space ? state.space.pageLabel : 'p1', stateRoot: STATE_ROOT, outputDir: OUTPUT_DIR })};`,
    `const PAGE_MAP = ${JSON.stringify(pageMap)};`,
  ].join('\n');

  const js = injected + '\n' + lib + '\n' + body;
  const egoBin = detectEgoBinary();

  return new Promise((resolve) => {
    const child = spawn(egoBin, ['nodejs'], { stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '', err = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', (e) => resolve({ ok: false, code: 'EGO_NOT_FOUND', hint: `无法启动 ego-browser（${egoBin}）：${e.message}。请确认已安装 ego-lite 且 ego-browser 在 PATH。`, data: null }));
    child.on('close', () => {
      // ego-browser 把脚本 console.log 写到 stderr（stdout 恒为空），且前面可能混有 [ego-browser:notice] 行。
      // 合并两路流，取最后一个「带 ok 布尔的合法 JSON 行」作为信封；notice 等非 JSON 行自然被跳过。
      const lines = (out + '\n' + err).split('\n').map((l) => l.trim()).filter(Boolean);
      let env = null;
      for (let i = lines.length - 1; i >= 0; i--) {
        try { const j = JSON.parse(lines[i]); if (j && typeof j.ok === 'boolean') { env = j; break; } } catch { /* keep looking */ }
      }
      if (!env) resolve({ ok: false, code: 'EGO_NO_ENVELOPE', hint: `ego 脚本未返回有效信封。stderr: ${err.slice(0, 400)}`, data: { stdout: out.slice(-800), stderr: err.slice(-800) } });
      else resolve(env);
    });
    child.stdin.write(js);
    child.stdin.end();
  });
}

// ---------- 本地命令 ----------
async function runLocal(cmdName, args) {
  const mod = await import(path.join(LOCAL_DIR, cmdName + '.mjs'));
  return mod.run({ args, paths: { STATE_FILE, PAGE_MAP_FILE, SEEN_FILE, OUTPUT_DIR, STATE_ROOT }, helpers: { readJson, writeJsonAtomic } });
}

// ---------- runId ----------
function makeRunId(query) {
  const ds = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const slug = String(query || 'run').replace(/[^\w一-龥]+/g, '-').slice(0, 20);
  return ds + '-' + slug;
}

// ---------- ego 结果落盘 + state 更新 ----------
function handleEgoResult(cmd, args, env, state) {
  if (!env || !env.ok) return;
  const data = env.data || {};

  // __statePatch（login/health/finish 的 space/login）
  if (data.__statePatch) {
    const patch = data.__statePatch;
    delete data.__statePatch;
    if (patch.space !== undefined) state.space = patch.space;
    if (patch.login) state.login = patch.login;
  }

  if (cmd === 'explore' && data.pageMap) {
    writeJsonAtomic(PAGE_MAP_FILE, data.pageMap);
  }

  if (cmd === 'search') {
    const runId = args.run || makeRunId(data.query);
    const runDir = path.join(OUTPUT_DIR, runId);
    fs.mkdirSync(runDir, { recursive: true });
    const rows = data.rows || [];
    fs.writeFileSync(path.join(runDir, 'list.jsonl'), rows.length ? rows.map((r) => JSON.stringify({ lines: r.lines })).join('\n') + '\n' : '');
    state.runs[runId] = { query: data.query, pageSize: data.pageSize || 30, list: { count: rows.length }, harvest: { cursor: 0, status: 'pending' }, createdAt: new Date().toISOString() };
    // 筛选条件随 run 持久化：harvest 重新导航后筛选不会保留（纯前端状态），必须能重放
    if (args.filters && typeof args.filters === 'object') state.runs[runId].filters = args.filters;
    data.runId = runId;
  }

  if (cmd === 'harvest') {
    const runId = args.run;
    const runDir = path.join(OUTPUT_DIR, runId);
    fs.mkdirSync(runDir, { recursive: true });
    const details = data.details || [];
    if (details.length) fs.appendFileSync(path.join(runDir, 'detail.jsonl'), details.map((d) => JSON.stringify(d)).join('\n') + '\n');
    if (state.runs[runId]) {
      state.runs[runId].harvest = state.runs[runId].harvest || {};
      state.runs[runId].harvest.cursor = data.cursor;
      state.runs[runId].harvest.status = 'running';
    }
  }

  if (cmd === 'health') {
    const pm = readJson(PAGE_MAP_FILE, null);
    data.pageMapAge = pm && pm.version ? pm.version : null;
    const seen = readJson(SEEN_FILE, {});
    data.seenCount = Object.keys(seen).length;
  }
}

// ---------- 主流程 ----------
async function main() {
  const { cmd, args } = parseArgs(process.argv.slice(2));
  if (!cmd) fail('USAGE', '用法：node mm.mjs <login|health|explore|search|harvest|export|finish> [参数]。详见 SKILL.md。');
  ensureDirs();
  const state = loadState();

  if (LOCAL_COMMANDS.has(cmd)) {
    const env = await runLocal(cmd, args);
    emit(env.ok, env.code, env.data ?? null, env.hint ?? null);
    if (!env.ok) process.exit(1);
    return;
  }
  if (!EGO_COMMANDS.has(cmd)) fail('USAGE', `未知命令：${cmd}。可用：${[...EGO_COMMANDS, ...LOCAL_COMMANDS].join(', ')}`);

  // --filters 提前校验：必须是合法 JSON 对象（面板筛选传字符串值，结果 chip 传 true）
  if (args.filters) {
    if (typeof args.filters === 'string') {
      try { args.filters = JSON.parse(args.filters); }
      catch { fail('USAGE', `--filters 不是合法 JSON。示例：--filters '{"workyears":"5-10年","city":"北京","hasPdf":true}'`); }
    }
    if (typeof args.filters !== 'object' || Array.isArray(args.filters) || args.filters === null) {
      fail('USAGE', '--filters 必须是 JSON 对象。示例：--filters \'{"workyears":"5-10年","degree":"本科及以上"}\'');
    }
  }

  const pageMap = readJson(PAGE_MAP_FILE, null);

  // harvest 注入 run 上下文（query/cursor/pageSize/totalFromSearch/filters）
  if (cmd === 'harvest' && args.run && state.runs[args.run]) {
    const run = state.runs[args.run];
    args.query = run.query;
    args.cursor = run.harvest ? run.harvest.cursor : 0;
    args.pageSize = run.pageSize || 30;
    args.totalFromSearch = run.list ? run.list.count : 0;
    if (run.filters) args.filters = run.filters;
    if (args['with-attachment'] || args.withAttachment || args['with-pdf'] || args.withPdf) {
      args.withAttachment = true; // --with-pdf 是旧别名，继续兼容
      args.dlDir = path.join(DOWNLOADS_DIR, args.run);
      fs.mkdirSync(args.dlDir, { recursive: true });
    }
  }

  const env = await runEgo(cmd, args, state, pageMap);
  handleEgoResult(cmd, args, env, state);
  writeJsonAtomic(STATE_FILE, state);
  emit(env.ok, env.code, env.data ?? null, env.hint ?? null);
  if (!env.ok) process.exit(1);
}

main().catch((e) => fail('INTERNAL', e && e.message ? e.message : String(e)));
