// Run only against a private copy. Synthetic candidates and a synthetic profile.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const source=path.resolve(process.argv[2] || '.');
assert.equal(JSON.parse(fs.readFileSync(path.join(source,'../distribution.json'))).version,'2.1.37');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'hunter-review-'));
const runtime=path.join(root,'runtime');
fs.cpSync(source,runtime,{recursive:true,dereference:true});
fs.cpSync(fileURLToPath(new URL('./runtime/',import.meta.url)),runtime,{recursive:true});
const env={...process.env,HUNTER_DATA_DIR:path.join(root,'state'),OPENCLI_CONFIG_DIR:path.join(root,'opencli')};
function run(args,status=0){
 const result=spawnSync(process.execPath,args,{cwd:runtime,env,encoding:'utf8',timeout:120000});
 assert.equal(result.status,status,result.stderr+' '+result.stdout);
 return result.stdout;
}
run(['--test','packages/hunter-linkedin/test/review-resume.test.mjs']);
const cli=(args,status=0)=>JSON.parse(run(['opencli.mjs',...args,'-f','json'],status));
const profile='fixture'+process.pid;
const account=['hunter-linkedin','review-account','--context',profile];
const pause=cli([...account,'--pause-reason','unusual_activity']).data.pause;
const denied=cli(['--profile',profile,'linkedin','profile-experience','--profile-url','https://www.linkedin.com/in/offline-fixture/'],2);
assert.equal(denied.error.code,'account_paused');
assert.equal(cli([...account,'--resume-revision',pause.revision]).data.pause,null);
console.log('PASS: 200 synthetic reviews across 12 processes; 5-15s gaps, 20-30s group breaks, 60-90s rests, cooldown, deduplication, concurrency, pause and explicit recovery.');
