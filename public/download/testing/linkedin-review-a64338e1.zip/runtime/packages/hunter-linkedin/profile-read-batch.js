import {withProfileLock} from '../linkedin-workflow/src/profile-lock.mjs';
import {readState,saveState,riskReason,pauseReview} from '../linkedin-workflow/src/review-state.mjs';
import {profileContent} from './lib/profile-content.js';
import {validateResolvedProfile} from './lib/profile-reference.js';
import {verifyProfileReference} from './lib/profile-reference-reader.js';
import { cli, Strategy } from '@jackwener/opencli/registry';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {readJsonFile} from './lib/json-file.js';
import {
  anchorSectionUrl,
  buildEducationExtractionScript,
  experienceText,
  normalizeEducationRows,
} from './lib/anchor-sections.js';
import { createPacer } from './lib/pacing.js';

const fail = (code, message) => { throw Object.assign(new Error(message ?? code), { code }); };

// Mirrors the bundled linkedin profile-read extraction so batch rows keep the same fields.
export function buildProfileExtractionScript() {
  return String.raw`(() => {
    const clean = (s) => String(s || '').replace(/[\u00a0\u202f]+/g, ' ').replace(/\s+/g, ' ').trim();
    const compact = (s) => {
      const text = clean(s);
      if (!text) return '';
      if (text.length % 2 === 0 && text.slice(0, text.length / 2) === text.slice(text.length / 2)) {
        return text.slice(0, text.length / 2);
      }
      return text;
    };
    const readSection = (headingPattern) => {
      const headings = Array.from(document.querySelectorAll('section h2, section h3, h2, h3'));
      const heading = headings.find((el) => headingPattern.test(clean(el.innerText || el.textContent || '')));
      const section = heading?.closest('section');
      if (!section) return '';
      const text = clean(section.innerText || section.textContent || '');
      return clean(text.replace(headingPattern, '').replace(/\bShow all.*$/i, '').replace(/\bSee more.*$/i, ''));
    };
    const nameHeading = document.querySelector('main h1, main h2');
    const intro = nameHeading?.closest('section') || document.querySelector('main section') || document.body;
    const lines = (intro.innerText || intro.textContent || '').split(/\n+/).map(clean).filter(Boolean);
    const name = compact(clean(nameHeading?.innerText || nameHeading?.textContent || lines[0] || ''));
    const skipIntro = (line) => !line
      || line === name
      || /^(1st|2nd|3rd|contact info|message|more|follow|connect|open to|add section|enhance profile|resources|self employed)$/i.test(line)
      || /^\d[\d,]*\s+(followers|connections)/i.test(line)
      || line === '·';
    const headline = compact(lines.find((line) => !skipIntro(line) && line.length > 20) || '');
    // Location is the "City, Region, Country" line right below the headline; do not
    // rely on a hard-coded city list.
    const headlineIndex = lines.findIndex((line) => compact(line) === headline);
    const looksLikeLocation = (line) => line.length >= 2 && line.length < 120
      && /[,，]/.test(line)
      && !/^(contact info|message|follow|connect|more|open to|show all)/i.test(line);
    const locationText = (headlineIndex >= 0 ? lines.slice(headlineIndex + 1) : [])
      .find((line) => looksLikeLocation(line)) || '';
    const about = readSection(/^About$/i);
    const experience = readSection(/^Experience$/i);
    const education = readSection(/^Education$/i);
    const featured = readSection(/^Featured$/i);
    const services = readSection(/^Services$/i) || readSection(/^Providing services$/i);
    const observedAt = new Date().toISOString();
    const otwLabel = [...intro.querySelectorAll('[alt], [aria-label]')].map(e => e.getAttribute('alt') || e.getAttribute('aria-label') || '').find(t => /#?open\s*to\s*work|愿意接受工作机会|正在求职/i.test(t));
    const otwSection = [...document.querySelectorAll('main section')].find(e => /^(?:open to work|求职意向|正在求职)$/im.test(e.innerText || ''));
    const openToWork = {status: otwLabel || otwSection ? 'publicly_visible' : name ? 'not_observed' : 'unknown', source: window.location.href, observed_at: observedAt, evidence: otwLabel || (otwSection?.innerText || '').slice(0, 300), headline_signal: /looking for (?:a |new )?(?:job|opportunit)|seeking .*opportunit/i.test(headline) ? headline : null};
    return { openToWork, profile_url: window.location.href, name, headline, location: locationText, about, experience, education, services, featured };
  })()`;
}

function normalizeProfileUrl(value) {
  let url;
  try { url = new URL(value); } catch { fail('invalid_profile_url'); }
  if (url.origin !== 'https://www.linkedin.com' || url.username || url.password || url.search || url.hash || !/^\/in\/[^/?#]+\/?$/.test(url.pathname)) fail('invalid_profile_url');
  url.pathname = url.pathname.replace(/\/?$/, '/');
  return url.href;
}

const sleepMs = ms => new Promise(resolve => setTimeout(resolve, ms));

// Readiness replaces fixed waits: return as soon as the name and at least two
// profile sections are rendered; waitSeconds is only the slow-page hard cap.
const readinessScript = `(() => {
  const clean = (s) => String(s || '').replace(/\\s+/g, ' ').trim();
  const name = clean((document.querySelector('main h1, main h2') || {}).textContent || '');
  const sections = ['About', 'Experience', 'Education'].map((title) => {
    const heading = Array.from(document.querySelectorAll('section h2, section h3, h2, h3'))
      .find((el) => new RegExp('^' + title + '$', 'i').test(clean(el.textContent || '')));
    return heading ? 1 : 0;
  }).join('');
  return { nameReady: Boolean(name), sections, loading: Boolean(document.querySelector('[aria-busy="true"]')) };
})()`;

async function waitForProfile(page, maxSeconds = 8) {
  const started = Date.now();
  for (;;) {
    const state = await page.evaluate(readinessScript);
    const readyCount = String(state?.sections ?? '').split('').filter(flag => flag === '1').length;
    if (state?.nameReady && !state?.loading && readyCount >= 2) return state;
    // A profile without About/Experience sections still becomes readable after a short wait.
    if (state?.nameReady && Date.now() - started >= 2000) return state;
    if (Date.now() - started >= Math.max(1, maxSeconds) * 1000) return state;
    await sleepMs(250);
  }
}

const clean = value => String(value ?? '').replace(/\s+/g, ' ').trim();

export function normalizeRow(row, expectedUrl) {
  if (!row || typeof row !== 'object') fail('malformed_profile_payload');
  const name = clean(row.name);
  if (!name) fail('profile_unreadable');
  return {
    profile_url: clean(row.profile_url) || expectedUrl,
    requested_profile_url: row.requested_profile_url,
    profile_reference: row.profile_reference,
    identity_resolution: row.identity_resolution,
    name,
    openToWork: row.openToWork ?? {status:'unknown',source:expectedUrl,observed_at:null,evidence:''},
    headline: clean(row.headline),
    location: clean(row.location),
    about: clean(row.about),
    experience: clean(row.experience),
    education: clean(row.education),
    experience_items: Array.isArray(row.experience_items) ? row.experience_items : [],
    education_items: Array.isArray(row.education_items) ? row.education_items : [],
    services: clean(row.services),
    featured: clean(row.featured),
  };
}

function fatalCode(pageState) {
  const target = `${pageState?.url ?? ''} ${pageState?.title ?? ''}`;
  if (pageState?.warning) return 'unusual_activity';
  if (/\/checkpoint/i.test(target)) return 'verification_required';
  if (/\/login|\/authwall|\/uas\/login|LinkedIn Login/i.test(target)) return 'not_logged_in';
  return null;
}

function readProfileRows(file) {
  if (!fs.existsSync(file)) return [];
  const rows = [];
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line);
      if (row?.profile_url) rows.push(row);
    } catch { /* ignore a truncated trailing line */ }
  }
  return rows;
}

function readCheckpoint(file) {
  if (!fs.existsSync(file)) return new Map();
  const done = new Map();
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try {
      const entry = JSON.parse(line);
      if (entry?.profile_url) done.set(entry.profile_url, entry.status ?? 'ok');
    } catch { /* ignore a truncated trailing line */ }
  }
  return done;
}

async function assertNoFatal(page) {
  const state = await page.evaluate(`({url:location.href,title:document.title,warning:[...document.querySelectorAll('[role="alert"],main h1,main h2')].some(e=>e.getClientRects().length && /unusual activity|profile viewing temporarily restricted|your ability to view profiles has been temporarily restricted|异常活动|浏览档案.*受限/i.test(e.innerText))})`);
  const fatal = fatalCode(state);
  if (fatal) fail(fatal);
}

// Detail reading follows the profile's own anchor pages instead of scrolling the
// main profile: basics come from /in/<handle>/, the structured lists come from
// /details/experience/ (bundled command) and /details/education/.
export async function readProfileFromPage(page, url, waitSeconds, { getCommand } = {}) {
  await page.goto(url);
  await assertNoFatal(page);
  await waitForProfile(page, waitSeconds);
  const basics = await verifyProfileReference(page, url, await page.evaluate(buildProfileExtractionScript()));
  const resolvedUrl = basics.profile_url;

  let experienceItems = [];
  const experienceCommand = getCommand?.('linkedin/profile-experience');
  if (experienceCommand?.func) {
    const result = await experienceCommand.func(page, { 'profile-url': resolvedUrl });
    experienceItems = Array.isArray(result) ? result : result ? [result] : [];
    await assertNoFatal(page);
  }

  await page.goto(anchorSectionUrl(resolvedUrl, 'education'));
  await assertNoFatal(page);
  try { await page.wait({ text: 'Education', timeout: 5 }); } catch { /* a profile may have no education section */ }
  await assertNoFatal(page);
  const education = normalizeEducationRows(await page.evaluate(buildEducationExtractionScript()));

  return {
    ...basics,
    experience: experienceText(experienceItems) || clean(basics.experience),
    education: education.text || clean(basics.education),
    experience_items: experienceItems,
    education_items: education.items,
  };
}

export async function runProfileBatch({ page, urls, outputDir, resumeFile, waitSeconds = 8, limit, readProfile, pacer = null, sleep = sleepMs, budgetMs = 0, now = Date.now, accountProfile, stateRoot, onProgress = event => process.stderr.write(JSON.stringify(event) + "\n") } = {}) {
  if (!readProfile && !page) fail('browser_session_required');
  if (!Array.isArray(urls) || !urls.length) fail('profile_urls_required');
  if (accountProfile) {
    return withProfileLock(accountProfile, () => runLockedBatch({page, urls, outputDir, resumeFile, waitSeconds, limit, readProfile, pacer, sleep, budgetMs, now, accountProfile, stateRoot, onProgress}), undefined, {stateRoot});
  }
  return runLockedBatch({page, urls, outputDir, resumeFile, waitSeconds, limit, readProfile, pacer, sleep, budgetMs, now, onProgress});
}

async function runLockedBatch({page, urls, outputDir, resumeFile, waitSeconds, limit, readProfile, pacer, sleep, budgetMs, now, accountProfile, stateRoot, onProgress}) {
  const selected = [...new Set(urls.map(normalizeProfileUrl))].slice(0, Number.isInteger(limit) ? limit : undefined);
  fs.mkdirSync(outputDir, { recursive: true });
  if (accountProfile) {
    const binding = path.join(outputDir,'review-profile.json');
    try { fs.writeFileSync(binding,JSON.stringify(accountProfile),{flag:'wx',mode:0o600}); }
    catch (error) {
      if (error.code !== 'EEXIST') throw error;
      if (JSON.parse(fs.readFileSync(binding,'utf8')) !== accountProfile) fail('review_profile_mismatch');
    }
  }
  const checkpoint = resumeFile ?? path.join(outputDir, 'checkpoint.jsonl');
  // Append as we go so a kill, auth wall or budget stop never loses already-read bodies.
  const rowsFile = path.join(outputDir, 'profiles.jsonl');
  const done = readCheckpoint(checkpoint);
  const persisted = new Map(readProfileRows(rowsFile).map(row => [row.requested_profile_url ?? row.profile_url, row]));
  try { for (const row of JSON.parse(fs.readFileSync(path.join(outputDir, 'profiles.json'), 'utf8'))) if (!persisted.has(row.requested_profile_url ?? row.profile_url)) persisted.set(row.requested_profile_url ?? row.profile_url, row); } catch { /* append log remains authoritative */ }
  const missingBodies = selected.filter(url => done.get(url) === 'ok' && !persisted.has(url));
  // A success checkpoint without its body is not a completed read.
  for (const url of missingBodies) done.delete(url);
  const ledger = accountProfile ? readState(accountProfile,'activity',stateRoot) ?? {attempts:done.size, page_visits:0, next_at:0} : null;
  if (ledger?.in_flight) throw Error('review_interrupted_inspect_before_resume');
  if (ledger && pacer?.preset && ledger.schedule && ledger.preset === pacer.preset)
    pacer = createPacer({preset:pacer.preset, schedule:ledger.schedule});
  const persist = () => saveState(accountProfile,'activity',ledger,stateRoot);
  const pending = selected.filter(url => !done.has(url));
  const rows = [];
  let stopped = null;
  let processed = 0;
  const runStarted = now();
  const readOne = readProfile ?? (url => readProfileFromPage(page, url, waitSeconds));
  for (const [index, url] of pending.entries()) {
    const wait = ledger ? {ms:Math.max(0,ledger.next_at-now()),kind:ledger.wait_kind ?? 'gap'} : pacer ? pacer.delayBefore(index) : { ms: 0, kind: 'none' };
    // Stop before burning a pacing pause that would overrun the command budget:
    // the caller resumes from the checkpoint in a fresh process.
    if (budgetMs > 0 && (index > 0 || ledger) && now() - runStarted + Math.max(0, wait.ms) >= budgetMs) {
      stopped = 'time_budget';
      break;
    }
    if (wait.ms > 0) await sleep(wait.ms);
    if (ledger) {
      ledger.attempts++;
      ledger.in_flight = url;
      ledger.checkpoint = path.resolve(checkpoint);
      ledger.last_access = now();
      ledger.schedule = pacer?.schedule;
      ledger.preset = pacer?.preset;
      const reserve = pacer?.delayBefore(ledger.attempts) ?? {ms:0,kind:'none'};
      ledger.wait_kind = reserve.kind;
      ledger.wait_ms = reserve.ms;
      ledger.next_at = now() + reserve.ms;
      persist();
    }
    processed += 1;
    const started = Date.now();
    onProgress({event:"profile_started",profile_url:url,index:processed,total:pending.length});
    try {
      const row = await readOne(url, () => {
        if (ledger) { ledger.page_visits++; ledger.last_access=now(); persist(); }
      });
      if (!row || normalizeProfileUrl(row.requested_profile_url ?? row.profile_url) !== url) fail("profile_identity_mismatch");
      if (normalizeProfileUrl(row.profile_url) !== url) {
        const id = new URL(url).pathname.split('/')[2];
        if (!validateResolvedProfile({id,lookup_url:url},row.identity_resolution) || row.identity_resolution.url !== row.profile_url) fail('profile_identity_mismatch');
      }
      Object.assign(row, profileContent(row));
      rows.push(row);
      fs.appendFileSync(rowsFile, JSON.stringify(row) + '\n');
      fs.appendFileSync(checkpoint, JSON.stringify({ profile_url: url, status: 'ok', wait_ms: wait.ms, wait_kind: wait.kind, duration_ms: Date.now() - started }) + '\n');
      done.set(url, 'ok');
      onProgress({event:'profile_completed',profile_url:url,status:'ok',duration_ms:Date.now()-started});
    } catch (error) {
      const code = error?.code ?? 'profile_read_failed';
      const errorMessage = String(error?.message ?? '').slice(0, 200);
      done.set(url, 'failed');
      onProgress({event:'profile_completed',profile_url:url,status:'failed',error:code});
      fs.appendFileSync(checkpoint, JSON.stringify({ profile_url: url, status: 'failed', error: code, error_message: errorMessage, wait_ms: wait.ms, wait_kind: wait.kind, duration_ms: Date.now() - started }) + '\n');
      const risk = riskReason(error);
      if (ledger && risk) pauseReview(accountProfile,risk,stateRoot);
      if (risk || ['not_logged_in', 'verification_required', 'AUTH_REQUIRED'].includes(code) || /not logged in|authwall|checkpoint|login|AUTH_REQUIRED/i.test(error?.message ?? '')) {
        stopped = risk ?? (code === 'profile_read_failed' ? 'not_logged_in' : code);
        break;
      }
    } finally {
      if (ledger) {
        ledger.next_at = now() + ledger.wait_ms;
        ledger.in_flight = null;
        persist();
      }
    }
  }
  const resultsFile = path.join(outputDir, 'profiles.json');
  const existing = (() => {
    try {
      const parsed = JSON.parse(fs.readFileSync(resultsFile, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    } catch { return []; }
  })();
  const merged = new Map(existing.map(row => [row.requested_profile_url ?? row.profile_url, row]));
  // The append log is authoritative: it also holds rows from runs that were killed
  // before profiles.json was rewritten.
  for (const row of readProfileRows(rowsFile)) merged.set(row.requested_profile_url ?? row.profile_url, row);
  for (const row of rows) merged.set(row.requested_profile_url ?? row.profile_url, row);
  const people = new Map();
  for (const row of merged.values()) {
    const key = normalizeProfileUrl(row.profile_url);
    const prior = people.get(key);
    people.set(key, {...prior, ...row,
      profile_reference: row.profile_reference ?? prior?.profile_reference,
      identity_resolution: row.identity_resolution ?? prior?.identity_resolution,
      requested_profile_urls: [...new Set([...(prior?.requested_profile_urls ?? []), ...(row.requested_profile_urls ?? []), row.requested_profile_url ?? row.profile_url])],
    });
  }
  const uniqueProfiles = [...people.values()].map(row => ({...row, ...profileContent(row)}));
  fs.writeFileSync(resultsFile, JSON.stringify(uniqueProfiles, null, 2) + '\n');
  const outcomes = selected.map(profile_url => ({profile_url,content_status:merged.has(profile_url)?profileContent(merged.get(profile_url)).content_status:undefined,status:merged.has(profile_url)?'ok':done.get(profile_url)==='failed'?'failed':'not_processed'}));
  const summary = {
    outcomes,
    failed_profiles: outcomes.filter(row => row.status === 'failed').map(row => row.profile_url),
    unprocessed_profiles: outcomes.filter(row => row.status === 'not_processed').map(row => row.profile_url),
    checkpoint_missing_bodies: missingBodies,
    selected_results_total: outcomes.filter(row => row.status === 'ok').length,
    requested: selected.length,
    account_activity: ledger,
    pending_before_run: pending.length,
    resumed_from_checkpoint: selected.length - pending.length,
    read_ok: rows.filter(row => row.content_status === 'content_observed').length,
    content_unavailable_profiles: outcomes.filter(row => row.content_status === 'content_unavailable').map(row => row.profile_url),
    results_total: uniqueProfiles.length,
    stopped: stopped,
    remaining_after_run: pending.length - processed,
    elapsed_ms: now() - runStarted,
    checkpoint,
    rows_log: rowsFile,
    output_dir: outputDir,
  };
  fs.writeFileSync(path.join(outputDir, 'summary.json'), JSON.stringify(summary, null, 2) + '\n');
  return { rows, summary, profiles: uniqueProfiles };
}

cli({
  site: 'hunter-linkedin',
  name: 'profile-read-batch',
  description: '单个浏览器会话内顺序读取多个 LinkedIn 主页，逐条写检查点；中断后用同一输出目录续读',
  domain: 'www.linkedin.com',
  access: 'read',
  browser: true,
  strategy: Strategy.COOKIE,
  args: [
    { name: 'input', type: 'string', required: true, help: 'JSON 文件，字段 profile_urls[]（可选 output、resume、wait_seconds、limit）' },
    { name: 'output', type: 'string', required: false, help: '结果与检查点目录；默认 ~/.hunter/channels/linkedin/profile-batch' },
    { name: 'resume', type: 'string', required: false, help: '已有检查点文件；默认输出目录下的 checkpoint.jsonl' },
    { name: 'wait', type: 'number', required: false, help: '页面就绪硬上限秒数，默认 8；就绪后立即读取' },
    { name: 'limit', type: 'number', required: false, help: '本次最多读取人数' },
    { name: 'pacing', type: 'string', required: false, help: '读取节奏：steady（稳健，默认 5–15 秒）/ conservative（45–90 秒）/ standard（15–25 秒）/ none' },
    { name: 'budget', type: 'int', required: false, help: '本次命令内部时间预算秒数，到点停止并保留检查点供续读；默认 240' },
    { name: 'timeout', type: 'int', default: 300, help: '浏览器命令超时秒数；节奏等待计入该预算，默认 300' },
  ],
  func: async (page, args) => {
    if (!page) fail('browser_session_required');
    const file = path.resolve(args.input);
    if (!fs.existsSync(file)) fail('input_file_missing');
    const input = readJsonFile(file);
    const outputDir = path.resolve(args.output ?? input.output ?? path.join(process.env.HUNTER_DATA_DIR || path.join(os.homedir(), '.hunter'), 'channels', 'linkedin', 'profile-batch'));
    // Detail reading is anchor-based: main page for basics, /details/experience/ and
    // /details/education/ for the structured lists (no main-page scrolling).
    const { getRegistry } = await import('@jackwener/opencli/registry');
    const waitSeconds = args.wait ?? input.wait_seconds ?? 8;
    const preset = String(args.pacing ?? input.pacing ?? 'steady');
    const pacer = preset === 'none' ? null : createPacer({ preset });
    const budgetSeconds = Number(args.budget ?? input.budget_seconds ?? 240);
    if (!Number.isInteger(budgetSeconds) || budgetSeconds < 1) fail('invalid_budget');
    if (!page.contextId) fail('explicit_bridge_profile_required');
    const readProfile = async (url, onVisit) => normalizeRow(
      await readProfileFromPage(new Proxy(page,{get(target,key) {
        if (key === 'goto') return (...args) => { onVisit(); return target.goto(...args); };
        const value=target[key]; return typeof value==='function'?value.bind(target):value;
      }}), url, waitSeconds, { getCommand: name => getRegistry().get(name) }),
      url,
    );
    const result = await runProfileBatch({
      page,
      accountProfile:page.contextId,
      urls: input.profile_urls,
      outputDir,
      resumeFile: args.resume ? path.resolve(args.resume) : input.resume ? path.resolve(input.resume) : undefined,
      waitSeconds,
      limit: args.limit ?? input.limit,
      readProfile,
      pacer,
      budgetMs: budgetSeconds * 1000,
    });
    return result.rows;
  },
});
