import fs from 'node:fs';
import {cli,Strategy} from '@jackwener/opencli/registry';
import {withProfileLock} from '../linkedin-workflow/src/profile-lock.mjs';
import {readState,clearPause,saveState,pauseReview} from '../linkedin-workflow/src/review-state.mjs';

cli({
  site:'hunter-linkedin', name:'review-account', strategy:Strategy.LOCAL, browser:false, access:'write',
  description:'本地查看审阅计数和账号暂停；人工核实平台已恢复后可按当前回执解除暂停。',
  args:[{name:'context',type:'string',required:true},{name:'pause-reason',type:'string'},{name:'resume-revision',type:'string'},{name:'acknowledge-interrupted-url',type:'string'}],
  func:async args=>withProfileLock(args.context,()=>{
    const activity=readState(args.context,'activity');
    if (args['pause-reason']) {
      if(!['unusual_activity','verification_required','account_restricted','rate_limited'].includes(args['pause-reason']) || args['resume-revision']) throw Error('invalid_pause_reason');
      pauseReview(args.context,args['pause-reason']);
    }
    if(args['resume-revision']) clearPause(args.context,args['resume-revision']);
    if(args['acknowledge-interrupted-url']){
      if(activity?.in_flight!==args['acknowledge-interrupted-url']) throw Error('interrupted_url_mismatch');
      // Record the unknown attempt before releasing it so resume cannot re-open it.
      if(!activity.checkpoint) throw Error('interrupted_checkpoint_unknown');
      fs.appendFileSync(activity.checkpoint,JSON.stringify({profile_url:activity.in_flight,status:'failed',error:'interrupted_unverified'})+'\n');
      activity.in_flight=null;
      saveState(args.context,'activity',activity);
    }
    return {pause:readState(args.context,'pause'),activity};
  },undefined,{recovery:true}),
});
