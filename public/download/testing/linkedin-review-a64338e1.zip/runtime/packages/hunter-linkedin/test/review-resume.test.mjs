import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {runProfileBatch} from '../profile-read-batch.js';
import {withProfileLock} from '../../linkedin-workflow/src/profile-lock.mjs';
import {clearPause,readState} from '../../linkedin-workflow/src/review-state.mjs';

test('resume retains account cooldown, skips completed people, serializes work and stops all new tasks after warning',async t=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'review-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const account='test'+process.pid;
  const urls=Array.from({length:10},(_,i)=>'https://www.linkedin.com/in/person-'+i+'/');
  let clock=1000;
  const waits=[],seen=[];
  const opts={accountProfile:account,stateRoot:root,outputDir:path.join(root,'task'),urls,
    now:()=>clock,sleep:async ms=>{waits.push(ms); clock+=ms;},onProgress:()=>{},
    pacer:{delayBefore:i=>({ms:i===3?60000:1000,kind:i===3?'group_pause':'gap'})},
    readProfile:async (url,visit)=>{visit();seen.push(url);return {profile_url:url,about:'observed'};}};
  await runProfileBatch({...opts,urls:urls.slice(0,3)});
  const limited=await runProfileBatch({...opts,budgetMs:10000});
  assert.equal(limited.summary.stopped,'time_budget');
  assert.equal(seen.length,3);
  await runProfileBatch({...opts,urls:urls.slice(0,4)});
  assert.equal(waits.at(-1),60000);
  assert.deepEqual(seen,urls.slice(0,4));
  const faulty=await runProfileBatch({...opts,readProfile:async()=>{
    await assert.rejects(runProfileBatch(opts),{code:'profile_busy'});
    throw Object.assign(Error('rate limited'),{code:'rate_limited'});
  }});
  assert.equal(faulty.summary.stopped,'rate_limited');
  await assert.rejects(runProfileBatch({...opts,outputDir:path.join(root,'other')}),{code:'account_paused'});
  await assert.rejects(withProfileLock(account,()=>assert.fail('dispatched'),undefined,{stateRoot:root}),{code:'account_paused'});
  assert.equal(readState(account,'activity',root).page_visits,4);
  const pause=readState(account,'pause',root);
  assert.throws(()=>clearPause(account,'old',root));
  clearPause(account,pause.revision,root);
  await withProfileLock(account,()=>{},undefined,{stateRoot:root});
});

test('fresh processes resume 200 synthetic profiles without any LinkedIn access',async t=>{
  const {spawnSync}=await import('node:child_process');
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'review-200-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  const context='offline'+process.pid;
  const moduleUrl=new URL('../profile-read-batch.js',import.meta.url).href;
  const child=`
    import {runProfileBatch} from ${JSON.stringify(moduleUrl)};
    const [root,account,end]=process.argv.slice(1);
    const urls=Array.from({length:Number(end)},(_,i)=>'https://www.linkedin.com/in/fixture-'+i+'/');
    const result=await runProfileBatch({urls,accountProfile:account,stateRoot:root,outputDir:root+'/task',
      onProgress:()=>{},now:()=>1000,sleep:async()=>{},pacer:{delayBefore:()=>({ms:1,kind:'gap'})},
      readProfile:async (url,visit)=>{visit();return {profile_url:url,about:'synthetic'};}});
    console.log(JSON.stringify(result.summary));
  `;
  for (const count of [3,10,30,50,70,90,110,130,150,170,190,200]) {
    const run=spawnSync(process.execPath,['--input-type=module','-e',child,root,context,String(count)],{encoding:'utf8'});
    assert.equal(run.status,0,run.stderr);
    const summary=JSON.parse(run.stdout);
    assert.equal(summary.account_activity.attempts,count);
    assert.equal(summary.account_activity.page_visits,count);
    assert.equal(summary.results_total,count);
  }
});

test('default ordinary gap includes exactly the requested endpoints',async()=>{
  const {createPacer}=await import('../lib/pacing.js');
  assert.equal(createPacer({random:()=>0}).delayBefore(1).ms,5000);
  assert.equal(createPacer({random:()=>0.9999999}).delayBefore(1).ms,15000);
});
