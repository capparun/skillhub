import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createHash,randomUUID} from 'node:crypto';

export function reviewRoot() {
  return path.join(process.env.HUNTER_DATA_DIR || path.join(os.homedir(), '.hunter'), 'linkedin-review');
}
function statePath(profile, kind, root) {
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(profile ?? '')) throw Error('explicit_bridge_profile_required');
  return path.join(root, createHash('sha256').update(profile).digest('hex') + '.' + kind + '.json');
}
export function readState(profile, kind, root = reviewRoot()) {
  try { return JSON.parse(fs.readFileSync(statePath(profile,kind,root),'utf8')); }
  catch (error) { if (error.code !== 'ENOENT') throw error; return null; }
}
export function saveState(profile, kind, value, root = reviewRoot()) {
  const file = statePath(profile,kind,root);
  fs.mkdirSync(root,{recursive:true,mode:0o700});
  const tmp = file + '.' + randomUUID();
  fs.writeFileSync(tmp,JSON.stringify(value),{mode:0o600,flag:'wx'});
  fs.renameSync(tmp,file);
}
export function requireActive(profile, root = reviewRoot()) {
  if (readState(profile,'pause',root)) throw Object.assign(Error('account_paused'),{code:'account_paused'});
}
export function anyPaused(root = reviewRoot()) {
  try { return fs.readdirSync(root).some(name=>name.endsWith('.pause.json')); }
  catch (error) { if(error.code!=='ENOENT') throw error; return false; }
}
export function riskReason(value) {
  const codes = ['verification_required','not_logged_in','login_required','AUTH_REQUIRED','rate_limited','search_restricted','search_blocked','account_restricted','unusual_activity','captcha_required'];
  for (const item of [value, value?.error, value?.interruption, value?.data?.interruption, value?.error?.upstream]) {
    const code = item?.code ?? item?.reason;
    if (codes.includes(code)) return code;
    if (item?.status === 429 || code === 429 || code === 'HTTP_429') return 'rate_limited';
    if (/captcha|authwall|verification required|unusual activity|account (?:temporarily )?restricted|not logged in|HTTP 429/i.test(item?.message || '')) return 'verification_required';
  }
  return null;
}
export function pauseReview(profile,reason,root=reviewRoot()) {
  const pause={reason,at:new Date().toISOString(),revision:randomUUID()};
  saveState(profile,'pause',pause,root);
  return pause;
}
export function clearPause(profile,revision,root=reviewRoot()) {
  const pause=readState(profile,'pause',root);
  if (!pause || !revision || pause.revision !== revision) throw Error('pause_revision_mismatch');
  fs.unlinkSync(statePath(profile,'pause',root));
}
