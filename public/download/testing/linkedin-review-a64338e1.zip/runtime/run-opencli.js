import {withProfileLock,inspectProfileLock,isHeldHere} from './packages/linkedin-workflow/src/profile-lock.mjs';
import {anyPaused,requireActive} from './packages/linkedin-workflow/src/review-state.mjs';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { installLinkedInCompatibility } from './linkedin-compat.js';
import { fileURLToPath, pathToFileURL } from 'node:url';

/** Pinned 2.0 host: load explicit product plugins, never discover shared user plugins. */
export async function runOpencli(pluginRoots) {
  const entry = import.meta.resolve('@jackwener/opencli');
  const packageRoot = path.resolve(path.dirname(fileURLToPath(entry)), '../..');
  const metadata = JSON.parse(fs.readFileSync(path.join(packageRoot, 'package.json'), 'utf8'));
  if (metadata.version !== '2.0.3') throw new Error(`需要项目 OpenCLI 2.0.3，实际为 ${metadata.version}`);
  const { isIgnorableDaemonPortEnv, unsupportedDaemonPortEnvMessage } = await import(new URL('./constants.js', entry));
  const { isSupportedNodeVersion } = await import(new URL('./runtime-detect.js', entry));
  if (!isSupportedNodeVersion(process.version)) throw new Error(`OpenCLI 不支持 Node.js ${process.version}`);
  if (!isIgnorableDaemonPortEnv(process.env.OPENCLI_DAEMON_PORT)) {
    throw new Error(unsupportedDaemonPortEnvMessage(process.env.OPENCLI_DAEMON_PORT));
  }
  if (['--version', '-V'].includes(process.argv[2])) {
    console.log(metadata.version);
    return;
  }
  if (process.argv.slice(2).join(' ') === 'daemon ensure') {
    if (process.platform !== 'win32') throw new Error('daemon ensure 仅适用于 Windows 安装');
    const script = fileURLToPath(new URL('./ensure-windows-bridge.ps1', import.meta.url));
    const powershell = path.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const result = spawnSync(powershell, ['-NoProfile', '-NonInteractive', '-File', script, '-NodePath', process.execPath],
      { encoding: 'utf8', windowsHide: true, timeout: 45000 });
    if (result.error) throw result.error;
    if (result.status !== 0) throw new Error(result.stderr.trim() || 'Windows 桥接启动失败');
    console.log(JSON.stringify({ ok: true, data: JSON.parse(result.stdout.trim()) }));
    return;
  }
  // These internal entry points are pinned and covered by actual CLI smoke tests.
  // Do not import main.js: its discovery rewrites ~/.opencli/plugins/* dependencies.
  const { discoverClis } = await import(new URL('./discovery.js', entry));
  const { runCli } = await import(new URL('./cli.js', entry));
  const { installNodeNetwork } = await import(new URL('./node-network.js', entry));
  const { escapeLeadingDashPositional } = await import(new URL('./cli-argv-preprocess.js', entry));
  const builtin = path.join(packageRoot, 'clis');
  installNodeNetwork();
  await discoverClis(builtin);
  for (const root of pluginRoots) {
    for (const name of fs.readdirSync(root).filter(name => name.endsWith('.js')).sort()) {
      await import(pathToFileURL(path.join(root, name)));
    }
  }
  await installLinkedInCompatibility(packageRoot);
  const {getRegistry}=await import('@jackwener/opencli/registry');
  for (const command of new Set(getRegistry().values())) {
    if (!['linkedin','hunter-linkedin'].includes(command.site) || !command.browser || !command.func ||
        command.name==='profile-read-batch') continue;
    const original=command.func;
    command.func=async (page,...args)=>{
      const profile=page.contextId;
      if (!profile) {
        if(anyPaused()) throw Error('account_paused_select_explicit_profile');
        return original(page,...args);
      }
      const run=()=>original(page,...args);
      if (isHeldHere(profile)) { requireActive(profile); return run(); }
      // The task gateway already owns the same lock in the direct parent process.
      if (process.env.HUNTER_GATEWAY_PARENT===String(process.ppid)) {
        const lock=await inspectProfileLock(profile);
        if(lock.status==='running' && lock.owner.pid===process.ppid){
          requireActive(profile);
          return run();
        }
      }
      return withProfileLock(profile,run);
    };
  }
  const manifest = JSON.parse(fs.readFileSync(path.join(packageRoot, 'cli-manifest.json'), 'utf8'));
  if (Array.isArray(manifest)) {
    process.argv.splice(2, process.argv.length - 2, ...escapeLeadingDashPositional(process.argv.slice(2), manifest));
  }
  const argv=process.argv.slice(2);
  const siteIndex=argv.findIndex(arg=>['linkedin','hunter-linkedin','browser'].includes(arg));
  if (siteIndex>=0 && !argv.includes('--help') && anyPaused()) {
    const site=argv[siteIndex], command=getRegistry().get(site+'/'+argv[siteIndex+1]);
    if (site==='browser' || site==='linkedin' || command?.browser !== false) {
      const {resolveProfileSelection}=await import(new URL('./browser/profile.js',entry));
      const flag=argv.findIndex(arg=>arg==='--profile' || arg.startsWith('--profile='));
      const profile=flag<0?undefined:argv[flag]==='--profile'?argv[flag+1]:argv[flag].slice(10);
      const selection=resolveProfileSelection(profile);
      try {
        if(selection?.source!=='explicit') throw Object.assign(Error('account_paused_select_explicit_profile'),{code:'account_paused_select_explicit_profile'});
        requireActive(selection.contextId);
      } catch(error) {
        if(!['account_paused','account_paused_select_explicit_profile'].includes(error.code)) throw error;
        console.log(JSON.stringify({ok:false,error:{code:error.code,message:'平台操作已暂停。请先核对账号状态。'}}));
        process.exitCode=2;
        return;
      }
    }
  }
  await runCli(builtin, path.join(os.homedir(), '.opencli', 'clis'));
}
