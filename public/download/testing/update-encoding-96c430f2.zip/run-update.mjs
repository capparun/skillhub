#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const skillRoot = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const pointerPath = path.join(skillRoot, '.hunter-installation.json');

const machine = process.argv.includes('--json') || process.platform === 'win32';
function emit(value) {
  const ascii = JSON.stringify(value).replace(/[^\x20-\x7e]/g, char =>
    '\\u' + char.charCodeAt(0).toString(16).padStart(4, '0'));
  fs.writeSync(1, ascii + '\n');
}
function fail(code, message) {
  if (machine) emit({ok:false, stage:'launcher', code, message});
  else console.error(message);
  process.exit(1);
}

if (!fs.existsSync(pointerPath)) {
  fail('pointer_missing', '未找到猎策安装路径登记。请使用最新安装包重新安装一次，再重试更新。');
}

let pointer;
try {
  pointer = JSON.parse(fs.readFileSync(pointerPath, 'utf8'));
} catch {
  fail('pointer_unreadable', '猎策安装路径登记损坏。请使用最新安装包重新安装一次，再重试更新。');
}

const product = pointer?.product;
const stateRoot = pointer?.stateRoot;
if (typeof product !== 'string' || !product || typeof stateRoot !== 'string' || !path.isAbsolute(stateRoot)) {
  fail('pointer_invalid', '猎策安装路径登记无效。请使用最新安装包重新安装一次，再重试更新。');
}

const receiptPath = path.join(stateRoot, 'installations', `${product}.json`);
const updaterPath = path.join(stateRoot, 'packages', product, 'update.mjs');
if (!fs.existsSync(receiptPath) || !fs.existsSync(updaterPath)) {
  fail('installation_missing', '猎策安装记录或更新器缺失。请使用最新安装包重新安装一次，再重试更新。');
}

const args = process.argv.slice(2).filter(arg => arg !== '--json');
if (!machine) {
  const result = spawnSync(process.execPath, [updaterPath, ...args], {stdio:'inherit'});
  if (result.error) console.error(result.error.message);
  process.exit(result.status ?? 1);
}

let logFd;
let logPath;
let outcomePath;
try {
  const dir = path.join(stateRoot, 'installation-logs');
  fs.mkdirSync(dir, {recursive:true});
  logPath = path.join(dir, 'update-' + randomUUID() + '.log');
  outcomePath = logPath + '.json';
  logFd = fs.openSync(logPath, 'wx', 0o600);
  const result = spawnSync(process.execPath, [updaterPath, ...args], {
    stdio:['inherit', logFd, logFd],
    env:{...process.env, HUNTER_UPDATE_OUTCOME:outcomePath},
  });
  const outcome = fs.existsSync(outcomePath)
    ? JSON.parse(fs.readFileSync(outcomePath,'utf8')) : {stage:'receipt'};
  const ok = result.status === 0 && Boolean(outcome.status);
  emit({...outcome, ok, logPath, ...(ok ? {} : {code:result.error?.code ?? 'update_failed'})});
  process.exitCode = ok ? 0 : result.status || 1;
} catch (error) {
  emit({ok:false, stage:'launcher', code:error.code ?? 'output_failed', logPath, message:error.message});
  process.exitCode = 1;
} finally {
  if (logFd !== undefined) fs.closeSync(logFd);
}
