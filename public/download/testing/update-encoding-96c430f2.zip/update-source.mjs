// The Skill pointer locates the receipt; it intentionally contains no server URL.
export function updateSource({explicit, previous = {}, manifest = {}}) {
  const value = explicit ?? previous.serverUrl ?? manifest.updateServerUrl;
  if (!value) throw new Error('安装回执及产品清单均缺少分发站地址；请使用明确来源的新版候选安装包修复，不要降级重装。');
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash)
    throw new Error('更新分发站地址无效：需要无凭据、无查询参数的 HTTPS 地址。');
  const serverUrl = url.href.replace(/\/+$/, '');
  const previousServer = previous.serverUrl?.replace(/\/+$/, '');
  return {serverUrl, updateCredential: previousServer === serverUrl ? previous.updateCredential ?? null : null};
}
export function compareProductVersions(local, remote) {
  for (const version of [local,remote]) if (!/^\d+\.\d+\.\d+$/.test(version ?? '')) throw new Error('产品版本无效，停止更新检查。');
  const a=local.split('.').map(Number),b=remote.split('.').map(Number);
  for(let i=0;i<3;i++) if(a[i]!==b[i]) return a[i]>b[i]?'local_newer':'update_available';
  return 'current';
}
export function assertUpdatePackage(manifest, product, version) {
  if (manifest?.product !== product || manifest?.version !== version)
    throw new Error('下载包的产品或版本与已检查发布不一致；停止安装，原版本不变。');
}
